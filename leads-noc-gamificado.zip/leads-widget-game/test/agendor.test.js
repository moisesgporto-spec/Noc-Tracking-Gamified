require('../lib/agendor').setGap(0);
// Testa a logica de leitura com uma API falsa que imita o comportamento real do Agendor
const assert = require('assert');
const { fetchMonth, fetchYoy, fetchAggs } = require('../lib/agendor');

const now = new Date(2026, 10, 4, 12);
const D = (y, m, d, h = 12) => new Date(y, m - 1, d, h).toISOString();
const people = {};
const deals = [];
// 250 negocios antigos + alguns deste mes, ordenados por atualizacao decrescente
let id = 1000;
const mkPerson = (name, origin, created) => { id++; people[id] = { id, name, createdAt: created, updatedAt: created, leadOrigin: origin ? { id: 1, name: origin } : null }; return id; };
const pA = mkPerson('A', 'Panfletagem', D(2026, 11, 2));
const pB = mkPerson('B', 'Anúncios', D(2026, 11, 3));
const pC = mkPerson('C', null, D(2026, 11, 3));
const pOld = mkPerson('Antigo', 'Anúncios', D(2026, 5, 1));
const deal = (i, personId, created, updated, status = 1, wonAt = null, owner = null, funnel = null, value = 0) => ({ id: i, person: { id: personId }, createdAt: created, updatedAt: updated, dealStatus: { id: status }, wonAt, owner: owner ? { name: owner } : undefined, dealStage: funnel ? { funnel: { name: funnel } } : undefined, value });
deals.push(deal(1, pA, D(2026, 11, 2), D(2026, 11, 4), 1, null, 'Lehm Silva', 'SAPreuni'));
deals.push(deal(2, pB, D(2026, 11, 3), D(2026, 11, 3), 1, null, 'João', 'MAPreuni'));
deals.push(deal(3, pC, D(2026, 11, 3), D(2026, 11, 3), 1, null, null, 'MAPreuni'));
deals.push(deal(6, pC, D(2026, 11, 3), D(2026, 11, 3), 1, null, 'Lehm Silva', 'Extensivo')); // outro funil, nao conta
deals.push(deal(7, pC, D(2026, 11, 3), D(2026, 11, 3), 2, D(2026, 11, 3), 'Lehm Silva', 'Extensivo', 9000)); // ganho em outro funil, nao conta
deals.push(deal(4, pOld, D(2026, 9, 10), D(2026, 11, 2), 2, D(2026, 11, 2), 'Nycolas', 'SAPreuni', 5000)); // criado em setembro, ganho em novembro
deals.push(deal(5, pA, D(2026, 11, 2), D(2026, 11, 2), 2, D(2026, 11, 2), 'Feliep', 'MAPreuni', 3000));   // criado e ganho neste mes
for (let k = 0; k < 250; k++) deals.push(deal(100 + k, pOld, k < 30 ? D(2026, 10, 5) : D(2026, 8, 1), D(2026, 10, 1 + (k % 20)), 1, null, null, 'SAPreuni'));
deals.push(deal(900, pOld, D(2026, 9, 20), D(2026, 10, 6), 2, D(2026, 10, 6), null, 'SAPreuni')); // ganho em outubro
deals.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
const peopleList = Object.values(people).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));

let calls = [];
global.fetch = async (url) => {
  const u = new URL(url);
  calls.push(u.pathname + u.search);
  const m = u.pathname.match(/\/v3\/(deals|people)(?:\/(\d+))?$/);
  const list = m[1] === 'deals' ? deals : peopleList;
  if (m[2]) return { ok: true, status: 200, json: async () => ({ data: people[m[2]] }) };
  const page = Number(u.searchParams.get('page')), per = Number(u.searchParams.get('per_page'));
  return { ok: true, status: 200, json: async () => ({ data: list.slice((page - 1) * per, page * per) }) };
};

(async () => {
  let r = await fetchMonth({ token: 't', entity: 'deals', now });
  assert.strictEqual(r.leads.total, 4);                       // negocios 1,2,3,5 criados em novembro
  assert.deepStrictEqual(r.leads.origins, { Panfletagem: 2, 'Anúncios': 1, 'Sem origem': 1 });
  assert.strictEqual(r.won.total, 2);                         // negocios 4 e 5 ganhos em novembro
  assert.deepStrictEqual(r.won.origins, { 'Anúncios': 1, Panfletagem: 1 }); // origem de quem se matriculou
  const pages = calls.filter((c) => c.includes('/deals?')).length;
  assert.ok(pages <= 2, 'parou cedo, leu ' + pages + ' paginas');  // 255 negocios = 3 paginas, mas para na 1a ou 2a
  // cache de origem evita novas buscas por pessoa
  calls = [];
  r = await fetchMonth({ token: 't', entity: 'deals', now, originCache: r.originCache });
  assert.strictEqual(calls.filter((c) => /people\/\d+/.test(c)).length, 0);

  // outros funis nao entram nem como lead nem como ganho
  assert.strictEqual(r.won.total, 2);
  r = await fetchMonth({ token: 't', entity: 'people', now }); // qualquer entidade vira negocios dos funis certos
  assert.strictEqual(r.leads.total, 4);
  // mes anterior
  calls = [];
  r = await fetchMonth({ token: 't', entity: 'deals', now, includePrev: true });
  assert.strictEqual(r.leads.total, 4);                          // novembro nao muda
  assert.strictEqual(r.prev.month, '2026-10');
  assert.strictEqual(r.prev.leadsDays['2026-10-05'], 30);        // 30 negocios criados em 5 de outubro
  assert.strictEqual(r.prev.wonDays['2026-10-06'], 1);
  assert.ok(calls.filter((c) => c.includes('/deals?')).length > pages); // leu mais paginas para chegar em outubro
  assert.strictEqual((await fetchMonth({ token: 't', entity: 'deals', now })).prev, null);
  r = await fetchMonth({ token: 't', entity: 'deals', now, includePrev: true });
  assert.deepStrictEqual(r.leads.daysU.SA, { '2026-11-02': 1 });          // negocio 1 (SAPreuni)
  assert.deepStrictEqual(r.leads.daysU.MA, { '2026-11-02': 1, '2026-11-03': 2 }); // negocios 2, 3 (MAPreuni) e 5
  assert.strictEqual(r.won.sellers.nycolas.val['2026-11-02'], 5000);      // valor do ganho por vendedor
  assert.strictEqual(r.won.sellers.feliep.days['2026-11-02'], 1);
  assert.deepStrictEqual(r.won.daysU.SA, { '2026-11-02': 1 });            // pelo funil
  assert.deepStrictEqual(r.won.daysU.MA, { '2026-11-02': 1 });
  assert.ok(r.diag.funnels.SAPreuni === 2 && r.diag.funnels.Extensivo === 2); // o diagnostico mostra todos os funis vistos
  // mesmo mes do ano anterior (sem dados no teste, so confere o formato)
  const y = await fetchYoy({ token: 't', entity: 'deals', now });
  assert.strictEqual(y.month, '2025-11');
  assert.deepStrictEqual(y.leadsDays, {});
  // qualquer mes e o anterior de uma vez
  const h = await fetchAggs({ token: 't', entity: 'deals', dates: [new Date(2026, 9, 1), new Date(2026, 8, 1)] });
  assert.strictEqual(h['2026-10'].leadsDays['2026-10-05'], 30);
  assert.strictEqual(h['2026-10'].wonDays['2026-10-06'], 1);
  assert.strictEqual(h['2026-09'].leadsDays['2026-09-10'], 1);
  assert.ok(h['2026-10'].leadsDays['2026-10-05'] > 0 && h['2026-09'].wonDays['2026-09-20'] === undefined);
  console.log('agendor ok');
})().catch((e) => { console.error(e); process.exit(1); });
