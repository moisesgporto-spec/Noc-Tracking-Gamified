@echo off
rem Gera a versao nova, fecha a antiga, instala por cima e abre. Metas e token ficam guardados.
cd /d "%~dp0"
if not exist node_modules (
  echo Primeira vez, instalando dependencias...
  call npm install || goto erro
)
echo [1/4] Gerando o instalador...
call npm run dist || goto erro
echo [2/4] Fechando o Leads Noc Gamificado...
taskkill /f /im "Leads Noc Gamificado.exe" >nul 2>&1
timeout /t 1 /nobreak >nul
echo [3/4] Instalando a versao nova...
start /wait "" "dist\Leads-Noc-Gamificado-Setup.exe" /S
echo [4/4] Abrindo...
start "" "%LOCALAPPDATA%\Programs\Leads Noc Gamificado\Leads Noc Gamificado.exe"
echo Pronto.
timeout /t 3 >nul
exit /b 0
:erro
echo.
echo Algo deu errado, veja a mensagem acima.
pause
