@echo off
cd /d "%~dp0"
call npm install
call npm run dist
echo.
echo Pronto. O instalador e o executavel ficam na pasta dist.
pause
