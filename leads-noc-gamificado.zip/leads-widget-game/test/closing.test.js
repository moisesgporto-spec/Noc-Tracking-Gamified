require('../lib/agendor').setGap(0);
const assert = require('assert');
const ops = require('../lib/ops');
const now = new Date(2026, 10, 11, 12);
const D = (m, d) => new Date(2026, m - 1, d, 12).toISOString();
const deal = (id, owner, funnel, status, stage, upd, value) => ({ id, dealStatus: { id: status }, owner: { name: owner }, dealStage: { name: stage, funnel: { name: funnel } }, updatedAt: upd, createdAt: D(10, 1), value });
const deals = [
  deal(1, 'Gabriel Barssalos Lehm', 'SAPreuni', 1, 'Fechamento', D(11, 9), 5794.51), // em fechamento, atualizado no mes
  deal(2, 'João Pedro de Oliveira', 'MAPreuni', 1, 'Fechamento', D(10, 20), 4930.56), // em fechamento desde outubro, entra no dia 1
  deal(3, 'Nycolas Galvão', 'SAPreuni', 2, 'Fechamento', D(11, 5), 6000), // ja ganho, conta como concluida (nao aqui)
  deal(4, 'Felipe Silva', 'MAPreuni', 1, 'Interessados', D(11, 5), 100), // outra etapa
  deal(5, 'X', 'Extensivo 2027', 1, 'Fechamento', D(11, 5), 1), // outro funil
];
global.fetch = async (url) => { const p = Number(new URL(url).searchParams.get('page')); return { ok: true, status: 200, json: async () => ({ data: p === 1 ? deals : [] }) }; };
const first = (async () => {
  const r = await ops.fetchClosing({ token: 't', now });
  assert.strictEqual(r.total, 2);
  assert.deepStrictEqual(r.daysU.SA, { '2026-11-09': 1 });
  assert.deepStrictEqual(r.daysU.MA, { '2026-11-01': 1 });
  assert.strictEqual(r.sellers.lehm.val['2026-11-09'], 5794.51);
  assert.ok(r.sellers.joao);
  console.log('closing ok');
})().catch((e) => { console.error(e.message); process.exit(1); });

// com a conversa do grupo importada: cada negocio conta no mes do anuncio; sem anuncio fica sem mes
first.then(async () => {
  const W = require('../lib/whats');
  const chat = [
    '[29/10/2026, 09:55:34] Lehm Comercial: 🛎️ _Yasmin Mandu Guedes_', '', '- EXT 27 | C1 | SA', '- R$ 5.255,51', '- *Bolsa: 20%*',
    '‎[10/11/2026, 16:24:08] Lehm Comercial: Heitor Lopes Paiva_Taxa de Matrícula.pdf • ‎1 página ‎documento omitido',
    '[10/11/2026, 16:07:43] Lehm Comercial: Maria Fernanda Gulfeto Martins_Taxa de Mtrícula.pdf • 1 página documento omitido',
    '[28/05/2026, 10:00:00] Lehm Comercial: 🛎️ _Lorena Pinheiro_', '- EXT | SA', '- R$ 100,00',
  ].join('\n');
  const anns = W.parseChat(chat).map((a) => ({ ...a, seller: 'lehm' }));
  assert.strictEqual(anns.length, 4);
  const deals2 = [
    { id: 11, title: '9864 - Yasmin mandu guedes' }, { id: 12, title: '9959 - Heitor Lopes Paiva' },
    { id: 13, title: '6329 - RESP: Marluce Gulfeto Martins (Filha: Maria Fernanda)' }, { id: 14, title: '9775 - Lorena' },
  ].map((x) => ({ ...x, dealStatus: { id: 1 }, owner: { name: 'Gabriel Barssalos Lehm' }, dealStage: { name: 'Fechamento', funnel: { name: 'SAPreuni' } }, updatedAt: D(11, 1), createdAt: D(9, 1), value: 1000 }));
  global.fetch = async (url) => { const u = new URL(url); const p = Number(u.searchParams.get('page')); if (u.pathname.endsWith('/deals')) return { ok: true, status: 200, json: async () => ({ data: p === 1 ? deals2 : [] }) }; return { ok: false, status: 404, text: async () => '' }; };
  const ops2 = require('../lib/ops');
  const r = await ops2.fetchClosing({ token: 't2', now: new Date(2026, 10, 12, 12), anns, seen: {}, seenSince: '2026-11-12', overrides: {} });
  const byId = Object.fromEntries(r.items.map((i) => [i.id, i]));
  {
    assert.strictEqual(byId[11].month, null); // fechada em outubro: fora da contagem de novembro
    assert.strictEqual(byId[11].off, true);
    assert.strictEqual(byId[12].month, '2026-11');
    assert.strictEqual(byId[13].month, '2026-11');
    assert.strictEqual(byId[14].month, null); // anuncio de maio esta fora da janela de 90 dias
    assert.strictEqual(r.total, 2);
    assert.strictEqual(r.byMonth['2026-10'], undefined);
    const r2 = await ops2.fetchClosing({ token: 't2', now: new Date(2026, 10, 12, 12), anns, seen: {}, seenSince: '2026-11-12', overrides: { 14: '2026-11' } });
    assert.strictEqual(r2.total, 3); // Lorena escolhida a mao para novembro
    const r3 = await ops2.fetchClosing({ token: 't2', now: new Date(2026, 10, 12, 12), anns, seen: {}, seenSince: '2026-11-12', overrides: { 12: 'x' } });
    assert.strictEqual(r3.total, 1); // Heitor fora da contagem (Maria Fernanda segue em novembro)
    assert.strictEqual(r3.items.find((i) => i.id === 12).src, 'fora da contagem');
  }
  console.log('closing com conversa ok');
}).catch((e) => { console.error(e.message); process.exit(1); });
