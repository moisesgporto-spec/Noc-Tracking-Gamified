@echo off
rem Remove o programa. As metas e o token ficam em %APPDATA%\LeadsNocGamificado (apague a pasta se quiser limpar tudo).
taskkill /f /im "Leads Noc Gamificado.exe" >nul 2>&1
timeout /t 1 /nobreak >nul
if exist "%LOCALAPPDATA%\Programs\Leads Noc Gamificado\Uninstall Leads Noc Gamificado.exe" (
  start /wait "" "%LOCALAPPDATA%\Programs\Leads Noc Gamificado\Uninstall Leads Noc Gamificado.exe" /S
  echo Desinstalado.
) else (
  echo Nao encontrei o programa instalado.
)
timeout /t 3 >nul
