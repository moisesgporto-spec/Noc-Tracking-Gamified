const assert = require('assert');
const H = require('../lib/holidays');
assert.strictEqual(H.ymd(H.easter(2026)), '2026-04-05');
assert.strictEqual(H.ymd(H.easter(2025)), '2025-04-20');
const p = H.presumed(2026, {});
assert.ok(p['2026-04-03'] && p['2026-04-03'].name === 'Sexta-feira Santa');
assert.ok(p['2026-02-16'] && p['2026-02-17']);            // carnaval
assert.ok(p['2026-06-04'] && p['2026-06-04'].name === 'Corpus Christi');
assert.ok(p['2026-11-02'] && p['2026-11-20'] && p['2026-12-08']);
assert.ok(!H.presumed(2026, { municipal: false })['2026-12-08']);
assert.deepStrictEqual(H.presumed(2026, { autoHolidays: false }), {});
// ajustes do usuario
const eff = H.effective([2026], { ignoredHolidays: ['2026-11-02'], extraHolidays: ['2026-11-27'] });
assert.ok(!eff.includes('2026-11-02') && eff.includes('2026-11-20') && eff.includes('2026-11-27'));
// o calculo de dias uteis enxerga os feriados
const C = require('../lib/calc');
const r = C.compute({ now: new Date(2026, 10, 4), goal: 190, count: 0, work: { saturday: false, holidays: H.effective([2026], {}) } });
assert.strictEqual(r.totalWork, 19);                       // 21 dias de semana menos 2 e 20
console.log('holidays ok');
