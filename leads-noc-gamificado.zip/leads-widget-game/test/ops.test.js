require('../lib/agendor').setGap(0);
const assert = require('assert');
const { fetchOps } = require('../lib/ops');
const now = new Date(2026, 10, 5, 12);
const D = (m, d, h = 12) => new Date(2026, m - 1, d, h).toISOString();
const deal = (id, owner, funnel, status, stage) => ({ id, dealStatus: { id: status }, owner: { name: owner }, dealStage: { name: stage, funnel: { name: funnel } }, updatedAt: D(11, 1) });
const deals = [deal(1, 'Feliep', 'MAPreuni', 1, 'Novo'), deal(2, 'Feliep', 'MAPreuni', 1, 'Visita agendada'), deal(3, 'Feliep', 'MAPreuni', 3, 'Novo'), deal(4, 'João', 'MAPreuni', 2, 'Novo'), deal(5, 'João', 'MAPreuni', 1, 'Novo'), deal(6, 'João', 'Extensivo', 1, 'Novo'), deal(7, 'Lehm', 'SAPreuni', 1, 'Novo')];
const task = (id, type, owner, due, finished, created, extra = {}) => ({ id, type: { name: type }, owner: { name: owner }, dueDate: due, finished, createdAt: created, updatedAt: D(11, 2), deal: { id: 1 }, ...extra });
const tasks = [
  task(1, 'Ligação', 'Feliep', D(11, 5), false, D(11, 1)),
  task(2, 'Ligação', 'Feliep', D(11, 5), true, D(11, 1)),
  task(3, 'Follow-up', 'Feliep', D(11, 3), false, D(11, 1)),   // atrasada
  task(4, 'Visitar', 'Atendimento Noc', D(11, 5), false, D(11, 2), { deal: { id: 2 } }),   // hoje, vendedor Feliep pelo negocio
  task(5, 'Visitar', 'Atendimento Noc', D(11, 4), true, D(11, 2), { deal: { id: 5 } }),
  task(6, 'Visitar', 'Atendimento Noc', D(11, 8), false, D(11, 3), { deal: { id: 5 } }),   // reagendada do mesmo negocio
  task(7, 'Visitar', 'Atendimento Noc', D(11, 2), false, D(11, 1), { deal: { id: 7 } }),   // atrasada, SA
  task(8, 'Visitar', 'Atendimento Noc', D(11, 5), false, D(11, 4), { deal: { id: 6 } }),   // negocio de outro funil, ignora
  task(9, 'Visita realizada', 'João', D(11, 4), true, D(11, 4), { deal: { id: 5 } }),
];
global.fetch = async (url) => {
  const u = new URL(url);
  const list = u.pathname.endsWith('/deals') ? deals : tasks;
  const page = Number(u.searchParams.get('page')), per = Number(u.searchParams.get('per_page'));
  return { ok: true, status: 200, json: async () => ({ data: list.slice((page - 1) * per, page * per) }) };
};
(async () => {
  const r = await fetchOps({ token: 't', now });
  assert.strictEqual(r.sellers.feliep.open, 2);       // nao conta perdido
  assert.strictEqual(r.sellers.joao.open, 1);         // nao conta ganho nem outro funil
  assert.strictEqual(r.sellers.lehm.open, 1);
  assert.strictEqual(r.sellers.feliep.today.ligacao, 2);
  assert.strictEqual(r.sellers.feliep.todayDone.ligacao, 1);
  assert.strictEqual(r.sellers.feliep.overdue.follow, 1);
  assert.strictEqual(r.visits.marcadas, 3);           // visitas dos negocios 2, 5 e 7 (a segunda do 5 e remarcacao)
  assert.strictEqual(r.visits.realizadas, 1);         // so "Visita realizada"
  assert.strictEqual(r.visits.remarcadas, 1);
  assert.strictEqual(r.visits.atrasadas, 1);
  assert.strictEqual(r.visits.pendentes, 2);          // hoje (negocio 2) e dia 8 (negocio 5)
  assert.strictEqual(r.visits.hoje, 1);
  assert.strictEqual(r.visits.porSdr, 3);             // todas no nome do Atendimento Noc
  assert.strictEqual(r.visits.porVendedor, 0);
  assert.strictEqual(r.visits.unit.MA.marc, 2);
  assert.strictEqual(r.visits.unit.SA.marc, 1);
  assert.strictEqual(r.sellers.feliep.today.visita, 1);
  assert.strictEqual(r.sellers.lehm.overdue.visita, 1);
  assert.deepStrictEqual(r.sellers.feliep.log['2026-11-05'], [3, 1]); // 3 com prazo hoje, 1 feita
  assert.strictEqual(r.visits.emEtapa, 1);
  console.log('ops ok');
})().catch((e) => { console.error(e.message); process.exit(1); });
