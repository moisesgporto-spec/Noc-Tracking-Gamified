# Leads Noc, widget da meta mensal

Janela pequena que fica sempre por cima de tudo, mesmo quando você clica em outro programa.
Mostra leads feitos, quanto falta, leads por dia útil e por semana, e se você está à frente ou atrás do ritmo.

## Como rodar no Windows

1. Instale o Node.js (versão LTS) em https://nodejs.org
2. Descompacte esta pasta onde quiser
3. Dê dois cliques em `Iniciar.bat` (na primeira vez ele instala o que precisa)

**Atualizar para uma versão nova (o jeito rápido):** descompacte o zip novo sobre a pasta antiga e dê dois cliques em `Atualizar.bat`. Ele gera o instalador, fecha o programa, instala por cima e abre de novo, tudo sozinho. Metas, token e fotos continuam guardados.

`Desinstalar.bat` remove o programa. Para só gerar o instalador (`dist\Leads-Noc-Setup.exe`) sem instalar, use `Gerar-instalador.bat`.

## Primeiro uso

1. Digite a meta de leads do mês e salve
2. Use -1, +1 e +5 para lançar leads manualmente (o botão desfazer remove o último)
3. Clique na engrenagem para ligar o Agendor

## Ligando o Agendor

1. No Agendor, gere seu token de API (Configurações, Integrações, API)
2. Nos ajustes do widget, marque "Puxar leads do Agendor", cole o token e escolha o que conta como lead (negócios, pessoas ou empresas criados no mês)
3. Clique em "Testar conexão" e depois em Salvar

O widget atualiza no intervalo escolhido (15 min a 2 h) e também no botão de atualizar. Os ajustes manuais somam com o que vem do Agendor.
O token fica guardado no seu computador, criptografado quando o Windows permite.

## Nova meta todo mês

Quando o mês virar, os rótulos e as metas trocam sozinhos (em dezembro aparecem "Leads de dezembro" e a meta de janeiro). As metas vêm da tabela do plano em `lib/plan.js` (leads, matrículas, metas por unidade e por vendedor, de outubro a março). Para mudar um número, edite o `lib/plan.js` e gere o app de novo, ou digite a meta do mês em Ajustes (vale só para o total geral).

## Mexendo no código

- `lib/calc.js` cálculo de ritmo, dias úteis e semana (testes em `npm test`)
- `lib/agendor.js` leitura do Agendor (leads, origem, ganhos, unidade, vendedor e valores), testes em `node test/agendor.test.js`
- `lib/plan.js` metas por mês, unidade e vendedor, e os jogadores (emoji e cor)
- `renderer/` visual da janela
- `main.js` janela, sincronização e armazenamento

## Visual

- Cartão branco e limpo, com foto no topo e a meta em destaque grande sobre a foto. A parte de baixo da foto é desfocada para o número nunca se perder.
- As 8 fotos ficam em `renderer/photos` e passam sozinhas, bem devagar. Para trocar, substitua os arquivos `01.jpg` a `08.jpg` e ajuste o enquadramento em `PHOTOS` no `renderer/renderer.js`.
- Vidro só nas barras e nos botões.
- Ao expandir, a janela cresce para os lados e para baixo em vez de esticar a lista.
- Fonte Poppins incluída no app. Se o computador tiver a Cera Pro (fonte oficial da marca) instalada, ela passa a ser usada.

## Perfis
Ao abrir pela primeira vez aparece a tela **Quem está acessando?**, no estilo Netflix. O avatar no canto do cartão volta para essa tela. O app lembra o último perfil.
- **Filipe, Administrador**: a visão completa (Marketing e Vendas, unidades, vendedores).
- **Filipe, Vendedor**, **Feliep, João, Nycolas e Lehm**: cada um vê a sua meta de matrículas como principal, a unidade como apoio e a sua rotina do dia (leads para abordar, ligações, follow-ups e visitas). No tamanho grande aparece a comparação com os outros vendedores da unidade. Não aparecem leads de marketing nem a outra unidade.
- **Gabs, SDR**: visitas marcadas contra a meta, realizadas, pendentes, atrasadas e remarcadas. Defina as metas de visitas em Ajustes.
- **Moisa, Marketing**: a visão de Marketing, sem a parte de Vendas.
- A bolinha do vendedor mostra matrículas feitas / que deveria ter hoje, a meta dele no mês e a posição na unidade. Fica verde quando está no ritmo e vermelha quando não está. A liderança conta o total de matrículas, e o Filipe fica fora dessa disputa.
- Visitas e rotina vêm das tarefas e negócios do Agendor. Como o CRM não tem as visitas 100% definidas, o app lê as tarefas do tipo Visita e conta como remarcadas as que têm "remarc" ou "reagend" no texto. Em Ajustes, o diagnóstico lista os tipos de tarefa e as etapas que ele encontrou, para ajustarmos o `taskKind` em `lib/plan.js`.

## Marketing e Vendas
O botão no topo troca a visão. Em Marketing, os leads são o número principal e as matrículas ficam no quadradinho. Em Vendas é o contrário, com as matrículas em destaque e a meta de matrículas (novembro 63, dezembro 65). As duas têm a linha vermelha do onde deveríamos estar hoje e a marca clara de amanhã.

## Três tamanhos
- **Bolinha**: mostra o número da área escolhida. Arraste para qualquer altura das laterais, clique para abrir o cartão e clique fora para voltar. Há efeito de conquista a cada matrícula e de cadastro a cada lead novo.
- **Cartão pequeno**: visão geral, com meta em destaque, status, faltam, por dia útil, por semana e o quadradinho da outra medida. Clique nele para ver a origem.
- **Grande** (botão de expandir): separação por Geral, Santo André e Mauá (cada uma com a sua meta), comparação, gráficos e a meta do próximo mês. Em Vendas aparecem os vendedores como jogadores, com emoji de iPhone (imagens em `renderer/emoji`), cor, meta e ritmo, e o botão Matrículas/Valores troca para as metas de cartão e Pix.
O botão com o círculo, no topo, volta para a bolinha.

## Meses anteriores e comparação
- O botão **Meses**, ao lado do rótulo da meta, abre a lista dos últimos 13 meses. O botão **Mês atual** volta. O primeiro acesso a um mês antigo busca os dados no Agendor e leva alguns segundos.
- O botão **Alternar para: Comparação 2025** compara com o mesmo período de 2025 em vez do mês passado (vale para o mês atual). O botão volta com **Alternar para: Mês passado**.

## Ajustes
- Metas de leads e de matrículas do mês atual e do próximo (já vêm 650 leads em dezembro e 63 matrículas em novembro).
- Atualização "Ao vivo" (a cada 1 minuto) ou a cada 5, 15, 30 e 60 minutos.
- Calendário de feriados: os nacionais, Carnaval e Corpus Christi vêm presumidos. Clique num dia para marcar ou desmarcar. Os municipais (Santo André 8/4 e Mauá 8/12) podem ser ligados ou desligados, vale conferir.

## Fotos do fundo
Em Ajustes, **Fotos do fundo**: adicione fotos da galeria para passarem atrás do cartão. As 8 fotos da Noc continuam como padrão e podem ser desligadas pelo interruptor.

## Bolinha: formato, tema e tamanho
Em Ajustes, na seção Bolinha, são treze opções. Sete redondas (Foto clara, Foto escura, Orbe escuro, Branco, Anéis duplos, Traços e Verde Noc) e seis em outros formatos (Cápsula, Cartão, Barra, Líder, Placar e Número). O Placar mostra todos os vendedores ao mesmo tempo, com as matrículas feitas contra as que cada um deveria ter hoje. O tamanho vale para todas e a mudança é imediata. O ícone do app está em `assets/` (`icon.png` e `icon.ico`); para usar o logo oficial da Noc, troque esses dois arquivos pelo logo e rode `Gerar-instalador.bat`.

## Se vendedor ou unidade não aparecer
Só contam os negócios dos funis **SAPreuni** (Santo André) e **MAPreuni** (Mauá), tanto para leads quanto para matrículas. Negócios de qualquer outro funil são ignorados. O widget identifica o vendedor pelo responsável do negócio. Em Ajustes, **Testar conexão** mostra os responsáveis e funis que o Agendor devolveu. Se algum nome estiver diferente do esperado, ajuste o campo `match` em `lib/plan.js`. Ganhos sem vendedor reconhecido aparecem como aviso no painel de vendedores. Os valores somam o valor dos negócios ganhos.

## Meta de visitas da SDR

A tabela de meta e base de visitas (OUT a MAR) já vem como padrão. Usamos a primeira tabela como Santo André, a segunda como Mauá e a terceira como total. A meta da Gabs é a do total. Dá para sobrescrever o mês em Ajustes.

## Quem marcou a visita

Como os vendedores também marcam visita por ligação, a visão da Gabs separa as visitas marcadas pela SDR, pelos vendedores e as sem origem no CRM. A origem vem do campo de quem criou a tarefa no Agendor. Se o Agendor não devolver esse campo, tudo cai em "Sem origem no CRM". O diagnóstico em Ajustes mostra o que o Agendor trouxe.

## Duas edições

Esta pasta é a edição normal (Leads Noc). A edição "Leads Noc Gamificado" é a mesma coisa com a camada de gamificação, e vem em outro zip. As duas têm nome, instalador e pasta de dados próprios, então dá para instalar as duas ao mesmo tempo. A gamificada copia o token da edição normal na primeira abertura. Metas e fotos não são copiadas.

Cada edição tem seu Atualizar.bat e seu Desinstalar.bat.

## Ajustes recentes

1. Perfis na ordem Moisa, Filipe, João, Lehm, Feliep, Nycolas, Gabs e ADM. O ADM é a visão geral, usada por você e pelo Filipe. O Filipe vendedor aparece como Líder de Vendas.
2. Nos estilos Líder e Placar, Moisa e Gabs veem só os próprios números. O Placar da Moisa e do ADM mostra os 4 vendedores. A largura do Placar acompanha quantas pessoas aparecem.
3. Visitas da Gabs: contamos tarefas do tipo Visita nos funis SAPreuni e MAPreuni juntos. Se o Agendor não tiver tarefas de visita, passamos a contar os negócios dos dois funis que entraram em etapa de visita no mês, e a tela avisa isso.

## ADM: aba Equipe

No perfil ADM há uma terceira aba, Equipe, ao lado de Marketing e Vendas. Nela dá para alternar entre Matrículas e Valores, ver um gráfico com uma linha por vendedor (cada um com sua cor e seu ícone), o ritmo da soma das metas e o quadro de cada vendedor com feito, meta e ideal de hoje. As bolinhas de "Quem aparece" ligam e desligam cada pessoa, inclusive o Filipe, e a escolha fica salva.

## ADM: aba SDR

No perfil ADM há uma quarta aba, SDR, com a mesma visão de visitas da Gabs (marcadas, realizadas, quem marcou e por unidade). No modo compacto as abas do ADM ficam logo abaixo da foto.

## Ícone do app

Em Ajustes, a seção Ícone do app tem o verde da Noc e outras variações, o ícone de cada perfil e a opção Do perfil em uso, que troca sozinha quando você muda de perfil. O ícone vale para a barra de tarefas, o atalho da área de trabalho (criado se não existir), o menu Iniciar e o app fixado. Se o desenho do atalho não mudar na hora, aperte F5 na área de trabalho.

## Matrículas feitas e concluídas

Matrícula concluída é a que já está como ganho no Agendor. Matrícula feita soma as concluídas com os negócios na etapa Fechamento dos funis SAPreuni e MAPreuni (a taxa já foi paga), cada um no mês em que foi fechado.

O Agendor não informa quando um negócio mudou de etapa, então o mês de cada negócio em Fechamento vem, nesta ordem, de:

1. O mês escolhido à mão em Ajustes, Matrículas em fechamento.
2. O anúncio no grupo de vendas, pela conversa exportada do WhatsApp (sem mídia) e importada em Ajustes. Quem foi anunciado num mês anterior sai da contagem sozinho, porque já contou no mês em que fechou. Vale a mensagem com o nome e o valor (sino ou nome em negrito) ou o comprovante "Nome_Taxa de Matrícula.pdf", dos últimos 90 dias.
3. O dia em que o app viu o negócio entrar em Fechamento (só para quem entrou depois que o app começou a acompanhar).

Depois de importar a conversa, quem não tiver mês aparece em vermelho na lista e só conta quando alguém escolher. Clicar no nome tira a pessoa da contagem (e clicar de novo devolve). A seção de importação e a lista ficam disponíveis só em novembro de 2026; de dezembro em diante o app acompanha sozinho quem entra em Fechamento. Sem conversa importada, todo negócio em Fechamento conta no mês atual. Os meses anteriores também mostram os negócios em Fechamento daquele mês. Nada da conversa sai do computador.


Cada vendedor vê no topo de Ajustes a lista "Suas matrículas do mês" (ganhos e Fechamento que contam para ele). Clicar no nome tira da contagem quem não fechou no mês, e clicar de novo devolve. Alguns nomes conferidos em novembro de 2026 já vêm fora da contagem por padrão.
## Gamificação (só nesta edição)

Aparece apenas no perfil de cada pessoa (vendedores, Gabs e Moisa), nunca no ADM.

1. Missão do dia: faixa com o progresso do dia e a sequência de dias seguidos (chama).
2. Níveis na barra da meta: Bronze (25%), Prata (50%), Ouro (75%) e Diamante (100%).
3. Conquistas: seis ícones simples na visão expandida (primeiro resultado, no ritmo, semana batida, 5 dias seguidos, liderança e meta batida).
4. Meu ritmo: no perfil do vendedor, compara o desempenho dele com o ideal de hoje (matrículas, ligações, follow-ups e visitas).
5. Versus: botão ao lado de Meu ritmo que coloca o vendedor contra o outro da unidade, com quem está ganhando, barra de cabo de guerra e placar por categoria.
6. Aviso na bolinha quando uma conquista nova é desbloqueada.
