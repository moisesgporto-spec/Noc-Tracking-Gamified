const assert = require('assert');
const C = require('../lib/calc');
const work = { saturday: false, holidays: [] };

// novembro de 2026 tem 30 dias, comeca no domingo. Dias uteis seg-sex = 21
let r = C.compute({ now: new Date(2026, 10, 4), goal: 300, count: 100, work });
assert.strictEqual(r.totalWork, 21);
assert.strictEqual(r.elapsedWork, 2);            // 2 e 3 de novembro
assert.strictEqual(r.remainingWork, 19);         // de 4 a 30, inclusive hoje
assert.strictEqual(r.remaining, 200);
assert.strictEqual(r.perDay, Math.ceil(200 / 19));
assert.strictEqual(r.perWeek, Math.ceil(200 / (19 / 5)));
assert.strictEqual(r.elapsedIncl, 3);               // 2, 3 e 4 de novembro
assert.strictEqual(r.diff, Math.round(100 - (300 * 3) / 21));
assert.ok(Math.abs(r.expected - (300 * 3) / 21) < 1e-9);
assert.ok(Math.abs(r.expectedNext - (300 * 4) / 21) < 1e-9);
assert.strictEqual(r.nextLabel, 'amanhã');

// meta batida
r = C.compute({ now: new Date(2026, 10, 4), goal: 300, count: 320, work });
assert.ok(r.done); assert.strictEqual(r.perDay, 0); assert.strictEqual(r.remaining, 0);

// feriado e sabado
r = C.compute({ now: new Date(2026, 10, 4), goal: 300, count: 0, work: { saturday: true, holidays: ['2026-11-20'] } });
assert.strictEqual(r.totalWork, 25 - 1);

// ultimo dia, faltando leads
r = C.compute({ now: new Date(2026, 10, 30), goal: 300, count: 250, work });
assert.strictEqual(r.remainingWork, 1); assert.strictEqual(r.perDay, 50); assert.strictEqual(r.perWeek, 50);

// serie diaria e soma manual
const log = [{ ts: new Date(2026, 10, 4, 10).getTime(), delta: 3 }, { ts: new Date(2026, 9, 31, 10).getTime(), delta: 9 }];
assert.strictEqual(C.manualSum(log, '2026-11'), 3);
const s = C.dailySeries(new Date(2026, 10, 4), { '2026-11-02': 5, '2026-10-31': 7 }, log);
assert.strictEqual(s.length, 30); assert.strictEqual(s[1], 5); assert.strictEqual(s[3], 3);
assert.strictEqual(C.weekCount(new Date(2026, 10, 4), s), 8); // seg 2 a qua 4
assert.deepStrictEqual(C.cumulative([1, 2, 0, 3]), [1, 3, 3, 6]);
assert.strictEqual(C.sumUpTo([1, 2, 3, 4], 2), 3);
assert.strictEqual(C.sumUpTo([1, 2, 3, 4], 31), 10); // mes mais curto usa o total
assert.strictEqual(C.monthKey(C.prevMonthDate(new Date(2026, 0, 15))), '2025-12');
// exemplo do uso: dia util 3 com 10 por dia, hoje 30 e amanha 40
r = C.compute({ now: new Date(2026, 10, 4), goal: 210, count: 45, work });
assert.strictEqual(Math.round(r.expected), 30); assert.strictEqual(Math.round(r.expectedNext), 40); assert.strictEqual(r.diff, 15);
// sexta-feira, proximo dia util e segunda
r = C.compute({ now: new Date(2026, 10, 6), goal: 210, count: 0, work });
assert.strictEqual(r.nextLabel, 'seg');
// ultimo dia do mes, nao ha proximo
r = C.compute({ now: new Date(2026, 10, 30), goal: 210, count: 0, work });
assert.strictEqual(r.nextLabel, null); assert.strictEqual(Math.round(r.expected), 210);
console.log('calc ok');
