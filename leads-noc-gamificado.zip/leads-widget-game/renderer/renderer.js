const $ = (id) => document.getElementById(id);
let S = null;
let view = 'main'; // main | settings
let mode = 'compact'; // bubble | compact | expanded
let testMsg = '';
let chartMetric = 'leads'; // leads | won
let chartMode = 'acc'; // acc (acumulado) | day (por dia)
let originTab = 'leads'; // leads | won
let unitSel = 'ALL'; // ALL | SA | MA (so no cartao grande)
let cmpMode = 'prev'; // prev (mes passado) | yoy (mesmo mes de 2025)
let sellerMetric = 'mat'; // mat | val
let viewKey = null; // mes que esta sendo visto (null = mes atual)
let menuOpen = false;
let flip = false;
let draft = null; // rascunho de feriados nos ajustes
let calMonth = null;
let lastShape = '';
let snapNext = false; // na proxima vez em bolinha, encosta na lateral
let fxUp = false; // aviso aparece acima da bolinha (metade de baixo da tela)
let seen = null; // ultimo total de leads e ganhos visto, para detectar novidades
let fxToastOn = false;
let ringPct = null; // fracao do anel mostrada no momento
let fromBubble = false; // o cartao foi aberto pela bolinha
const bubSize = () => Math.max(48, Math.min(140, Number(S && S.bubble && S.bubble.size) || 80));
const bubTheme = () => (prof().type === 'seller' && !(S.bubble && S.bubble.themeSet) ? 'lider' : (S && S.bubble && THEMES[S.bubble.theme] ? S.bubble.theme : 'foto-clara'));
const prof = () => (S && S.ui && Plan.profileById(S.ui.profile)) || Plan.profileById('adm');
const area = () => { const t = prof().type; return t === 'seller' || t === 'sdr' ? 'vendas' : t === 'mkt' ? 'mkt' : (S && S.ui && ['vendas', 'equipe', 'sdr'].includes(S.ui.area) ? S.ui.area : 'mkt'); };
// visao de visitas: o proprio perfil da SDR ou o ADM na aba SDR
const sdrView = () => prof().type === 'sdr' || (prof().type === 'admin' && area() === 'sdr');
const sdrFace = () => (prof().type === 'admin' ? Plan.profileById('gabs') : prof());
const sellerOf = (p) => Plan.SELLERS.find((s) => s.id === (p || prof()).seller) || null;
const opsNow = () => (S && S.ops && S.ops.month === Calc.monthKey(new Date()) ? S.ops : null);
const pad2 = (n) => String(n).padStart(2, '0');

const fmt = (n) => Math.round(n).toLocaleString('pt-BR');
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const sumVals = (o) => Object.values(o || {}).reduce((a, n) => a + n, 0);
const fmtMoney = (n) => (n >= 1e6 ? (n / 1e6).toFixed(2).replace('.', ',') + ' mi' : n >= 1000 ? (n / 1000).toFixed(1).replace('.', ',').replace(',0', '') + ' mil' : fmt(n));
const brl = (n) => 'R$ ' + fmtMoney(n);
const monthName = (d) => d.toLocaleDateString('pt-BR', { month: 'long' });
const UNIT_NAME = { ALL: 'Geral', SA: 'Santo André', MA: 'Mauá' };


// avatar do jogador com o emoji de iPhone (imagem em renderer/emoji)
const avHTML = (s, cls) => `<div class="av ${cls || ''}" style="--c:${s.color}"><img src="${s.img}" alt="${esc(s.name)}" draggable="false"></div>`;
const ICON = {
  gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
  expand: '<svg viewBox="0 0 24 24"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg>',
  shrink: '<svg viewBox="0 0 24 24"><path d="M20 10h-6V4M4 14h6v6M14 10l7-7M3 21l7-7"/></svg>',
  min: '<svg viewBox="0 0 24 24"><path d="M5 12h14"/></svg>',
  close: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  cal: '<svg viewBox="0 0 24 24"><rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>',
  swap: '<svg viewBox="0 0 24 24"><path d="M7 4L3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7"/></svg>',
  back: '<svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg>',
  next: '<svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg>',
  dot: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="7"/></svg>',
  undo: '<svg viewBox="0 0 24 24"><path d="M3 7v6h6"/><path d="M3.5 13a9 9 0 1 0 2.2-6.2"/></svg>',
  refresh: '<svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 3v6h-6"/></svg>',
};

/* ------------------------------------------------------------------ dados */
function workCfg(d) {
  return { saturday: !!S.work.saturday, holidays: Holidays.effective([d.getFullYear(), d.getFullYear() + 1], S.work) };
}
const sortO = (o) => Object.entries(o || {}).filter(([, n]) => n > 0).sort((a, b) => b[1] - a[1]);
const effUnit = () => {
  const p = prof();
  if (p.type === 'seller') return sellerOf(p).unit; // vendedor so ve a propria unidade
  if (sdrView()) return 'ALL';
  return mode === 'expanded' && view === 'main' ? unitSel : 'ALL';
};

// Tudo que a tela precisa de um mes, de uma unidade. P e a medida principal (leads no
// Marketing, matriculas em Vendas) e X a secundaria.
function metrics(realNow) {
  const curKey = Calc.monthKey(realNow);
  const key = viewKey || curKey;
  const isCur = key === curKey;
  const [vy, vm] = key.split('-').map(Number);
  const now = isCur ? realNow : new Date(vy, vm, 0, 12); // mes passado: ultimo dia
  const unit = effUnit();
  const wk = workCfg(now);
  const on = !!S.agendor.enabled;
  const mName = monthName(new Date(vy, vm - 1, 1));

  // fonte dos numeros: cache ao vivo (mes atual) ou mes carregado sob demanda
  let A = null;
  let loading = false;
  if (on) {
    if (isCur && S.cache.month === key) {
      const w = S.cache.won || {};
      A = { leadsDays: S.cache.days || {}, leadsDaysU: S.cache.daysU || { SA: {}, MA: {} }, wonDays: w.days || {}, wonDaysU: w.daysU || { SA: {}, MA: {} }, sellers: w.sellers || {}, origins: S.cache.origins || {}, wonOrigins: w.origins || {} };
    } else if (!isCur && S.history && S.history[key]) A = { ...S.history[key], origins: null, wonOrigins: null };
    else if (!isCur) loading = true;
  }
  const dayOf = (days, daysU) => (unit === 'ALL' ? days : (daysU && daysU[unit]) || {});

  // leads
  const lGoal = unit === 'ALL' ? (S.goals[key] || Plan.meta('leads', 'ALL', key)) : Plan.meta('leads', unit, key);
  const lDays = A ? dayOf(A.leadsDays, A.leadsDaysU) : {};
  const manualLog = unit === 'ALL' ? S.manualLog : [];
  const lCount = Math.max(0, sumVals(lDays) + Calc.manualSum(manualLog, key));
  const lSeries = Calc.dailySeries(now, lDays, manualLog);
  const L = { kind: 'leads', noun: 'leads', goal: lGoal, base: Plan.base('leads', unit, key), count: lCount, series: lSeries, c: Calc.compute({ now, goal: lGoal, count: lCount, work: wk }) };

  // matriculas (ganhos)
  const wGoal = unit === 'ALL' ? ((S.winGoals || {})[key] || Plan.meta('mat', 'ALL', key)) : Plan.meta('mat', unit, key);
  const wDays = A ? dayOf(A.wonDays, A.wonDaysU) : {};
  const wCount = A ? sumVals(wDays) : null;
  const wSeries = Calc.dailySeries(now, wDays, []);
  const W = { kind: 'won', noun: 'matrículas', goal: wGoal, base: Plan.base('mat', unit, key), count: wCount, series: wSeries, c: Calc.compute({ now, goal: wGoal, count: wCount || 0, work: wk }) };

  const sales = area() !== 'mkt';
  const P = sales ? W : L, X = sales ? L : W;

  // origens (so do mes atual e da visao geral)
  const origins = { ...(A && A.origins && unit === 'ALL' ? A.origins : {}) };
  const man = Calc.manualSum(manualLog, key);
  if (man > 0) origins['Manual'] = (origins['Manual'] || 0) + man;
  const leadsOrigins = sortO(origins);
  const wonOrigins = A && A.wonOrigins && unit === 'ALL' ? sortO(A.wonOrigins) : [];

  // comparacao: mes anterior ou o mesmo mes de 2025
  const yoy = cmpMode === 'yoy' && isCur;
  const prevDate = new Date(vy, vm - 2, 1);
  const prevKey = Calc.monthKey(prevDate);
  let src = null, refDate = prevDate, label = monthName(prevDate);
  if (yoy) {
    refDate = new Date(vy - 1, vm - 1, 1); label = `${mName} de ${vy - 1}`;
    const y = S.cache.yoy;
    if (on && y && y.month === Calc.monthKey(refDate)) src = y;
  } else if (on) {
    if (isCur) src = S.cache.prev && S.cache.prev.month === prevKey ? S.cache.prev : null;
    else src = S.history && S.history[key] ? S.history[key].prevAgg : null;
  }
  const cDays = (a, au) => (src ? (unit === 'ALL' ? src[a] : (src[au] && src[au][unit]) || {}) : {});
  const pLeads = Calc.monthSeries(refDate, cDays('leadsDays', 'leadsDaysU'), unit === 'ALL' && !yoy && isCur ? S.manualLog : []);
  const pWon = Calc.monthSeries(refDate, cDays('wonDays', 'wonDaysU'), []);
  const day = now.getDate();
  const cmp = {
    ready: !!(on && src), yoy, label, unavailable: cmpMode === 'yoy' && !isCur,
    prevLeads: Calc.sumUpTo(pLeads, day), prevWon: Calc.sumUpTo(pWon, day), curLeads: lCount, curWon: wCount,
    prevLeadsSeries: pLeads, prevWonSeries: pWon, wonSeries: wSeries,
  };

  // vendedores
  const mkSeller = (sl) => {
    const ag = A && A.sellers && A.sellers[sl.id];
    return { ...sl, days: ag ? ag.days : {}, valDays: ag ? ag.val : {}, mat: ag ? sumVals(ag.days) : 0, val: ag ? sumVals(ag.val) : 0, goalMat: Plan.sellerGoal(sl, key, 'mat'), goalVal: Plan.sellerGoal(sl, key, 'val') };
  };
  const sellers = Plan.sellersOf(unit).map(mkSeller);
  const allSellers = unit === 'ALL' ? sellers : Plan.sellersOf('ALL').map(mkSeller); // placar do marketing e do ADM mostra os 4
  const identified = sellers.reduce((a, s) => a + s.mat, 0);
  const leader = sellers.filter((s) => s.mat > 0 && s.compete !== false).sort((a, b) => b.mat - a.mat)[0] || null;

  // mes seguinte (ex.: dezembro)
  const nd = new Date(vy, vm, 1);
  const nKey = Calc.monthKey(nd);
  const next = {
    label: monthName(nd), key: nKey,
    leads: unit === 'ALL' ? (S.goals[nKey] || Plan.meta('leads', 'ALL', nKey)) : Plan.meta('leads', unit, nKey),
    won: unit === 'ALL' ? ((S.winGoals || {})[nKey] || Plan.meta('mat', 'ALL', nKey)) : Plan.meta('mat', unit, nKey),
    leadsBase: Plan.base('leads', unit, nKey), wonBase: Plan.base('mat', unit, nKey),
    days: Calc.compute({ now: nd, goal: 1, count: 0, work: workCfg(nd) }).totalWork,
  };
  return { key, isCur, now, unit, mName, vy, loading, L, W, P, X, c: P.c, leadsOrigins, wonOrigins, cmp, sellers, allSellers, leader, unidentified: wCount === null ? 0 : Math.max(0, (unit === 'ALL' ? wCount : wCount) - identified), next, sales };
}

function statusInfo(c, now, noun) {
  if (c.done) return { title: 'Meta batida', sub: `${fmt(c.count - c.goal)} ${noun} além do objetivo.`, color: 'var(--noc)' };
  if (c.monthOver) return { title: 'Mês encerrado', sub: `Faltaram ${fmt(c.remaining)} ${noun} para a meta.`, color: 'var(--pink)' };
  if (c.diff > 0) return { title: 'À frente do ritmo', sub: `${fmt(c.diff)} ${noun} acima da meta de hoje, que é ${fmt(c.expected)}.`, color: 'var(--noc)' };
  if (c.diff === 0) return { title: 'No ritmo', sub: `Exatamente na meta de hoje, ${fmt(c.expected)} ${noun}.`, color: 'var(--noc)' };
  if (c.diff > -Math.max(2, c.goal * 0.03)) return { title: 'Quase no ritmo', sub: `${fmt(-c.diff)} ${noun} para bater a meta de hoje, ${fmt(c.expected)}.`, color: 'var(--wine)' };
  return { title: 'Atrás do ritmo', sub: `${fmt(-c.diff)} ${noun} abaixo da meta de hoje, que é ${fmt(c.expected)}.`, color: 'var(--pink)' };
}

/* ---------------------------------------------------------------- graficos */
function smooth(pts) {
  if (pts.length === 1) return `M${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)}`;
  if (pts.length < 3) return pts.map((p, i) => `${i ? 'L' : 'M'}${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
  let d = `M${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
    d += ` C${(p1.x + (p2.x - p0.x) / 6).toFixed(1)} ${(p1.y + (p2.y - p0.y) / 6).toFixed(1)} ${(p2.x - (p3.x - p1.x) / 6).toFixed(1)} ${(p2.y - (p3.y - p1.y) / 6).toFixed(1)} ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`;
  }
  return d;
}

function stretch(cum, N) { return Array.from({ length: N }, (_, i) => cum[Math.min(i, cum.length - 1)] || 0); }

function accChart({ cur, prev, todayIdx, goal, showPace, cutPrev }) {
  const W = 400, H = 168, pl = 28, pr = 8, pt = 10, pb = 20;
  const N = cur.length;
  const cc = Calc.cumulative(cur);
  const cp = stretch(Calc.cumulative(prev), N);
  const ymax = Math.max(1, cc[todayIdx], cp[N - 1], showPace && goal > 0 ? goal * 0.6 : 0) * 1.1;
  const x = (i) => pl + (i / Math.max(1, N - 1)) * (W - pl - pr);
  const y = (v) => H - pb - (v / ymax) * (H - pb - pt);
  const curPts = cc.slice(0, todayIdx + 1).map((v, i) => ({ x: x(i), y: y(v) }));
  const line = smooth(curPts);
  const area = `${line} L${x(todayIdx).toFixed(1)} ${y(0)} L${x(0).toFixed(1)} ${y(0)} Z`;
  let out = `<defs><linearGradient id="ag" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0aa874" stop-opacity=".30"/><stop offset="1" stop-color="#0aa874" stop-opacity="0"/></linearGradient>
    <clipPath id="cp"><rect x="${pl}" y="0" width="${W - pl}" height="${H - pb}"/></clipPath></defs>`;
  [0, 0.5, 1].forEach((f) => {
    const v = (ymax / 1.1) * f;
    out += `<line x1="${pl}" x2="${W - pr}" y1="${y(v)}" y2="${y(v)}" stroke="#e1e0d8" stroke-width="1" ${f ? 'stroke-dasharray="2 4"' : ''}/>
            <text x="${pl - 6}" y="${y(v) + 3}" fill="#8b928d" font-size="9" text-anchor="end">${fmt(v)}</text>`;
  });
  if (showPace && goal > 0) out += `<path clip-path="url(#cp)" d="M${x(0)} ${y(0)} L${x(N - 1)} ${y(goal)}" stroke="#e8366b" stroke-width="1.3" stroke-dasharray="1.5 4" stroke-linecap="round" fill="none"/>`;
  out += `<path d="${smooth(cp.slice(0, cutPrev ? todayIdx + 1 : N).map((v, i) => ({ x: x(i), y: y(v) })))}" stroke="#7d8480" stroke-width="1.4" stroke-dasharray="5 4" fill="none" stroke-linecap="round"/>`;
  out += `<path d="${area}" fill="url(#ag)"/><path d="${line}" stroke="#0aa874" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
  out += `<circle cx="${x(todayIdx)}" cy="${y(cp[todayIdx])}" r="3.4" fill="#7d8480" stroke="#f3f2ed" stroke-width="1.5"/>`;
  out += `<circle cx="${x(todayIdx)}" cy="${y(cc[todayIdx])}" r="7" fill="rgba(10,168,116,.18)"/><circle cx="${x(todayIdx)}" cy="${y(cc[todayIdx])}" r="4" fill="#0aa874" stroke="#fff" stroke-width="1.5"/>`;
  const lab = (i, a) => `<text x="${x(i)}" y="${H - 5}" fill="#8b928d" font-size="9" text-anchor="${a}">${i + 1}</text>`;
  return `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">${out}${lab(0, 'start')}${lab(todayIdx, 'middle')}${lab(N - 1, 'end')}</svg>`;
}

// barras por dia, planas
function dayChart({ series, todayIdx, avg }) {
  const W = 400, H = 168, pl = 6, pr = 6, pt = 10, pb = 20;
  const N = series.length;
  const ymax = Math.max(1, ...series, avg ? Math.ceil(avg * 1.25) : 0) * 1.08;
  const slot = (W - pl - pr) / N;
  const bw = Math.max(3, slot - 3);
  const y = (v) => H - pb - (v / ymax) * (H - pb - pt);
  let out = `<line x1="${pl}" x2="${W - pr}" y1="${y(0)}" y2="${y(0)}" stroke="#e1e0d8"/>`;
  series.forEach((v, i) => {
    const x = pl + i * slot + (slot - bw) / 2;
    if (i > todayIdx) { out += `<rect x="${x.toFixed(1)}" y="${y(0) - 3}" width="${bw.toFixed(1)}" height="3" rx="1.5" fill="#ececee"/>`; return; }
    const h = Math.max(3, y(0) - y(v));
    out += `<rect x="${x.toFixed(1)}" y="${(y(0) - h).toFixed(1)}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" rx="${Math.min(4, bw / 2).toFixed(1)}" fill="${i === todayIdx ? '#0aa874' : '#8fe0bf'}"/>`;
  });
  if (avg) out += `<line x1="${pl}" x2="${W - pr}" y1="${y(avg)}" y2="${y(avg)}" stroke="#e8366b" stroke-width="1.3" stroke-dasharray="1.5 4" stroke-linecap="round"/>`;
  const lab = (i, a) => `<text x="${pl + i * slot + slot / 2}" y="${H - 5}" fill="#8b928d" font-size="9" text-anchor="${a}">${i + 1}</text>`;
  return `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">${out}${lab(0, 'start')}${lab(todayIdx, 'middle')}${lab(N - 1, 'end')}</svg>`;
}

/* ---------------------------------------------------------------- origens */
function originColors(rows) {
  const base = ['#0aa874', '#2fd08f', '#2e3532', '#e8366b', '#7d2a55'];
  let k = 0;
  return rows.map(([name]) => {
    if (name === 'Sem origem') return '#b3bdb6';
    if (name === 'Outras') return '#d6dcd7';
    if (name === 'Manual') return '#7d2a55';
    return base[k++ % base.length];
  });
}
function originBlock(list, total, max) {
  if (!list.length) return '<div class="hint">Sem dados de origem ainda.</div>';
  let rows = list.slice(0, max);
  if (list.length > max) rows.push(['Outras', list.slice(max).reduce((a, [, n]) => a + n, 0)]);
  const colors = originColors(rows);
  const sum = rows.reduce((a, [, n]) => a + n, 0) || 1;
  return `<div class="sbar">${rows.map(([, n], i) => `<i style="flex:${n} 1 0;background:${colors[i]}" title="${fmt(n)}"></i>`).join('')}</div>
    <ul class="olist">${rows.map(([name, n], i) => `
      <li title="${esc(name)}"><i style="background:${colors[i]}"></i><span class="nm">${esc(name)}</span><b>${fmt(n)}</b><em>${Math.round((n / (total || sum)) * 100)}%</em></li>`).join('')}</ul>`;
}

/* ---------------------------------------------------------------- templates */
function toolsHTML() {
  const ex = mode === 'expanded';
  return `<div class="tools">
    <button class="tb" id="bExpand" title="${ex ? 'Voltar ao cartão pequeno' : 'Expandir'}">${ex ? ICON.shrink : ICON.expand}</button>
    <button class="tb" id="bSet" title="Ajustes">${ICON.gear}</button>
    <button class="tb" id="bBubble" title="Virar bolinha">${ICON.dot}</button>
    <button class="tb" id="bClose" title="Fechar">${ICON.close}</button>
  </div>`;
}
function areaSeg() {
  const a = area();
  return `<div class="aseg"><button class="${a === 'mkt' ? 'on' : ''}" id="aMkt">Marketing</button><button class="${a === 'vendas' ? 'on' : ''}" id="aVen">Vendas</button><button class="${a === 'equipe' ? 'on' : ''}" id="aEq">Equipe</button><button class="${a === 'sdr' ? 'on' : ''}" id="aSdr">SDR</button></div>`;
}
function monthMenu(real) {
  const cur = Calc.monthKey(real);
  let h = '';
  for (let i = 0; i < 13; i++) {
    const d = new Date(real.getFullYear(), real.getMonth() - i, 1);
    const k = Calc.monthKey(d);
    h += `<button class="mi ${k === (viewKey || cur) ? 'on' : ''}" data-mk="${k}">${esc(cap(monthName(d)))} ${d.getFullYear()}${i === 0 ? '<em>atual</em>' : ''}</button>`;
  }
  return `<div class="mmenu" id="mmenu">${h}</div>`;
}

function barHTML(c, ticks, g) {
  const pct = Math.min(100, c.pct * 100);
  // marca rosa = meta acumulada de hoje, marca clara = meta de amanhã
  const tick = Math.min(100, (c.expected / c.goal) * 100);
  const tickNext = c.nextLabel ? Math.min(100, (c.expectedNext / c.goal) * 100) : null;
  const marks = g ? [25, 50, 75].map((v) => `<i class="bar-ms ${pct >= v ? 'on' : ''}" style="left:${v}%"></i>`).join('') : '';
  return `<div class="bar"><div class="bar-fill" style="width:${pct}%"></div>${marks}${ticks && tickNext !== null ? `<div class="bar-tick next" style="left:calc(${tickNext}% - 1px)" title="Meta acumulada de ${esc(c.nextLabel)}, ${fmt(c.expectedNext)}"></div>` : ''}${ticks ? `<div class="bar-tick" style="left:calc(${tick}% - 1px)" title="Meta acumulada de hoje, ${fmt(c.expected)}"></div>` : ''}</div>`;
}

function heroMain(now, m) {
  const { P, c, sales } = m;
  const past = !m.isCur;
  const label = m.label || (sales ? `Matrículas de ${m.mName}` : `Meta de ${m.mName}`);
  const num = P.count;
  const hnum = num === null ? '<b>-</b><span class="nogoal">ligue o Agendor</span>'
    : c.goal ? `<b>${fmt(num)}</b><i>/ ${fmt(c.goal)}</i>` : `<b>${fmt(num)}</b><span class="nogoal">sem meta definida</span>`;
  return `
    <div class="topbar">${topLeft(m)}${toolsHTML()}</div>
    <div>
      <div class="hlabel"><span>${esc(label)}${past ? ' · encerrado' : ''}</span>${m.noMonths ? '' : `<button class="mbtn ${past ? 'back' : ''}" id="bMonth" title="Ver meses anteriores">${past ? ICON.back : ICON.cal}<span>${past ? 'Mês atual' : 'Meses'}</span></button>`}</div>
      <div class="hrow">
        <div class="hnum">${hnum}</div>
        ${!sales && m.isCur ? '<button class="plus" id="bP1" title="Somar 1 lead">+1<span class="lbl-long">&nbsp;lead</span></button>' : ''}
      </div>
      ${c.goal && num !== null ? `${barHTML(c, m.isCur, m.game)}
      <div class="hmeta"><span><b>${Math.round(c.pct * 100)}%</b> da meta${m.game ? ` <em class="lvl">· ${m.game.levelName ? 'Nível ' + m.game.levelName : 'rumo ao Bronze'}</em>` : ''}</span><span>${m.isCur ? `<u></u>hoje ${fmt(c.expected)}${c.nextLabel ? ` <s></s> ${esc(c.nextLabel)} ${fmt(c.expectedNext)}` : ''}` : (m.loading ? 'Carregando do Agendor...' : '')}</span></div>` : ''}
    </div>`;
}

function syncLine() {
  if (S.loadingKey) return [`Carregando ${S.loadingKey} do Agendor...`, ''];
  if (!S.agendor.enabled) return ['Modo manual', ''];
  if (S.syncing) return ['Atualizando do Agendor...', ''];
  if (S.cache.error) return [S.cache.error, 'err'];
  const live = Number(S.agendor.intervalMin) <= 2 ? 'Ao vivo, ' : '';
  if (S.cache.syncedAt) return [`${live}Agendor atualizado às ${new Date(S.cache.syncedAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`, ''];
  return ['Aguardando o Agendor', ''];
}
function footHTML(m) {
  const [txt, cls] = syncLine();
  const manual = !m.sales && m.isCur;
  return `<div class="foot"><span class="sync ${cls}" title="${esc(txt)}">${esc(txt)}</span>
    ${manual ? `<button class="pbtn round" id="bM1" title="Tirar 1 lead">-1</button>
    <button class="pbtn round" id="bP5" title="Somar 5 leads">+5</button>
    <button class="pbtn round" id="bUndo" title="Desfazer o último ajuste manual">${ICON.undo}</button>` : ''}
    <button class="pbtn round ${S.syncing || S.loadingKey ? 'spin' : ''}" id="bSync" title="Atualizar agora">${ICON.refresh}</button></div>`;
}

function statsHTML(P) {
  const c = P.c;
  return `<div class="stats">
    <div><b>${fmt(c.remaining)}</b><span>faltam</span></div>
    <div><b>${fmt(c.perDay)}</b><span>por dia útil</span></div>
    <div><b>${fmt(c.perWeek)}</b><span>por semana</span></div></div>`;
}

// cartao da medida secundaria. No compacto e quadrado e, ao clicar, mostra a origem.
function miniCard(m, wide) {
  const X = m.X;
  const noun = X.kind === 'won' ? `${X.count === 1 ? 'ganho' : 'ganhos'} no mês` : 'leads no mês';
  const list = X.kind === 'won' ? m.wonOrigins : m.leadsOrigins;
  if (X.count === null) return `<div class="gcard ${wide ? 'wide' : ''}" style="cursor:default"><div><b>-</b><span>${noun}</span></div><small>ligue o Agendor</small></div>`;
  if (!wide && flip) {
    const rows = list.slice(0, 4);
    return `<button class="gcard flip" id="gCard" title="Voltar"><div class="lbl" style="margin:0">Origem</div>
      <div>${rows.length ? rows.map(([n, v]) => `<div class="olr"><span>${esc(n)}</span><b>${fmt(v)}</b></div>`).join('') : '<small>sem dados ainda</small>'}</div></button>`;
  }
  const pct = X.goal ? Math.min(100, (X.count / X.goal) * 100) : 0;
  const conv = X.kind === 'won' && m.L.count > 0 ? `${(X.count / m.L.count * 100).toFixed(1).replace('.', ',')}% dos leads` : '';
  const inner = `<div><b>${fmt(X.count)}${wide && X.goal ? `<em>de ${fmt(X.goal)}</em>` : ''}</b><span>${noun}</span></div>
    ${X.goal ? `<div><div class="mini"><i style="width:${pct}%"></i></div><small>${wide ? `${Math.round(pct)}% da meta${conv ? ' · ' + conv : ''}` : `meta ${fmt(X.goal)}`}</small></div>` : (wide && conv ? `<small>${conv}</small>` : '')}`;
  return wide ? `<div class="gcard wide">${inner}</div>` : `<button class="gcard" id="gCard" title="Ver a origem">${inner}</button>`;
}

function deltaCell(cur, prev) {
  if (cur === null || cur === undefined) return '<span class="num" style="color:var(--muted)">sem dado</span>';
  const d = cur - prev;
  const pct = prev > 0 ? ` (${d >= 0 ? '+' : ''}${Math.round((d / prev) * 100)}%)` : '';
  return `<span class="num ${d >= 0 ? 'up' : 'down'}">${d >= 0 ? '+' : ''}${fmt(d)}${pct}</span>`;
}
function compareHTML(m) {
  const cmp = m.cmp;
  const btn = `<button class="pbtn" id="bCmp" title="Trocar a base de comparação">${ICON.swap}<span>${cmpMode === 'yoy' ? 'Alternar para: Mês passado' : 'Alternar para: Comparação 2025'}</span></button>`;
  const head = `<div class="cmphead"><div class="lbl" style="margin:0">Mesma data, dia ${m.now.getDate()}</div>${btn}</div>`;
  if (!S.agendor.enabled) return head + '<div class="hint">Ligue o Agendor nos ajustes para comparar.</div>';
  if (cmp.unavailable) return head + '<div class="hint">A comparação com 2025 vale só para o mês atual. Use o botão para voltar ao mês passado.</div>';
  if (!cmp.ready) return head + `<div class="hint">${cmp.yoy ? 'Buscando os dados de 2025 no Agendor, a primeira vez pode levar alguns minutos...' : 'Carregando o mês anterior do Agendor, pode levar alguns segundos...'}</div>`;
  const rows = [['Leads', cmp.curLeads, cmp.prevLeads], ['Ganhos', cmp.curWon, cmp.prevWon]];
  if (m.sales) rows.reverse();
  return `<div class="cmp">${head}
    <div class="hd"><span></span><span class="num">${m.isCur ? 'este mês' : esc(m.mName)}</span><span class="num">${esc(cmp.label)}</span><span class="num">diferença</span></div>
    ${rows.map(([n, a, b]) => `<div class="rw"><span>${n}</span><b class="num">${a === null ? '-' : fmt(a)}</b><b class="num">${fmt(b)}</b>${deltaCell(a, b)}</div>`).join('')}</div>`;
}

function emptyGoal(m) {
  return `<div class="empty"><p>Defina a meta de leads deste mês</p>
    <div class="row"><input class="fieldline" id="goalQuick" type="number" min="1" placeholder="Ex. 300"><button class="pbtn primary" style="height:36px;padding:0 20px" id="bGoal">Salvar</button></div></div>${footHTML(m)}`;
}

function infoCompact(now, m) {
  const { P } = m;
  if (!P.goal) return emptyGoal(m);
  const st = statusInfo(P.c, now, P.noun);
  return `
    <div class="top2">
      <div>
        <h3><span class="dot" style="background:${st.color}"></span>${esc(st.title)}</h3>
        <p class="sub">${esc(st.sub)}</p>
        <div class="rule"></div>
        ${statsHTML(P)}
      </div>
      ${miniCard(m, false)}
    </div>
    ${m.game ? `<div class="rule" style="margin:12px 0 10px"></div>${missionStrip(m)}` : ''}
    ${footHTML(m)}`;
}

function nextCard(m) {
  const n = m.next, sales = m.sales;
  const goal = sales ? n.won : n.leads, base = sales ? n.wonBase : n.leadsBase, other = sales ? n.leads : n.won;
  if (!goal) return `<div class="nextcard"><div class="lbl">Meta de ${esc(n.label)}</div><p style="margin:0">Defina nos ajustes.</p></div>`;
  const diff = m.P.goal ? Math.round((goal / m.P.goal - 1) * 100) : null;
  const perDay = n.days ? Math.ceil(goal / n.days) : 0;
  return `<div class="nextcard"><div class="lbl">Meta de ${esc(n.label)}</div>
    <b>${fmt(goal)}<small>${sales ? 'matrículas' : 'leads'}</small></b>
    <p><em>${fmt(perDay)}</em> por dia útil, ${n.days} dias úteis${diff !== null ? `, <em>${diff >= 0 ? '+' : ''}${diff}%</em> sobre ${esc(m.mName)}` : ''}.</p>
    ${base ? `<p>Base ${fmt(base)}</p>` : ''}
    ${other ? `<p>${sales ? 'Leads' : 'Matrículas'} <em>${fmt(other)}</em></p>` : ''}</div>`;
}

// ranking dos vendedores, cada um com sua cor e emoji, como jogadores
function sellersPanel(m) {
  const val = sellerMetric === 'val';
  const arr = m.sellers.map((s) => ({ s, n: val ? s.val : s.mat, g: val ? s.goalVal : s.goalMat })).sort((a, b) => b.n - a.n);
  const tot = arr.reduce((a, r) => ({ n: a.n + r.n, g: a.g + r.g }), { n: 0, g: 0 });
  const frac = m.isCur && m.W.c.goal ? Math.min(1, m.W.c.expected / m.W.c.goal) : null;
  const f = (n) => (val ? brl(n) : fmt(n));
  const row = (s, n, g) => `<div class="srow">${avHTML(s)}
    <div class="sm"><div class="sn"><b>${esc(s.name)}</b><em>${s.unit}</em><span>${f(n)}<i> / ${f(g)}</i></span></div>
    <div class="sbr"><i style="width:${g ? Math.min(100, (n / g) * 100) : 0}%;background:${s.color}"></i>${frac !== null ? `<u style="left:${(frac * 100).toFixed(1)}%"></u>` : ''}</div></div></div>`;
  return `<div class="ctl" style="margin-top:0"><div class="lbl" style="margin:0">Vendedores</div>
      <div class="seg"><button class="pbtn ${val ? '' : 'on'}" id="sMat">Matrículas</button><button class="pbtn ${val ? 'on' : ''}" id="sVal">Valores</button></div></div>
    <div class="slist">${arr.map((r) => row(r.s, r.n, r.g)).join('')}</div>
    <div class="stot"><span>Equipe</span><b>${f(tot.n)}<i> / ${f(tot.g)}</i></b></div>
    ${m.unidentified > 0 && S.agendor.enabled ? `<p class="note" style="margin-top:6px">${fmt(m.unidentified)} ${m.unidentified === 1 ? 'ganho' : 'ganhos'} sem vendedor identificado. Confira os nomes em Ajustes, Testar conexão.</p>` : ''}
    ${val ? '<p class="note" style="margin-top:6px">Valores somam o valor dos negócios ganhos no Agendor.</p>' : ''}`;
}

function unitBar(m) {
  return `<div class="unitbar"><div class="seg">${['ALL', 'SA', 'MA'].map((u) => `<button class="pbtn ${unitSel === u ? 'on' : ''}" data-u="${u}">${UNIT_NAME[u]}</button>`).join('')}</div>
    <span class="hint">${m.isCur ? '' : `Vendo ${esc(m.mName)} de ${m.vy}`}</span></div>`;
}

function infoExpanded(now, m) {
  const { P, c, sales } = m;
  if (!sales && !P.goal && m.unit === 'ALL') return emptyGoal(m);
  const st = statusInfo(c, now, P.noun);
  const todayIdx = now.getDate() - 1;
  const cmp = m.cmp;
  const isWon = chartMetric === 'won' && S.agendor.enabled;
  const cur = isWon ? cmp.wonSeries : m.L.series;
  const prev = isWon ? cmp.prevWonSeries : cmp.prevLeadsSeries;
  const gl = isWon ? m.W.goal : m.L.goal;
  const cc = isWon ? m.W.c : m.L.c;
  const chart = chartMode === 'acc'
    ? accChart({ cur, prev, todayIdx, goal: gl, showPace: gl > 0 })
    : dayChart({ series: cur, todayIdx, avg: gl ? cc.avgPerDay : 0 });
  const todayN = P.series[todayIdx] || 0;
  const weekN = Calc.weekCount(now, P.series);
  const legend = chartMode === 'acc'
    ? `<span><i style="border-color:#0aa874"></i>${m.isCur ? 'este mês' : esc(m.mName)}</span><span><i style="border-color:#7d8480;border-top-style:dashed"></i>${esc(cmp.label)}</span>${gl ? '<span><i style="border-color:#e8366b;border-top-style:dotted"></i>ritmo da meta</span>' : ''}`
    : `<span><i style="border-color:#0aa874"></i>por dia</span>${gl ? `<span><i style="border-color:#e8366b;border-top-style:dotted"></i>média necessária ${cc.avgPerDay.toFixed(1).replace('.', ',')}</span>` : ''}`;
  const showWon = originTab === 'won' && S.agendor.enabled;
  const oList = showWon ? m.wonOrigins : m.leadsOrigins;
  const oTotal = showWon ? (m.W.count || 0) : m.L.count;
  const right = sales
    ? sellersPanel(m)
    : `<div class="ctl" style="margin-top:0"><div class="lbl" style="margin:0">Origem</div>
        <div class="seg"><button class="pbtn ${showWon ? '' : 'on'}" id="oLeads">Leads</button><button class="pbtn ${showWon ? 'on' : ''}" id="oWon">Matrículas</button></div></div>
        ${m.unit === 'ALL' ? originBlock(oList, oTotal, 4) : '<div class="hint">A origem aparece na visão geral.</div>'}`;
  const avg = c.avgPerDay.toFixed(1).replace('.', ',');
  return `
    ${unitBar(m)}
    <div class="cols">
      <div>
        <h3><span class="dot" style="background:${st.color}"></span>${esc(st.title)}</h3>
        <p class="sub">${esc(st.sub)}</p>
        <div class="rule"></div>
        ${statsHTML(P)}
        ${m.isCur ? `<div class="tiles">
          <div class="tile"><b>${fmt(todayN)}</b><span>${esc(P.noun)} hoje</span></div>
          <div class="tile"><b>${fmt(weekN)} <small>de ${fmt(c.weeklyGoal)}</small></b><span>nesta semana</span></div>
        </div>` : ''}
        <div style="margin-top:12px">${miniCard(m, true)}</div>
        <p class="note">${P.goal && P.base ? `Base ${fmt(P.base)}, meta ${fmt(P.goal)}. ` : ''}Média diária necessária ${avg}${m.isCur ? `, restam ${c.remainingWork} dias úteis` : ''}.</p>
      </div>
      <div>
        ${compareHTML(m)}
        ${cmp.ready ? `
        <div class="ctl">
          <div class="seg"><button class="pbtn ${isWon ? '' : 'on'}" id="tLeads">Leads</button><button class="pbtn ${isWon ? 'on' : ''}" id="tWon">Ganhos</button></div>
          <div class="seg"><button class="pbtn ${chartMode === 'acc' ? 'on' : ''}" id="mAcc">Acumulado</button><button class="pbtn ${chartMode === 'day' ? 'on' : ''}" id="mDay">Por dia</button></div>
        </div>
        <div class="chart">${chart}</div>
        <div class="legend">${legend}</div>` : ''}
      </div>
      <div>
        ${missionStrip(m)}
        ${right}
        ${badgesRow(m)}
        ${nextCard(m)}
      </div>
    </div>
    ${footHTML(m)}`;
}

/* ---------------------------------------------------------------- perfis */
const pavHTML = (p, cls) => `<span class="pav ${cls || ''}" style="--c:${p.color}"><img src="${p.img}" alt="${esc(p.name)}" draggable="false"></span>`;

// topo esquerdo do cartao: avatar do perfil (volta para a escolha) e, no administrador, Marketing/Vendas
function topLeft(m) {
  const p = prof();
  const chip = `<button class="pchip" id="bProf" title="Trocar de perfil">${pavHTML(p, 'sm')}${p.type === 'admin' ? '' : `<em>${esc(p.name)}</em>`}</button>`;
  return `<div class="tl">${chip}${p.type === 'admin' && mode === 'expanded' ? areaSeg() : ''}</div>`;
}

// tela de escolha, no estilo Netflix
function pickerHTML() {
  return `<div class="picker"><button class="pclose" id="bClose" title="Fechar">${ICON.close}</button>
    <h2>Quem está acessando?</h2>
    <div class="pgrid2">${Plan.PROFILES.map((p) => `<button class="ptile ${S.ui.profile === p.id ? 'cur' : ''}" data-p="${p.id}">${pavHTML(p)}<b>${esc(p.name)}</b><span>${esc(p.role)}</span></button>`).join('')}</div>
  </div>`;
}

/* ---------------------------------------------------------------- modelos de cada perfil */
const sumKinds = (o) => Object.values(o || {}).reduce((a, n) => a + n, 0);
function viewModel(now) {
  const m = metrics(now);
  const p = prof();
  m.profile = p;
  const out = p.type === 'seller' ? sellerModel(m, p) : sdrView() ? sdrModel(m, p) : m;
  out.game = gameModel(out);
  return out;
}

// Posicao do vendedor na unidade pelo TOTAL de matriculas (nao o proporcional). Quem nao compete (lider de vendas) fica de fora.
function rankOf(sellers, me) {
  if (me.compete === false) return { kind: 'out' };
  const comp = sellers.filter((s) => s.compete !== false).sort((a, b) => b.mat - a.mat);
  const top = comp[0] ? comp[0].mat : 0;
  const others = comp.filter((s) => s.id !== me.id);
  if (top === 0) return { kind: 'open' };
  const best = others[0] || null; // melhor dos outros
  if (me.mat === top) return best && best.mat === me.mat ? { kind: 'tie', who: best.name } : { kind: 'lead', who: best ? best.name : '', margin: best ? me.mat - best.mat : me.mat };
  return { kind: 'behind', pos: 1 + comp.filter((s) => s.mat > me.mat).length, who: comp[0].name, gap: top - me.mat };
}

function sellerModel(m, p) {
  const me0 = m.sellers.find((s) => s.id === p.seller);
  const wk = workCfg(m.now);
  const mk = (s) => ({ ...s, series: Calc.dailySeries(m.now, s.days, []), pct: s.goalMat ? s.mat / s.goalMat : 0, c: Calc.compute({ now: m.now, goal: s.goalMat, count: s.mat, work: wk }) });
  const me = mk(me0);
  m.me = me; m.peers = m.sellers.filter((s) => s.id !== me0.id && s.compete !== false).map(mk);
  m.rank = rankOf(m.sellers, me0);
  m.sales = true; m.noMonths = false;
  m.label = `Suas matrículas de ${m.mName}`;
  m.P = { kind: 'won', noun: 'matrículas', goal: me.goalMat, base: 0, count: m.W.count === null ? null : me.mat, series: me.series, c: me.c };
  m.c = me.c;
  m.ops = opsNow();
  m.myOps = m.ops ? m.ops.sellers[me.id] : null;
  m.watch = { key: m.key + p.id, leads: 0, won: m.W.count === null ? null : me.mat, wgoal: me.goalMat };
  const nd = new Date(m.vy, Number(m.key.slice(5)), 1), nk = Calc.monthKey(nd);
  m.nextS = { label: monthName(nd), goal: Plan.sellerGoal(sellerOf(p), nk, 'mat'), goalVal: Plan.sellerGoal(sellerOf(p), nk, 'val'), days: m.next.days };
  return m;
}

function sdrModel(m, p) {
  const key = Calc.monthKey(new Date());
  const o = opsNow();
  const vg = (S.visitGoals || {})[key] || {};
  const wk = workCfg(m.now);
  const planM = Plan.meta('visits', 'ALL', key);
  const marc = o ? o.visits.marcadas : null, real = o ? o.visits.realizadas : null;
  const mkS = (days) => Calc.dailySeries(m.now, days || {}, []);
  const ser = mkS(o && o.visits.days.marc), serR = mkS(o && o.visits.days.real);
  const gM = vg.marc || planM;
  const c = Calc.compute({ now: m.now, goal: gM, count: marc || 0, work: wk });
  const cR = Calc.compute({ now: m.now, goal: vg.real || 0, count: real || 0, work: wk });
  m.sales = true; m.noMonths = true; m.isCur = true;
  m.label = `Visitas marcadas de ${m.mName}`;
  m.P = { kind: 'visit', noun: 'visitas', goal: gM, base: 0, count: marc, series: ser, c };
  m.X = { kind: 'visit', noun: 'visitas', goal: vg.real || 0, count: real, series: serR, c: cR };
  m.c = c; m.ops = o; m.vis = o ? o.visits : null;
  m.watch = { key: m.key + p.id, leads: 0, won: null, wgoal: 0 };
  return m;
}

/* ---------------------------------------------------------------- rotina do dia (vendedor) */
function workTiles(m, wide) {
  const o = m.myOps;
  if (!m.isCur) return '';
  const err = S.agendor.enabled ? ((m.ops && m.ops.tasksError) || (S.ops && S.ops.error)) : 'Ligue o Agendor';
  const dn = (k) => (o && !(m.ops && m.ops.tasksError) ? `${o.todayDone[k]}<i>/${o.today[k]}</i>` : '-');
  const items = [
    ['Leads para abordar', o ? fmt(o.open) : '-', 'em andamento com você'],
    ['Ligações hoje', dn('ligacao'), 'feitas / do dia'],
    ['Follow-ups hoje', dn('follow'), 'feitos / do dia'],
    ['Visitas hoje', dn('visita'), 'feitas / do dia'],
  ];
  const late = o && !(m.ops && m.ops.tasksError) ? sumKinds(o.overdue) : 0;
  return `<div class="wk ${wide ? 'wide' : ''}">${items.map(([l, v, s]) => `<div class="wt"><b>${v}</b><span>${l}</span>${wide ? `<small>${s}</small>` : ''}</div>`).join('')}</div>
    ${late > 0 ? `<p class="late">${fmt(late)} ${late === 1 ? 'tarefa atrasada' : 'tarefas atrasadas'}</p>` : ''}
    ${!o && S.agendor.enabled ? '<p class="note" style="margin-top:6px">Lendo a sua rotina no Agendor, pode levar um minuto.</p>' : ''}
    ${err && o ? `<p class="note" style="margin-top:6px">${esc(err)}</p>` : ''}`;
}

function unitCard(m, wide) {
  const W = m.W, g = W.goal;
  const pct = g && W.count !== null ? Math.min(100, (W.count / g) * 100) : 0;
  return `<div class="gcard ${wide ? 'wide' : ''}" style="cursor:default"><div><b>${W.count === null ? '-' : fmt(W.count)}${wide && g ? `<em>de ${fmt(g)}</em>` : ''}</b><span>matrículas de ${UNIT_NAME[m.unit]}</span></div>
    ${g ? `<div><div class="mini"><i style="width:${pct}%"></i></div><small>${wide ? `${Math.round(pct)}% da meta da unidade` : `meta ${fmt(g)}`}</small></div>` : ''}</div>`;
}

function infoSellerCompact(now, m) {
  if (!m.P.goal) return `<div class="empty"><p>Sem meta cadastrada para ${esc(m.me.name)} em ${esc(m.mName)}</p><span class="hint">As metas por vendedor ficam em lib/plan.js.</span></div>${footHTML(m)}`;
  const st = statusInfo(m.c, now, 'matrículas');
  return `<div class="top2"><div>
      <h3><span class="dot" style="background:${st.color}"></span>${esc(st.title)}</h3><p class="sub">${esc(st.sub)}</p>
      <div class="rule"></div>${statsHTML(m.P)}</div>${unitCard(m, false)}</div>
    ${m.isCur ? `<div class="rule" style="margin:12px 0 10px"></div>${missionStrip(m)}${workTiles(m, false)}` : ''}
    ${footHTML(m)}`;
}

function peerTable(m) {
  const cols = [m.me, ...m.peers];
  const o = m.ops;
  const ops = (s) => (o ? o.sellers[s.id] : null);
  const f = (n) => fmt(n);
  const rows = [
    ['Matrículas', (s) => `<b>${f(s.mat)}</b>`],
    ['Meta', (s) => f(s.goalMat)],
    ['% da meta', (s) => `${Math.round(s.pct * 100)}%`],
    ['Valores', (s) => brl(s.val)],
  ];
  if (m.isCur) rows.push(
    ['Leads para abordar', (s) => (ops(s) ? f(ops(s).open) : '-')],
    ['Ligações hoje', (s) => (ops(s) && !o.tasksError ? `${ops(s).todayDone.ligacao}/${ops(s).today.ligacao}` : '-')],
    ['Follow-ups hoje', (s) => (ops(s) && !o.tasksError ? `${ops(s).todayDone.follow}/${ops(s).today.follow}` : '-')],
    ['Visitas hoje', (s) => (ops(s) && !o.tasksError ? `${ops(s).todayDone.visita}/${ops(s).today.visita}` : '-')],
    ['Visitas que marcou', (s) => (ops(s) && !o.tasksError ? f(ops(s).visitsOwn || 0) : '-')],
    ['Atrasadas', (s) => (ops(s) && !o.tasksError ? f(sumKinds(ops(s).overdue)) : '-')],
  );
  return `<div class="ptab" style="--n:${cols.length}"><div class="ph0"><span></span>${cols.map((s, i) => `<span class="who">${avHTML(s)}<em>${i === 0 ? 'Você' : esc(s.name)}</em></span>`).join('')}</div>
    ${rows.map(([l, fn]) => `<div class="pr"><span>${l}</span>${cols.map((s) => `<span class="num">${fn(s)}</span>`).join('')}</div>`).join('')}</div>`;
}

function infoSellerExpanded(now, m) {
  if (!m.P.goal) return infoSellerCompact(now, m);
  const st = statusInfo(m.c, now, 'matrículas');
  const todayIdx = now.getDate() - 1;
  const peer = m.peers[0];
  const chart = accChart({ cur: m.me.series, prev: peer ? peer.series : m.me.series.map(() => 0), todayIdx, goal: m.P.goal, showPace: true, cutPrev: true });
  const todayN = m.me.series[todayIdx] || 0;
  const n = m.nextS;
  return `<div class="cols">
    <div>
      <h3><span class="dot" style="background:${st.color}"></span>${esc(st.title)}</h3><p class="sub">${esc(st.sub)}</p>
      <div class="rule"></div>${statsHTML(m.P)}
      ${m.isCur ? `<div class="tiles"><div class="tile"><b>${fmt(todayN)}</b><span>matrículas hoje</span></div>
        <div class="tile"><b>${fmt(Calc.weekCount(now, m.me.series))} <small>de ${fmt(m.c.weeklyGoal)}</small></b><span>nesta semana</span></div></div>` : ''}
      <div style="margin-top:12px">${unitCard(m, true)}</div>
      <p class="note">Meta de ${esc(m.me.name)} em ${esc(m.mName)}, ${fmt(m.P.goal)} matrículas${m.isCur ? `. Restam ${m.c.remainingWork} dias úteis` : ''}.</p>
    </div>
    <div>
      ${gameOn() && m.isCur ? (hasVs(m) && gameTab === 'vs' ? gameVersus(now, m) : gameMe(now, m)) : `      <div class="cmphead"><div class="lbl" style="margin:0">Você e ${UNIT_NAME[m.unit]}</div></div>
      ${peerTable(m)}
      <div class="chart" style="margin-top:12px">${chart}</div>
      <div class="legend"><span><i style="border-color:#0aa874"></i>você</span>${peer ? `<span><i style="border-color:#7d8480;border-top-style:dashed"></i>${esc(peer.name)}</span>` : ''}<span><i style="border-color:#e8366b;border-top-style:dotted"></i>ritmo da sua meta</span></div>`}
    </div>
    <div>
      <div class="lbl" style="margin:0 0 6px">${m.isCur ? 'Sua rotina de hoje' : 'Rotina'}</div>
      ${m.isCur ? missionStrip(m) + workTiles(m, true) : '<p class="hint">A rotina só aparece no mês atual.</p>'}
      ${badgesRow(m)}
      <div class="nextcard"><div class="lbl">Sua meta de ${esc(n.label)}</div>
        ${n.goal ? `<b>${fmt(n.goal)}<small>matrículas</small></b><p><em>${fmt(Math.ceil(n.goal / Math.max(1, n.days)))}</em> por dia útil, ${n.days} dias úteis.</p>${n.goalVal ? `<p>Valores <em>${brl(n.goalVal)}</em></p>` : ''}` : '<p style="margin:0">Sem meta cadastrada.</p>'}</div>
    </div>
  </div>${footHTML(m)}`;
}

/* ---------------------------------------------------------------- SDR (visitas) */
function visitStats(m) {
  const v = m.vis;
  if (!v) return [];
  return [['Marcadas', v.marcadas, '#0aa874'], ['Realizadas', v.realizadas, '#2fd08f'], ['Pendentes', v.pendentes, '#aab0ac'], ['Atrasadas', v.atrasadas, '#e8366b'], ['Remarcadas', v.remarcadas, '#f5a524']];
}
function sdrWarn() {
  if (!S.agendor.enabled) return '<p class="note">Ligue o Agendor nos Ajustes para ver as visitas.</p>';
  const o = opsNow();
  if (!o) return `<p class="note">${S.ops && S.ops.error ? esc(S.ops.error) : 'Lendo as visitas no Agendor, pode levar um minuto.'}</p>`;
  if (o.tasksError) return `<p class="note">${esc(o.tasksError)}</p>`;
  if (!o.visits.marcadas) {
    const tp = Object.entries(o.diag.taskTypes || {}).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([k, n]) => `${esc(k)} (${n})`).join(', ');
    return `<p class="note">Nenhuma visita marcada neste mês nos funis SAPreuni e MAPreuni. O Agendor devolveu ${fmt(o.diag.tasks)} tarefas${tp ? `, dos tipos ${tp}` : ''}, e ${fmt(o.diag.deals)} negócios abertos nos dois funis. Em Ajustes, Atualizar rotina agora, mostra o detalhe.</p>`;
  }
  if (o.visits.fonte === 'etapa') return '<p class="note">Não achamos tarefas de visita no Agendor. Estamos contando os negócios dos funis SAPreuni e MAPreuni que entraram em etapa de visita neste mês.</p>';
  return '';
}
function visitBars(rows) {
  const tot = rows.reduce((a, r) => a + r[1], 0) || 1;
  return `<div class="sbar">${rows.filter((r) => r[1] > 0).map(([, n, c]) => `<i style="flex:${n} 1 0;background:${c}"></i>`).join('')}</div>
    <ul class="olist">${rows.map(([name, n, c]) => `<li><i style="background:${c}"></i><span class="nm">${name}</span><b>${fmt(n)}</b><em>${Math.round((n / tot) * 100)}%</em></li>`).join('')}</ul>`;
}
// quem marcou a visita: a SDR ou o proprio vendedor, por ligacao
function quemMarcou(v) {
  v = { porSdr: 0, porVendedor: 0, semOrigem: 0, ...v };
  const rows = [['Pela SDR', v.porSdr, '#ec4899'], ['Pelos vendedores', v.porVendedor, '#f97316']];
  if (v.semOrigem > 0) rows.push(['Sem origem no CRM', v.semOrigem, '#b3bdb6']);
  const tot = rows.reduce((a, r) => a + r[1], 0) || 1;
  return `<div class="lbl" style="margin:14px 0 6px">Quem marcou</div>
    <div class="sbar">${rows.filter((r) => r[1] > 0).map(([, n, c]) => `<i style="flex:${n} 1 0;background:${c}"></i>`).join('')}</div>
    <ul class="olist">${rows.map(([name, n, c]) => `<li><i style="background:${c}"></i><span class="nm">${name}</span><b>${fmt(n)}</b><em>${Math.round((n / tot) * 100)}%</em></li>`).join('')}</ul>`;
}
function porUnidade(m) {
  const key = Calc.monthKey(new Date()), v = m.vis;
  const row = (u) => {
    const goal = Plan.meta('visits', u, key), n = (v.unit && v.unit[u] ? v.unit[u].marc : 0);
    return `<div class="urow"><span>${UNIT_NAME[u]}</span><b>${fmt(n)}<i> / ${fmt(goal)}</i></b><div class="mini"><i style="width:${goal ? Math.min(100, (n / goal) * 100) : 0}%"></i></div></div>`;
  };
  return `<div class="lbl" style="margin:14px 0 6px">Marcadas por unidade</div>${row('SA')}${row('MA')}`;
}
function infoSdrCompact(now, m) {
  const v = m.vis;
  if (!m.P.goal) return `<div class="empty"><p>Defina a meta de visitas marcadas do mês</p>
    <div class="row"><input class="fieldline" id="goalQuick" type="number" min="1" placeholder="Ex. 120"><button class="pbtn primary" style="height:36px;padding:0 20px" id="bGoal">Salvar</button></div>${v ? `<div class="wk">${visitStats(m).slice(0, 4).map(([l, n]) => `<div class="wt"><b>${fmt(n)}</b><span>${l}</span></div>`).join('')}</div>` : ''}</div>${footHTML(m)}`;
  const st = statusInfo(m.c, now, 'visitas');
  const X = m.X, pct = X.goal && X.count !== null ? Math.min(100, (X.count / X.goal) * 100) : 0;
  return `<div class="top2"><div>
      <h3><span class="dot" style="background:${st.color}"></span>${esc(st.title)}</h3><p class="sub">${esc(st.sub)}</p>
      <div class="rule"></div>${statsHTML(m.P)}</div>
    <div class="gcard" style="cursor:default"><div><b>${X.count === null ? '-' : fmt(X.count)}</b><span>realizadas</span></div>${X.goal ? `<div><div class="mini"><i style="width:${pct}%"></i></div><small>meta ${fmt(X.goal)}</small></div>` : '<small>sem meta</small>'}</div></div>
    ${v ? `<div class="rule" style="margin:12px 0 10px"></div>${missionStrip(m)}<div class="wk">${[['Hoje', v.hoje], ['Pendentes', v.pendentes], ['Atrasadas', v.atrasadas], ['Remarcadas', v.remarcadas]].map(([l, n]) => `<div class="wt ${l === 'Atrasadas' && n > 0 ? 'bad' : ''}"><b>${fmt(n)}</b><span>${l}</span></div>`).join('')}</div>` : sdrWarn()}
    ${footHTML(m)}`;
}
function infoSdrExpanded(now, m) {
  if (!m.P.goal) return infoSdrCompact(now, m);
  const v = m.vis, st = statusInfo(m.c, now, 'visitas'), X = m.X;
  const todayIdx = now.getDate() - 1;
  const chart = accChart({ cur: m.P.series, prev: X.series, todayIdx, goal: m.P.goal, showPace: true, cutPrev: true });
  const rate = v && v.marcadas ? Math.round((v.realizadas / v.marcadas) * 100) : 0;
  const pct = X.goal && X.count !== null ? Math.min(100, (X.count / X.goal) * 100) : 0;
  const stats = visitStats(m);
  return `<div class="cols">
    <div>
      <h3><span class="dot" style="background:${st.color}"></span>${esc(st.title)}</h3><p class="sub">${esc(st.sub)}</p>
      <div class="rule"></div>${statsHTML(m.P)}
      <div class="tiles"><div class="tile"><b>${fmt(m.P.series[todayIdx] || 0)}</b><span>marcadas hoje</span></div>
        <div class="tile"><b>${fmt(Calc.weekCount(now, m.P.series))} <small>de ${fmt(m.c.weeklyGoal)}</small></b><span>nesta semana</span></div></div>
      <div style="margin-top:12px"><div class="gcard wide" style="cursor:default"><div><b>${X.count === null ? '-' : fmt(X.count)}${X.goal ? `<em>de ${fmt(X.goal)}</em>` : ''}</b><span>visitas realizadas</span></div>
        ${X.goal ? `<div><div class="mini"><i style="width:${pct}%"></i></div><small>${Math.round(pct)}% da meta${v && v.marcadas ? ` · ${rate}% das marcadas` : ''}</small></div>` : (v && v.marcadas ? `<small>${rate}% das marcadas</small>` : '')}</div></div>
      <p class="note">Meta de visitas marcadas ${fmt(m.P.goal)}${X.goal ? `, realizadas ${fmt(X.goal)}` : ''}. Restam ${m.c.remainingWork} dias úteis.</p>
    </div>
    <div>
      <div class="cmphead"><div class="lbl" style="margin:0">Marcadas e realizadas</div></div>
      <div class="chart">${chart}</div>
      <div class="legend"><span><i style="border-color:#0aa874"></i>marcadas</span><span><i style="border-color:#7d8480;border-top-style:dashed"></i>realizadas</span><span><i style="border-color:#e8366b;border-top-style:dotted"></i>ritmo da meta</span></div>
      ${v ? porUnidade(m) : ''}
      ${sdrWarn()}
    </div>
    <div>
      ${missionStrip(m)}
      <div class="lbl" style="margin:0 0 6px">Situação das visitas</div>
      ${v && v.marcadas ? visitBars(stats.slice(1)) : '<p class="hint">Sem visitas no mês ainda.</p>'}
      ${v ? quemMarcou(v) : ''}
      ${badgesRow(m)}
      ${v ? `<div class="nextcard"><div class="lbl">Hoje</div><b>${fmt(v.hoje)}<small>visitas na agenda</small></b><p>${fmt(v.emEtapa)} ${v.emEtapa === 1 ? 'negócio' : 'negócios'} na etapa de visita do funil.</p></div>` : ''}
    </div>
  </div>${footHTML(m)}`;
}

/* ---------------------------------------------------------------- gamificacao (so na edicao gamificada, so no perfil de cada um) */
const GAME_DAY_OK = 0.8; // um dia conta para a sequencia quando pelo menos 80% das tarefas do dia foram feitas
const GICON = {
  flame: '<svg viewBox="0 0 24 24"><path d="M12 3c1 3.2 4.5 5 4.5 9.2A4.5 4.5 0 0 1 12 17a4.5 4.5 0 0 1-4.5-4.8c0-1.6.8-2.8 1.6-3.6.2 1.2.9 1.9 1.7 2C10.4 8 10.8 5.2 12 3z"/><path d="M12 21c-3.3 0-6-2.2-6-5.5 0-.8.2-1.6.5-2.2"/></svg>',
  star: '<svg viewBox="0 0 24 24"><path d="M12 3.2l2.5 5.4 5.9.7-4.4 4 1.2 5.8L12 16.2 6.8 19.1 8 13.3 3.6 9.3l5.9-.7z"/></svg>',
  bolt: '<svg viewBox="0 0 24 24"><path d="M13 3L5 13.5h6L10 21l8-10.5h-6z"/></svg>',
  target: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r=".8"/></svg>',
  crown: '<svg viewBox="0 0 24 24"><path d="M4 18h16M5 18L4 8l5 4 3-6 3 6 5-4-1 10"/></svg>',
  trophy: '<svg viewBox="0 0 24 24"><path d="M8 4h8v5a4 4 0 0 1-8 0zM8 6H5a3 3 0 0 0 3 4M16 6h3a3 3 0 0 1-3 4M12 13v4M9 20h6M10 17h4"/></svg>',
  check: '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
};
const GBADGES = {
  primeira: { name: 'Primeira do mês', icon: 'star', desc: 'Primeiro resultado do mês' },
  ritmo: { name: 'No ritmo', icon: 'bolt', desc: 'No ritmo da meta de hoje' },
  semana: { name: 'Semana batida', icon: 'target', desc: 'Meta da semana alcançada' },
  sequencia: { name: '5 dias seguidos', icon: 'flame', desc: 'Cinco dias seguidos cumprindo a missão' },
  lider: { name: 'Na liderança', icon: 'crown', desc: 'Primeiro lugar na unidade' },
  meta: { name: 'Meta batida', icon: 'trophy', desc: 'Meta do mês alcançada' },
  mission: { name: 'Missão cumprida', icon: 'check', desc: 'Missão do dia cumprida' },
};

/* ---- arte das conquistas (corujas, medalhas e trofeus) ---- */
const owlArt = (o = {}) => {
  const body = o.body || '#8a5a2b', belly = o.belly || '#f3d9a8';
  return `<path d="M19 18l5 8M45 18l-5 8" stroke="${body}" stroke-width="4.5" stroke-linecap="round"/>
  <path d="M16 33c0-10 6-17 16-17s16 7 16 17v5c0 9-6 15-16 15s-16-6-16-15z" fill="${body}"/>
  <path d="M23 45c0-5 4-8 9-8s9 3 9 8c0 3-4 5-9 5s-9-2-9-5z" fill="${belly}"/>
  <circle cx="25.5" cy="31" r="7.2" fill="#fff"/><circle cx="38.5" cy="31" r="7.2" fill="#fff"/>
  <circle cx="26.5" cy="31.6" r="3.4" fill="#2b1a0b"/><circle cx="37.5" cy="31.6" r="3.4" fill="#2b1a0b"/>
  <circle cx="27.7" cy="30.3" r="1.2" fill="#fff"/><circle cx="38.7" cy="30.3" r="1.2" fill="#fff"/>
  <path d="M29.2 36.5h5.6L32 41.5z" fill="#f5a524"/>
  <path d="M17 38c-3 3-2 8 1 10M47 38c3 3 2 8-1 10" stroke="${o.wing || '#6d4520'}" stroke-width="3" fill="none" stroke-linecap="round"/>`;
};
const badgeFrame = (id, shape, c) => {
  const g = (n, a, b) => `<linearGradient id="${id}${n}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>`;
  const P = {
    circle: (r) => `<circle cx="32" cy="32" r="${r}"/>`,
    shield: (k) => `<path d="M32 3c8 5 15 6 24 6v22c0 14-10 23-24 30C18 54 8 45 8 31V9c9 0 16-1 24-6z" transform="translate(${32 - 32 * k} ${32 - 32 * k}) scale(${k})"/>`,
    hex: (k) => `<path d="M32 2l26 15v30L32 62 6 47V17z" transform="translate(${32 - 32 * k} ${32 - 32 * k}) scale(${k})"/>`,
    burst: (k) => `<path d="M32 1l5.5 5.8 7.6-2.2 2.9 7.4 7.9.4-.4 7.9 7.4 2.9-2.2 7.6L64 32l-5.3 5.5 2.2 7.6-7.4 2.9.4 7.9-7.9-.4-2.9 7.4-7.6-2.2L32 63l-5.5-5.8-7.6 2.2-2.9-7.4-7.9-.4.4-7.9-7.4-2.9 2.2-7.6L0 32l5.3-5.5L3.1 18.9l7.4-2.9-.4-7.9 7.9.4 2.9-7.4 7.6 2.2z" transform="translate(${32 - 32 * k} ${32 - 32 * k}) scale(${k})"/>`,
  }[shape];
  const big = P(shape === 'circle' ? 30 : 0.96), mid = P(shape === 'circle' ? 24.5 : 0.74);
  return `<defs>${g('a', c[0], c[1])}${g('b', c[2], c[3])}</defs>
    <g transform="translate(0 2.5)" fill="${c[1]}" opacity=".95">${big}</g>
    <g fill="url(#${id}a)">${big}</g>
    <g fill="url(#${id}b)" stroke="rgba(255,255,255,.55)" stroke-width="1.4">${mid}</g>
    <path d="M13 22c3-8 9-12 17-13" stroke="rgba(255,255,255,.7)" stroke-width="2.6" fill="none" stroke-linecap="round"/>`;
};
const scale = (k, x, y) => `transform="translate(${x} ${y}) scale(${k})"`;
const flameArt = `<path d="M32 10c2 7 11 11 11 22a11 11 0 0 1-22 0c0-4 2-7 4-9 .4 3 2 4.6 3.6 5C27 22 29 16 32 10z" fill="#fff"/><path d="M32 22c1.4 4.5 6.5 6.5 6.5 12a6.5 6.5 0 0 1-13 0c0-2.4 1-4.200 2.400-5.600.3 1.800 1.200 2.600 2.200 2.800C29.500 29 30.500 25 32 22z" fill="#ffb02e"/><circle cx="29.600" cy="36" r="1.700" fill="#7a3a00"/><circle cx="35.200" cy="36" r="1.700" fill="#7a3a00"/>`;
const BADGE_ART = {
  primeira: (id) => badgeFrame(id, 'circle', ['#2c9a4b', '#1d7a37', '#7be08f', '#2fbf55']) + `<g ${scale(0.78, 7, 8.5)}>${owlArt({ body: '#7a4c1e' })}</g><path d="M49 12l1.600 3.300 3.600.5-2.600 2.500.6 3.600-3.200-1.700-3.200 1.700.6-3.600-2.600-2.500 3.600-.5z" fill="#ffd54a" stroke="#d99a00" stroke-width="1"/>`,
  ritmo: (id) => badgeFrame(id, 'shield', ['#2f7fe8', '#1c58b8', '#8cc2ff', '#3f95f5']) + `<path d="M36 12L19 35h10l-3 17 19-26H34z" fill="#ffd54a" stroke="#fff" stroke-width="2.600" stroke-linejoin="round"/>`,
  semana: (id) => badgeFrame(id, 'hex', ['#8b5cf6', '#5b34c4', '#c4a8ff', '#9b6df7']) + `<circle cx="32" cy="33" r="15" fill="#fff"/><circle cx="32" cy="33" r="10.500" fill="#e8366b"/><circle cx="32" cy="33" r="6" fill="#fff"/><circle cx="32" cy="33" r="2.800" fill="#e8366b"/><path d="M33 32L48 14M44 13l5 1 1 5" stroke="#3b2a7a" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none"/>`,
  sequencia: (id) => badgeFrame(id, 'circle', ['#f08a1c', '#c25e00', '#ffd08a', '#ff9d2e']) + `<g ${scale(1, 0, 1)}>${flameArt}</g>`,
  lider: (id) => badgeFrame(id, 'burst', ['#f5b50a', '#c98a00', '#ffe27a', '#ffc72c']) + `<g ${scale(0.7, 9.6, 16)}>${owlArt({ body: '#7a4c1e' })}</g><path d="M21 22l2-9 5 5 4-8 4 8 5-5 2 9z" fill="#ffd54a" stroke="#b97d00" stroke-width="1.600" stroke-linejoin="round"/>`,
  meta: (id) => badgeFrame(id, 'circle', ['#f5b50a', '#c98a00', '#ffe27a', '#ffc72c']) + `<path d="M21 14h22v12a11 11 0 0 1-22 0z" fill="#fff4c2" stroke="#b97d00" stroke-width="2"/><path d="M21 17h-5c0 8 3 11 7 12M43 17h5c0 8-3 11-7 12" stroke="#b97d00" stroke-width="2.200" fill="none" stroke-linecap="round"/><path d="M32 37v8M25 50h14l-1.500-5h-11z" fill="#b97d00" stroke="#b97d00" stroke-width="2" stroke-linejoin="round"/><path d="M32 17l2.200 4.500 4.800.7-3.500 3.400.8 4.800-4.300-2.300-4.300 2.300.8-4.800-3.500-3.400 4.800-.7z" fill="#ffc72c"/>`,
  mission: (id) => badgeFrame(id, 'circle', ['#2c9a4b', '#1d7a37', '#7be08f', '#2fbf55']) + `<path d="M20 33l8 8 16-17" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" fill="none"/>`,
};
const badgeSVG = (id) => `<svg class="bsvg" viewBox="0 0 64 66" aria-hidden="true">${BADGE_ART[id]('bg' + id)}</svg>`;

const LEVELS = [['Bronze', 0.25], ['Prata', 0.5], ['Ouro', 0.75], ['Diamante', 1]];
const gameOn = () => !!(S && S.edition && S.edition.game) && prof().type !== 'admin';

function streakFromLog(log, now) {
  let n = 0;
  const wk = workCfg(now);
  for (let i = 0; i < 60; i++) {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i, 12);
    if (!Calc.isWorkday(d, wk)) continue;
    const e = (log || {})[Calc.ymd(d)];
    const ok = e && e[0] > 0 && e[1] / e[0] >= GAME_DAY_OK;
    if (i === 0) { if (ok) n++; continue; } // hoje so soma quando ja esta cumprido, nao quebra a sequencia
    if (!e || e[0] === 0) continue; // dia sem tarefa nao quebra
    if (ok) n++; else break;
  }
  return n;
}
function streakFromSeries(series, need, now) {
  let n = 0;
  const wk = workCfg(now), today = now.getDate();
  for (let day = today; day >= 1; day--) {
    const d = new Date(now.getFullYear(), now.getMonth(), day, 12);
    if (!Calc.isWorkday(d, wk)) continue;
    const ok = (series[day - 1] || 0) >= need;
    if (day === today) { if (ok) n++; continue; }
    if (ok) n++; else break;
  }
  return n;
}

function gameModel(m) {
  if (!gameOn() || !m.isCur) return null;
  const p = prof(), P = m.P, c = P.c;
  const count = P.count || 0, goal = P.goal;
  const pct = goal ? count / goal : 0;
  let mission = null, streak = 0;
  if (p.type === 'seller') {
    const o = m.myOps;
    if (o && !(m.ops && m.ops.tasksError)) {
      const total = sumKinds(o.today), done = sumKinds(o.todayDone);
      if (total > 0) mission = { done, total, label: 'tarefas' };
      streak = streakFromLog(o.log, m.now);
    }
  } else if (goal && P.count !== null) {
    const need = Math.max(1, Math.ceil(c.avgPerDay));
    const todayN = P.series[m.now.getDate() - 1] || 0;
    mission = { done: todayN, total: need, label: p.type === 'sdr' ? 'visitas marcadas' : 'leads' };
    streak = streakFromSeries(P.series, need, m.now);
  }
  let lvl = 0;
  LEVELS.forEach(([, f], i) => { if (pct >= f) lvl = i + 1; });
  const nextLv = LEVELS[lvl] || null;
  const week = Calc.weekCount(m.now, P.series);
  const earned = {
    primeira: count >= 1,
    ritmo: !!goal && count > 0 && count >= Math.round(c.expected),
    semana: !!goal && c.weeklyGoal > 0 && count > 0 && week >= c.weeklyGoal,
    sequencia: streak >= 5,
    lider: !!(m.rank && (m.rank.kind === 'lead' || m.rank.kind === 'tie')),
    meta: !!c.done,
  };
  const ids = ['primeira', 'ritmo', 'semana', 'sequencia', ...(p.type === 'seller' && m.rank && m.rank.kind !== 'out' ? ['lider'] : []), 'meta'];
  return { mission, streak, pct, lvl, levelName: lvl ? LEVELS[lvl - 1][0] : null, nextLevel: nextLv ? nextLv[0] : null, badges: ids.map((id) => ({ id, ...GBADGES[id], earned: !!earned[id] })), newIds: new Set() };
}

/* ---- pecas de interface ---- */
function missionStrip(m) {
  const g = m.game;
  if (!g || (!g.mission && !g.streak)) return '';
  const M = g.mission, done = M && M.done >= M.total;
  const pct = M ? Math.min(100, (M.done / M.total) * 100) : 0;
  return `<div class="msn ${done ? 'done' : ''}">
    <span class="fl ${g.streak ? 'on' : ''}" title="Dias seguidos cumprindo a missão">${GICON.flame}<b>${g.streak}</b></span>
    <div class="mb"><div class="mh"><span>${done ? 'Missão cumprida' : 'Missão do dia'}</span>${M ? `<em>${fmt(M.done)} de ${fmt(M.total)} ${M.label}</em>` : ''}</div>
      ${M ? `<div class="mbar"><i style="width:${pct}%"></i></div>` : ''}</div>
  </div>`;
}
function badgesRow(m) {
  const g = m.game;
  if (!g) return '';
  const n = g.badges.filter((b) => b.earned).length;
  const nx = g.badges.find((b) => !b.earned);
  return `<div class="bdg"><div class="lbl" style="margin:0 0 7px;display:flex;justify-content:space-between"><span>Conquistas</span><span>${n} de ${g.badges.length}</span></div>
    <div class="bdr">${g.badges.map((b) => `<div class="bd ${b.earned ? 'on' : ''} ${g.newIds.has(b.id) ? 'new' : ''}" title="${esc(b.name)}. ${esc(b.desc)}">${GICON[b.icon]}</div>`).join('')}</div></div>`;
}

// avisos de conquista na bolinha (nao dispara na primeira leitura)
let seenGame = null;
function watchGame(m) {
  const g = m.game;
  if (!g) { seenGame = null; return; }
  const ids = new Set(g.badges.filter((b) => b.earned).map((b) => b.id));
  if (g.mission && g.mission.done >= g.mission.total) ids.add('mission');
  const key = prof().id + m.key;
  if (seenGame && seenGame.key === key && S.agendor.enabled) {
    for (const id of ids) {
      if (seenGame.ids.has(id)) continue;
      g.newIds.add(id);
      if (view === 'main' && mode === 'bubble') fxQueue.push({ type: 'badge', id });
    }
    if (fxQueue.length && !fxBusy && view === 'main' && mode === 'bubble') runFx();
  }
  seenGame = { key, ids };
}


/* ---------------------------------------------------------------- perfil do vendedor: meu ritmo e versus */
let gameTab = 'me'; // 'me' | 'vs'
const hasVs = (m) => gameOn() && !!m.me && m.me.compete !== false && !!(m.peers && m.peers[0]);

function gTabs(m) {
  if (!hasVs(m)) return '';
  return `<div class="gseg"><button class="${gameTab === 'me' ? 'on' : ''}" id="bGme">Meu ritmo</button><button class="${gameTab === 'vs' ? 'on' : ''}" id="bGvs">Versus</button></div>`;
}

// uma linha "feito x ideal" com barra, verde quando esta dentro do ideal e rosa quando nao
function idealRow(label, done, ideal, note, soft, f = fmt) {
  const ok = done >= ideal;
  const cls = ok ? 'ok' : soft ? 'mid' : 'low';
  const w = ideal > 0 ? Math.min(100, (done / ideal) * 100) : (done > 0 ? 100 : 0);
  return `<div class="gr"><div class="gh"><span>${label}</span><b class="${cls}">${f(done)}<i> / ${f(ideal)}</i></b></div>
    <div class="gbar"><i class="${cls}" style="width:${w}%"></i></div>${note ? `<small>${note}</small>` : ''}</div>`;
}

function gameMe(now, m) {
  const me = m.me, o = m.myOps, okOps = o && !(m.ops && m.ops.tasksError);
  const ideal = Math.round(me.c.expected), diff = me.mat - ideal;
  const fr = m.W.c.goal ? Math.min(1, m.W.c.expected / m.W.c.goal) : 0;
  const idealVal = Math.round((me.goalVal || 0) * fr);
  const todayIdx = now.getDate() - 1;
  const chart = accChart({ cur: me.series, prev: me.series.map(() => 0), todayIdx, goal: m.P.goal, showPace: true, cutPrev: true });
  const rows = [idealRow('Matrículas no mês', me.mat, ideal, diff >= 0 ? (diff ? `${fmt(diff)} à frente do ideal de hoje` : 'exatamente no ideal de hoje') : `${fmt(-diff)} atrás do ideal de hoje`)];
  if (me.goalVal) rows.push(idealRow('Valores vendidos', me.val, idealVal, `meta do mês ${brl(me.goalVal)}`, true, brl));
  else rows.push(`<div class="gr"><div class="gh"><span>Valores vendidos</span><b>${brl(me.val)}</b></div></div>`);
  const plain = (lab, val, note) => `<div class="gr"><div class="gh"><span>${lab}</span><b>${val}</b></div>${note ? `<small>${note}</small>` : ''}</div>`;
  if (okOps) {
    const k = (n, lab) => {
      const d = o.todayDone[n] || 0, t = o.today[n] || 0;
      rows.push(t ? idealRow(lab, d, t, '', true) : plain(lab, `${fmt(d)}<i> hoje</i>`));
    };
    k('ligacao', 'Ligações hoje'); k('follow', 'Follow-ups hoje'); k('visita', 'Visitas hoje');
    rows.push(plain('Visitas que marcou no mês', fmt(o.visitsOwn || 0)));
    rows.push(plain('Leads para abordar', fmt(o.open || 0), sumKinds(o.overdue) ? `${fmt(sumKinds(o.overdue))} tarefas atrasadas` : ''));
  } else rows.push('<p class="note">Ligações, follow-ups e visitas aparecem quando o Agendor liberar as tarefas.</p>');
  return `<div class="cmphead"><div class="lbl" style="margin:0">Você e o ideal</div>${gTabs(m)}</div>
    <div class="grs">${rows.join('')}</div>
    <div class="chart" style="margin-top:8px">${chart}</div>
    <div class="legend"><span><i style="border-color:#0aa874"></i>você</span><span><i style="border-color:#e8366b;border-top-style:dotted"></i>ideal da sua meta</span></div>`;
}

function gameVersus(now, m) {
  const me = m.me, pe = m.peers[0], o = m.ops;
  const mo = o && !o.tasksError ? o.sellers[me.id] : null, po = o && !o.tasksError ? o.sellers[pe.id] : null;
  const cats = [
    ['Matrículas', me.mat, pe.mat, fmt, true],
    ['% da meta', Math.round(me.pct * 100), Math.round(pe.pct * 100), (n) => n + '%', true],
    ['Valores', me.val, pe.val, brl, true],
  ];
  if (mo && po) cats.push(
    ['Ligações hoje', mo.todayDone.ligacao, po.todayDone.ligacao, fmt, true],
    ['Follow-ups hoje', mo.todayDone.follow, po.todayDone.follow, fmt, true],
    ['Visitas hoje', mo.todayDone.visita, po.todayDone.visita, fmt, true],
  );
  let wins = 0, lose = 0;
  const lines = cats.map(([l, a, b, f]) => {
    const w = a > b ? 1 : a < b ? -1 : 0;
    if (w > 0) wins++; else if (w < 0) lose++;
    return `<div class="vr"><b class="${w > 0 ? 'win' : ''}">${f(a)}</b><span>${l}</span><b class="${w < 0 ? 'win' : ''}">${f(b)}</b></div>`;
  }).join('');
  const total = me.mat + pe.mat, left = total ? (me.mat / total) * 100 : 50;
  const head = me.mat > pe.mat ? ['Você está ganhando', `por ${fmt(me.mat - pe.mat)} matrícula${me.mat - pe.mat > 1 ? 's' : ''}`, 'ok']
    : me.mat < pe.mat ? [`${esc(pe.name)} está ganhando`, `por ${fmt(pe.mat - me.mat)} matrícula${pe.mat - me.mat > 1 ? 's' : ''}`, 'low']
      : ['Empate na disputa', 'ninguém passou na frente ainda', ''];
  const todayIdx = now.getDate() - 1;
  const chart = accChart({ cur: me.series, prev: pe.series, todayIdx, goal: m.P.goal, showPace: true, cutPrev: true });
  return `<div class="cmphead"><div class="lbl" style="margin:0">Você contra ${esc(pe.name)}</div>${gTabs(m)}</div>
    <div class="vs">
      <div class="vp">${avHTML(me, 'lg')}<em>Você</em></div>
      <div class="vm"><b class="${head[2]}">${head[0]}</b><span>${head[1]}</span></div>
      <div class="vp">${avHTML(pe, 'lg')}<em>${esc(pe.name)}</em></div>
    </div>
    <div class="tug"><i style="width:${Math.max(6, Math.min(94, left))}%"></i></div>
    <div class="vtab">${lines}</div>
    <p class="note" style="margin:6px 0 8px">Você vence em ${wins} de ${cats.length} categorias${lose ? ` e ${esc(pe.name)} em ${lose}` : ''}.</p>
    <div class="chart">${chart}</div>
    <div class="legend"><span><i style="border-color:#0aa874"></i>você</span><span><i style="border-color:#7d8480;border-top-style:dashed"></i>${esc(pe.name)}</span><span><i style="border-color:#e8366b;border-top-style:dotted"></i>ritmo da sua meta</span></div>`;
}
/* ---------------------------------------------------------------- ADM: visao por vendedor */
const teamState = () => {
  const t = (S.ui && S.ui.team) || {};
  return { hide: Array.isArray(t.hide) ? t.hide : [], metric: t.metric === 'val' ? 'val' : 'mat' };
};
const saveTeam = (t) => { S.ui.team = t; api.setUi({ team: t }); render(); };

// varias linhas acumuladas, uma por vendedor, com a cor de cada um
function multiChart({ lines, todayIdx, ideal, isMoney }) {
  const W = 400, H = 176, pl = isMoney ? 48 : 28, pr = 10, pt = 10, pb = 20;
  const N = lines.length ? lines[0].series.length : 30;
  const cums = lines.map((l) => ({ ...l, cum: Calc.cumulative(l.series) }));
  const top = Math.max(1, ...cums.map((l) => l.cum[todayIdx]), ideal ? ideal * 0.6 : 0) * 1.12;
  const x = (i) => pl + (i / Math.max(1, N - 1)) * (W - pl - pr);
  const y = (v) => H - pb - (v / top) * (H - pb - pt);
  let out = `<defs><clipPath id="cpt"><rect x="${pl}" y="0" width="${W - pl}" height="${H - pb}"/></clipPath></defs>`;
  [0, 0.5, 1].forEach((f) => {
    const v = (top / 1.12) * f;
    out += `<line x1="${pl}" x2="${W - pr}" y1="${y(v)}" y2="${y(v)}" stroke="#e1e0d8" ${f ? 'stroke-dasharray="2 4"' : ''}/><text x="${pl - 6}" y="${y(v) + 3}" fill="#8b928d" font-size="9" text-anchor="end">${isMoney ? fmtMoney(v) : fmt(v)}</text>`;
  });
  if (ideal > 0) out += `<path clip-path="url(#cpt)" d="M${x(0)} ${y(0)} L${x(N - 1)} ${y(ideal)}" stroke="#e8366b" stroke-width="1.3" stroke-dasharray="1.5 4" stroke-linecap="round" fill="none"/>`;
  cums.forEach((l) => {
    const pts = l.cum.slice(0, todayIdx + 1).map((v, i) => ({ x: x(i), y: y(v) }));
    out += `<path d="${smooth(pts)}" stroke="${l.color}" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
  });
  cums.forEach((l) => { out += `<circle cx="${x(todayIdx)}" cy="${y(l.cum[todayIdx])}" r="4" fill="${l.color}" stroke="#fff" stroke-width="1.5"/>`; });
  const lab = (i, a) => `<text x="${x(i)}" y="${H - 5}" fill="#8b928d" font-size="9" text-anchor="${a}">${i + 1}</text>`;
  return `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">${out}${lab(0, 'start')}${lab(todayIdx, 'middle')}${lab(N - 1, 'end')}</svg>`;
}

function teamModel(m) {
  const st = teamState(), isVal = st.metric === 'val';
  const wk = workCfg(m.now);
  const all = (m.allSellers || m.sellers).map((s) => {
    const days = isVal ? s.valDays : s.days;
    const goal = isVal ? s.goalVal : s.goalMat;
    const count = isVal ? s.val : s.mat;
    return { ...s, series: Calc.dailySeries(m.now, days || {}, []), goal, count, c: Calc.compute({ now: m.now, goal, count, work: wk }), on: !st.hide.includes(s.id) };
  });
  const shown = all.filter((s) => s.on);
  const tot = shown.reduce((a, s) => ({ goal: a.goal + (s.goal || 0), count: a.count + s.count }), { goal: 0, count: 0 });
  const c = Calc.compute({ now: m.now, goal: tot.goal, count: tot.count, work: wk });
  return { st, isVal, all, shown, tot, c, f: isVal ? brl : fmt };
}

function teamChips(T) {
  return `<div class="tmchips">${T.all.map((s) => `<button class="tmchip ${s.on ? 'on' : ''}" data-tm="${s.id}" style="--c:${s.color}" title="${s.on ? 'Esconder' : 'Mostrar'} ${esc(s.name)}">${avHTML(s)}<span>${esc(s.name)}</span></button>`).join('')}</div>`;
}
function teamSeg(T) {
  return `<div class="gseg"><button class="${!T.isVal ? 'on' : ''}" id="bTmMat">Matrículas</button><button class="${T.isVal ? 'on' : ''}" id="bTmVal">Valores</button></div>`;
}
function teamRows(T, m) {
  if (!T.shown.length) return '<p class="hint">Nenhum vendedor ligado. Use as bolinhas acima.</p>';
  return `<div class="trows">${[...T.shown].sort((a, b) => b.count - a.count).map((s) => {
    const exp = s.c.expected, ok = s.count >= Math.round(exp * 100) / 100 - 0.0001 || s.c.done;
    const pct = s.goal ? Math.min(100, (s.count / s.goal) * 100) : 0, ep = s.goal ? Math.min(100, (exp / s.goal) * 100) : 0;
    return `<div class="trow">${avHTML(s)}<div class="tb2"><div class="th"><b>${esc(s.name)}</b><span class="${ok ? 'ok' : 'low'}">${T.f(s.count)}<i> / ${s.goal ? T.f(s.goal) : 'sem meta'}</i></span></div>
      <div class="gbar"><i style="width:${pct}%;background:${s.color}"></i>${s.goal ? `<u style="left:${ep}%"></u>` : ''}</div>
      <small>${s.goal ? `ideal hoje ${T.f(Math.round(exp))}, ${Math.round(s.c.pct * 100)}% da meta` : 'defina a meta em Ajustes'}</small></div></div>`;
  }).join('')}</div>`;
}

function infoTeam(now, m, big) {
  const T = teamModel(m), todayIdx = now.getDate() - 1;
  const chart = multiChart({ lines: T.shown.map((s) => ({ color: s.color, series: s.series })), todayIdx, ideal: T.tot.goal, isMoney: T.isVal });
  const diff = T.tot.count - T.c.expected;
  const sum = `<div class="tsum"><div><b>${T.f(T.tot.count)}</b><span>${T.tot.goal ? `de ${T.f(T.tot.goal)} na meta dos ligados` : 'sem meta nos ligados'}</span></div>
    ${T.tot.goal ? `<div><b class="${diff >= 0 ? 'ok' : 'low'}">${diff >= 0 ? '+' : '-'}${T.f(Math.round(Math.abs(diff)))}</b><span>${diff >= 0 ? 'à frente do ideal de hoje' : 'atrás do ideal de hoje'}</span></div>` : ''}</div>`;
  const legend = `<div class="legend">${T.shown.map((s) => `<span><i style="border-color:${s.color}"></i>${esc(s.name)}</span>`).join('')}${T.tot.goal ? '<span><i style="border-color:#e8366b;border-top-style:dotted"></i>ritmo da soma das metas</span>' : ''}</div>`;
  if (!big) return `<div class="cmphead"><div class="lbl" style="margin:0">Por vendedor</div>${teamSeg(T)}</div>${teamChips(T)}${sum}<div class="chart">${chart}</div>${legend}${footHTML(m)}`;
  return `<div class="cols">
    <div><div class="lbl" style="margin:0 0 8px">Quem aparece</div>${teamChips(T)}<div style="height:10px"></div>${sum}<p class="note">Ligue ou desligue cada pessoa, inclusive o Filipe. Os números e o gráfico mudam na hora e a escolha fica salva.</p></div>
    <div><div class="cmphead"><div class="lbl" style="margin:0">${T.isVal ? 'Valores' : 'Matrículas'} acumuladas</div>${teamSeg(T)}</div><div class="chart">${chart}</div>${legend}</div>
    <div><div class="lbl" style="margin:0 0 6px">Cada vendedor</div>${teamRows(T, m)}</div>
  </div>${footHTML(m)}`;
}
/* ---------------------------------------------------------------- bolinha */
function ringTarget(m) { return m.P.c.goal ? Math.min(1, (m.P.count || 0) / m.P.c.goal) : 0; }
// o anel (ou a barra) cresce suavemente ate o valor novo
function animateRing(m) {
  const t = ringTarget(m);
  if (ringPct === t) return;
  requestAnimationFrame(() => requestAnimationFrame(() => {
    const arc = $('ringArc');
    if (arc) {
      const R = Number(arc.getAttribute('r'));
      arc.setAttribute('stroke-dasharray', `${(Math.max(t, 0.015) * 2 * Math.PI * R).toFixed(1)} ${(2 * Math.PI * R).toFixed(1)}`);
    }
    const bf = $('barFill'); if (bf) bf.style.width = Math.max(t * 100, 3) + '%';
    ringPct = t;
  }));
}
// aw e ah = proporcao do formato em relacao ao tamanho escolhido
const THEMES = {
  'foto-clara':  { name: 'Foto clara',   cls: 't-fotoclara',  shape: 'round', aw: 1, ah: 1, kind: 'arc',    sw: 4,   track: 'rgba(14,18,16,.13)', arc: '#0aa874', txt: '#0e1210', sub: 'rgba(14,18,16,.62)', dotbg: '#fff' },
  'foto-escura': { name: 'Foto escura',  cls: 't-fotoescura', shape: 'round', aw: 1, ah: 1, kind: 'arc',    sw: 3.5, track: 'rgba(255,255,255,.32)', arc: '#2fd08f', txt: '#fff', sub: 'rgba(255,255,255,.78)', dotbg: '#fff' },
  'escuro':      { name: 'Orbe escuro',  cls: 't-escuro',     shape: 'round', aw: 1, ah: 1, kind: 'arc',    sw: 4,   track: 'rgba(255,255,255,.13)', arc: '#2fd08f', txt: '#fff', sub: 'rgba(255,255,255,.5)', dotbg: '#0e1210' },
  'branco':      { name: 'Branco',       cls: 't-branco',     shape: 'round', aw: 1, ah: 1, kind: 'arc',    sw: 7,   track: '#ececee', arc: '#0aa874', txt: '#0e1210', sub: '#8a8f8c', dotbg: '#fff' },
  'aneis':       { name: 'Anéis duplos', cls: 't-aneis',      shape: 'round', aw: 1, ah: 1, kind: 'double', sw: 4.5, track: '#ececee', arc: '#0aa874', arc2: '#f5a524', txt: '#0e1210', sub: '#8a8f8c', dotbg: '#fff' },
  'tracos':      { name: 'Traços',       cls: 't-tracos',     shape: 'round', aw: 1, ah: 1, kind: 'ticks',  sw: 3,   track: '#dfe2e0', arc: '#0aa874', txt: '#0e1210', sub: '#8a8f8c', dotbg: '#fff' },
  'verde':       { name: 'Verde Noc',    cls: 't-verde',      shape: 'round', aw: 1, ah: 1, kind: 'arc',    sw: 4.5, track: 'rgba(255,255,255,.25)', arc: '#ffffff', txt: '#fff', sub: 'rgba(255,255,255,.75)', dotbg: '#07533f' },
  // formatos que nao sao bolinha
  'capsula':     { name: 'Cápsula',      cls: 't-capsula',    shape: 'capsula', aw: 2.15, ah: 0.82, track: '#ececee', arc: '#0aa874' },
  'cartao':      { name: 'Cartão',       cls: 't-cartao',     shape: 'cartao',  aw: 1.3, ah: 1.08,  track: '#ececee', arc: '#0aa874' },
  'barra':       { name: 'Barra',        cls: 't-barra',      shape: 'barra',   aw: 2.5,  ah: 0.72,  track: 'rgba(255,255,255,.22)', arc: '#2fd08f' },
  'lider':       { name: 'Líder',        cls: 't-lider',      shape: 'lider',   aw: 2.85, ah: 0.84, track: '#ececee', arc: '#0aa874' },
  'placar':      { name: 'Placar',       cls: 't-placar',     shape: 'placar',  aw: 3.9,  ah: 1.0,  track: '#ececee', arc: '#0aa874' },
  'numero':      { name: 'Número',       cls: 't-numero',     shape: 'numero',  aw: 1.3,  ah: 0.82, track: '#ececee', arc: '#0aa874' },
};
// quantos jogadores o placar mostra neste perfil (a largura acompanha)
function placarN() {
  const t = prof().type;
  if (sdrView()) return 1;
  const list = t === 'seller' ? Plan.sellersOf(effUnit()) : Plan.sellersOf('ALL');
  return Math.max(1, list.filter((s) => s.compete !== false).length);
}
const bubDims = (k, size) => { const T = THEMES[k || bubTheme()]; const aw = T.shape === 'placar' ? 0.34 + 0.9 * placarN() : T.aw; return [Math.round(size * aw), Math.round(size * T.ah)]; };

function bubbleHTML(now, m, themeKey, preview) {
  const { P, X } = m;
  const c = P.c;
  const T = THEMES[themeKey || bubTheme()];
  const pct = preview ? ringTarget(m) : (ringPct === null ? ringTarget(m) : ringPct); // comeca do valor anterior e cresce
  const exp = c.goal ? Math.min(1, c.expected / c.goal) : 0;
  const id = (n) => (preview ? '' : `id="${n}"`);
  const num = P.count === null ? '-' : fmt(P.count);
  const noun = P.noun;
  const goalTxt = c.goal ? `de ${fmt(c.goal)}` : noun;

  // formatos retangulares
  if (T.shape === 'capsula') {
    const R = 40, C = 2 * Math.PI * R;
    return `<svg class="mring" viewBox="0 0 100 100"><circle cx="50" cy="50" r="${R}" fill="none" stroke="${T.track}" stroke-width="11"/><circle ${id('ringArc')} cx="50" cy="50" r="${R}" fill="none" stroke="${T.arc}" stroke-width="11" stroke-linecap="round" stroke-dasharray="${(Math.max(pct, 0.012) * C).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 50 50)"/></svg>
      <div class="mtx"><b>${num}</b><span>${goalTxt}</span></div><em class="mpc">${Math.round(pct * 100)}%</em>`;
  }
  if (T.shape === 'cartao') {
    return `<div class="ct"><span>${P.kind === 'won' ? 'Vendas' : P.kind === 'visit' ? 'Visitas' : 'Leads'}</span><em>${Math.round(pct * 100)}%</em></div>
      <b>${num}</b><div class="cb"><i ${id('barFill')} style="width:${Math.max(pct * 100, 3)}%"></i>${c.goal ? `<u style="left:${(exp * 100).toFixed(1)}%"></u>` : ''}</div><small>${goalTxt}</small>`;
  }
  if (T.shape === 'barra') {
    return `<div class="btx"><b>${num}</b><span>${goalTxt}</span><em>${Math.round(pct * 100)}%</em></div><div class="btr"><i class="bfill" ${id('barFill')} style="width:${Math.max(pct * 100, 3)}%"></i>${c.goal ? `<u style="left:${(exp * 100).toFixed(1)}%"></u>` : ''}</div>`;
  }
  if (T.shape === 'lider' && m.me) {
    // perfil de vendedor: feito x deveria ter hoje, a meta dele no mes e a posicao na unidade
    const me = m.me, y = Math.round(me.c.expected), good = me.mat >= y;
    const g = me.goalMat || 1, rk = m.rank || {};
    const lines = {
      lead: ['Na liderança', rk.who ? `+${fmt(rk.margin)} sobre ${esc(rk.who)}` : esc(me.name), 'up'],
      tie: ['Empate na liderança', `com ${esc(rk.who || '')}`, 'up'],
      behind: [`${rk.pos}º na unidade`, `${fmt(rk.gap)} atrás de ${esc(rk.who || '')}`, ''],
      open: ['Disputa aberta', 'sem líder ainda', ''],
      out: ['Líder de vendas', esc(me.name), ''],
    }[rk.kind || 'out'];
    return `<div class="lw">${avHTML(me)}<div class="mtx"><b class="${good ? 'ok' : 'low'}">${fmt(me.mat)}<i>/${fmt(y)}</i></b><span>meta ${fmt(me.goalMat)}</span></div>
      <div class="lname ${lines[2]}"><small>${lines[0]}</small>${lines[1]}</div>
      <div class="lbar"><i class="${good ? 'ok' : 'low'}" ${id('barFill')} style="width:${Math.max(Math.min(1, me.mat / g) * 100, 3)}%"></i><u style="left:${Math.min(100, (me.c.expected / g) * 100).toFixed(1)}%"></u></div></div>`;
  }
  if (T.shape === 'lider' && (prof().type === 'mkt' || sdrView())) {
    // so as informacoes da propria pessoa, sem disputa
    const p = sdrView() ? sdrFace() : prof(), y = Math.round(c.expected), good = (P.count || 0) >= y, g = c.goal || 1, cnt = P.count || 0;
    const d = cnt - y;
    const l1 = sdrView() ? 'Visitas marcadas' : 'Leads do mês';
    const l2 = !c.goal ? 'sem meta definida' : c.done ? 'Meta batida' : `${Math.round(c.pct * 100)}% da meta`;
    return `<div class="lw">${avHTML(p)}<div class="mtx"><b class="${good ? 'ok' : 'low'}">${P.count === null ? '-' : fmt(cnt)}<i>/${fmt(y)}</i></b><span>meta ${fmt(c.goal)}</span></div>
      <div class="lname ${good ? 'up' : ''}"><small>${l1}</small>${l2}</div>
      <div class="lbar"><i class="${good ? 'ok' : 'low'}" ${id('barFill')} style="width:${Math.max(Math.min(1, cnt / g) * 100, 3)}%"></i><u style="left:${Math.min(100, (c.expected / g) * 100).toFixed(1)}%"></u></div></div>`;
  }
  if (T.shape === 'lider') {
    const L = m.leader;
    const av = L ? avHTML(L) : '<div class="av" style="--c:#0aa874">🏁</div>';
    return `${av}<div class="mtx"><b>${num}</b><span>${goalTxt}</span></div><div class="lname">${L ? `<small>líder</small>${esc(L.name)}` : '<small>sem líder</small>'}</div>`;
  }
  if (T.shape === 'placar') {
    // todos os vendedores ao mesmo tempo, feito x o que deveria estar hoje
    const fr = m.W.c.goal ? Math.min(1, m.W.c.expected / m.W.c.goal) : 0;
    if (sdrView()) {
      const y = Math.round(c.expected), ok = (P.count || 0) >= y;
      return `<div class="pl">${avHTML(sdrFace())}<b class="${ok ? 'ok' : 'low'}">${P.count === null ? '-' : fmt(P.count)}<i>/${fmt(y)}</i></b></div>`;
    }
    return (prof().type === 'seller' ? m.sellers : m.allSellers).filter((s) => s.compete !== false).map((s) => {
      const exp = Math.round(s.goalMat * fr); // x,5 ou mais sobe, abaixo disso desce
      const ok = s.mat >= exp;
      return `<div class="pl">${avHTML(s)}<b class="${ok ? 'ok' : 'low'}">${fmt(s.mat)}<i>/${fmt(exp)}</i></b></div>`;
    }).join('');
  }
  if (T.shape === 'numero') {
    const col = c.done || c.diff >= 0 ? '#0aa874' : '#e8366b';
    return `<div class="nb"><i style="background:${col}"></i><b>${num}</b></div><small>${goalTxt}</small><div class="nm"><i ${id('barFill')} style="width:${Math.max(pct * 100, 3)}%;background:${col}"></i></div>`;
  }

  // formatos redondos
  const arcOf = (R, p, col, sw, idn) => {
    const C = 2 * Math.PI * R;
    return `<circle cx="50" cy="50" r="${R}" fill="none" stroke="${T.track}" stroke-width="${sw}"/><circle ${id(idn)} cx="50" cy="50" r="${R}" fill="none" stroke="${col}" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${(Math.max(p, 0.012) * C).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 50 50)"/>`;
  };
  const dot = (R) => {
    if (!c.goal) return '';
    const a = exp * 2 * Math.PI;
    return `<circle cx="${(50 + R * Math.sin(a)).toFixed(1)}" cy="${(50 - R * Math.cos(a)).toFixed(1)}" r="4.6" fill="#e8366b" stroke="${T.dotbg}" stroke-width="2"/>`;
  };
  let svg;
  if (T.kind === 'ticks') {
    const n = 40, done = Math.round(pct * n), pink = Math.min(n - 1, Math.round(exp * n));
    svg = '';
    for (let i = 0; i < n; i++) {
      const a = (i / n) * 2 * Math.PI, x1 = 50 + 38 * Math.sin(a), y1 = 50 - 38 * Math.cos(a), x2 = 50 + 47 * Math.sin(a), y2 = 50 - 47 * Math.cos(a);
      const col = c.goal && i === pink ? '#e8366b' : i < done ? T.arc : T.track;
      svg += `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${col}" stroke-width="${i === pink && c.goal ? 3.6 : T.sw}" stroke-linecap="round"/>`;
    }
  } else if (T.kind === 'double') {
    const wp = X.goal && X.count !== null ? Math.min(1, X.count / X.goal) : 0;
    svg = arcOf(44, pct, T.arc, T.sw, 'ringArc') + arcOf(34.5, wp, T.arc2, T.sw, 'ringArc2') + dot(44);
  } else {
    const R = T.sw > 5 ? 43 : 44;
    svg = arcOf(R, pct, T.arc, T.sw, 'ringArc') + dot(R);
  }
  const sub = T.kind === 'double' && X.count !== null ? `${fmt(X.count)} ${X.kind === 'won' ? 'ganhos' : 'leads'}` : goalTxt;
  return `<svg viewBox="0 0 100 100">${svg}</svg><div class="bc" style="color:${T.txt}"><b>${num}</b><span style="color:${T.sub}">${sub}</span></div>`;
}

/* ---------------------------------------------------------------- icone do app */
// Variacoes da Noc, a coruja, o icone de cada perfil e o automatico (segue o perfil em uso)
const APP_ICONS = [
  { key: 'noc', name: 'Noc verde', kind: 'ring', bg: ['#12b57a', '#07563f'], ring: '#ffffff', track: 'rgba(255,255,255,.28)' },
  { key: 'escuro', name: 'Noc escuro', kind: 'ring', bg: ['#1c2622', '#0b0f0d'], ring: '#1DB954', track: 'rgba(29,185,84,.25)' },
  { key: 'claro', name: 'Noc claro', kind: 'ring', bg: ['#ffffff', '#e9efec'], ring: '#0aa874', track: 'rgba(10,168,116,.18)' },
  { key: 'esmeralda', name: 'Esmeralda', kind: 'ring', bg: ['#0f7a5c', '#063d2e'], ring: '#b8f34a', track: 'rgba(184,243,74,.25)' },
  { key: 'auto', name: 'Do perfil em uso', kind: 'auto' },
  ...Plan.PROFILES.map((p) => ({ key: 'p:' + p.id, name: p.name, kind: 'img', img: p.img, color: p.color })),
];
const imgCache = {};
const loadImg = (src) => imgCache[src] || (imgCache[src] = new Promise((res) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = (window.EMOJI_DATA && window.EMOJI_DATA[src]) || src; }));
const shade = (hex, f) => { const n = parseInt(hex.slice(1), 16); const c = (v) => Math.max(0, Math.min(255, Math.round(v))); const r = n >> 16, g = (n >> 8) & 255, b = n & 255;
  return f >= 0 ? `rgb(${c(r + (255 - r) * f)},${c(g + (255 - g) * f)},${c(b + (255 - b) * f)})` : `rgb(${c(r * (1 + f))},${c(g * (1 + f))},${c(b * (1 + f))})`; };
// icone efetivo de uma chave (o automatico vira o do perfil atual)
const iconDef = (key) => { const k = key === 'auto' ? 'p:' + prof().id : key; return APP_ICONS.find((x) => x.key === k) || APP_ICONS[0]; };

async function drawAppIcon(key, size) {
  const d = iconDef(key);
  const cv = document.createElement('canvas'); cv.width = cv.height = size;
  const x = cv.getContext('2d'), s = size / 256;
  const rr = (r) => { x.beginPath(); x.moveTo(r, 0); x.arcTo(size, 0, size, size, r); x.arcTo(size, size, 0, size, r); x.arcTo(0, size, 0, 0, r); x.arcTo(0, 0, size, 0, r); x.closePath(); };
  const bg = d.bg || [shade(d.color, 0.55), shade(d.color, 0.05)];
  const gr = x.createLinearGradient(0, 0, size, size); gr.addColorStop(0, bg[0]); gr.addColorStop(1, bg[1]);
  rr(58 * s); x.fillStyle = gr; x.fill();
  if (d.kind === 'ring') {
    x.lineCap = 'round'; x.lineWidth = 30 * s;
    x.strokeStyle = d.track; x.beginPath(); x.arc(128 * s, 128 * s, 72 * s, 0, Math.PI * 2); x.stroke();
    x.strokeStyle = d.ring; x.beginPath(); x.arc(128 * s, 128 * s, 72 * s, -Math.PI / 2, Math.PI * 0.95); x.stroke();
  } else {
    const im = await loadImg(d.img);
    if (im) { const w = 178 * s; x.drawImage(im, (size - w) / 2, (size - w) / 2, w, w); }
  }
  return cv;
}
const appIconURL = async (key, size) => (await drawAppIcon(key, size)).toDataURL('image/png');

// aplica no Windows quando muda a escolha ou, no automatico, quando muda o perfil
let appIconSig = null;
async function syncAppIcon(force) {
  if (!S || !api.setAppIcon) return;
  const key = S.appIcon || 'noc';
  const sig = key === 'auto' ? 'auto:' + prof().id : key;
  if (!force && sig === appIconSig) return;
  appIconSig = sig;
  const url = key === 'noc' ? null : await appIconURL(key, 256);
  const r = await api.setAppIcon(key, url);
  if (r) S.appIcon = r.appIcon;
}

function appIconSection() {
  const cur = S.appIcon || 'noc';
  return `<h4>Ícone do app</h4>
    <div class="igrid">${APP_ICONS.map((d) => `<button class="itile ${cur === d.key ? 'on' : ''}" data-icon="${d.key}" title="${esc(d.name)}"><canvas data-ic="${d.key}" width="96" height="96"></canvas><span>${esc(d.name)}</span></button>`).join('')}</div>
    <p class="hint">Vale para a barra de tarefas e para quando você fixa o app. Se o ícone fixado não mudar, desafixe e fixe de novo.</p>`;
}
async function drawIconTiles() {
  for (const cv of document.querySelectorAll('canvas[data-ic]')) {
    const k = cv.dataset.ic, ctx = cv.getContext('2d');
    if (k === 'auto') {
      const a = await drawAppIcon('auto', 96);
      ctx.clearRect(0, 0, 96, 96); ctx.drawImage(a, 0, 0);
      ctx.fillStyle = '#0e1210'; ctx.beginPath(); ctx.arc(78, 78, 15, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2.6; ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(78, 78, 7, -0.3, Math.PI * 1.45); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(84.5, 70.5); ctx.lineTo(85.2, 76.2); ctx.lineTo(79.6, 75); ctx.stroke();
    } else { const a = await drawAppIcon(k, 96); ctx.clearRect(0, 0, 96, 96); ctx.drawImage(a, 0, 0); }
  }
}
/* ---------------------------------------------------------------- ajustes */
function heroSettings() {
  return `<div class="topbar"><span class="mpill">Ajustes</span>
    <div class="tools"><button class="tb" id="bBack" title="Voltar">${ICON.back}</button></div></div>
    <div><div class="hname">Metas, fotos e bolinha</div></div>`;
}

function draftWork() {
  return { saturday: draft.saturday, autoHolidays: draft.auto, municipal: draft.municipal, extraHolidays: [...draft.extra], ignoredHolidays: [...draft.ignored] };
}
function calHTML() {
  const { y, m } = calMonth;
  const work = draftWork();
  const pres = Holidays.presumed(y, work);
  const first = new Date(y, m, 1), dim = new Date(y, m + 1, 0).getDate();
  const todayS = Holidays.ymd(new Date());
  const ds = (d) => `${y}-${pad2(m + 1)}-${pad2(d)}`;
  const eff = new Set(Holidays.effective([y], work));
  const bd = Calc.compute({ now: first, goal: 1, count: 0, work: { saturday: work.saturday, holidays: [...eff] } }).totalWork;
  let cells = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((x) => `<div class="dw">${x}</div>`).join('');
  for (let i = 0; i < first.getDay(); i++) cells += '<i class="cd"></i>';
  const names = [];
  for (let d = 1; d <= dim; d++) {
    const s = ds(d), dow = new Date(y, m, d).getDay();
    const p = pres[s], ign = draft.ignored.has(s), ex = draft.extra.has(s);
    const isH = (p && !ign) || ex;
    const cls = ['cd'];
    if (dow === 0 || (dow === 6 && !work.saturday)) cls.push('off');
    if (isH) cls.push('hol'); else if (p && ign) cls.push('ign');
    if (s === todayS) cls.push('today');
    cells += `<button class="${cls.join(' ')}" data-d="${s}" title="${esc(p ? p.name : ex ? 'Feriado extra' : 'Clique para marcar como feriado')}">${d}</button>`;
    if (p) names.push(`<div class="${ign ? 'ig' : ''}"><b>${d}</b><span>${esc(p.name)}${p.kind === 'municipal' ? ' <span class="chk">confira</span>' : ''}${p.kind === 'facultativo' ? ' <span class="chk">facultativo</span>' : ''}${ign ? ' (não conta)' : ''}</span></div>`);
    else if (ex) names.push(`<div><b>${d}</b><span>Feriado extra</span></div>`);
  }
  const label = new Date(y, m, 1).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  return `<div class="calhd"><button class="pbtn round" data-nav="-1">${ICON.back}</button><span>${esc(cap(label))} <span class="cnt">· ${bd} dias úteis</span></span><button class="pbtn round" data-nav="1">${ICON.next}</button></div>
    <div class="cal">${cells}</div>
    <div class="hl">${names.join('') || '<span class="hint">Nenhum feriado neste mês.</span>'}</div>`;
}

function photosHTML() {
  const mine = S.photos || [];
  return `<label class="sw"><input id="fPhDef" type="checkbox" ${S.usePhotosDefault !== false ? 'checked' : ''}><u></u><span>Usar as 8 fotos padrão da Noc</span></label>
    <div class="pgrid">${mine.map((p) => `<div class="ph"><img src="${esc(p.url)}" alt="" draggable="false"><button data-rm="${esc(p.id)}" title="Remover">${ICON.close}</button></div>`).join('')}
      <button class="ph add" id="bAddPh" title="Adicionar fotos da galeria"><span>+</span><small>Adicionar</small></button></div>
    <span class="hint">${mine.length ? `${mine.length} ${mine.length === 1 ? 'foto sua passa' : 'fotos suas passam'} no fundo${S.usePhotosDefault !== false ? ' junto com as padrão' : ''}.` : 'As fotos que você adicionar passam no fundo do cartão.'}</span>`;
}

function infoSettings(now) {
  const key = Calc.monthKey(now);
  const nd = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const nKey = Calc.monthKey(nd);
  const mn = monthName(now), nn = monthName(nd);
  const a = S.agendor;
  const sel = (v, cur) => (String(v) === String(cur) ? 'selected' : '');
  const tokenHint = a.tokenUnreadable ? '<span class="hint err">O token salvo não pôde ser lido neste computador. Cole de novo uma vez.</span>'
    : a.hasToken ? '<span class="hint ok">Token salvo neste computador. Não precisa colar de novo.</span>' : '';
  const wg = S.winGoals || {};
  const mm = metrics(now);
  const plan = (kind, k) => Plan.meta(kind, 'ALL', k);
  const num = (id, label, v, ph) => `<label class="f">${label}<input class="fieldline" id="${id}" type="number" min="0" value="${v || ''}" placeholder="${ph ? 'plano ' + ph : ''}"></label>`;
  const sw = (id, on, txt) => `<label class="sw"><input id="${id}" type="checkbox" ${on ? 'checked' : ''}><u></u><span>${txt}</span></label>`;
  const size = bubSize();
  const preview = (k, T) => {
    const [w, h] = bubDims(k, 100);
    const pb = Math.min(54, 66 / (w / 100), 54 / (h / 100) * 1.0);
    const [pw, ph] = bubDims(k, pb);
    return `<div class="bubble prev ${T.cls} sh-${T.shape}" style="--bwpx:${pw}px;--bhpx:${ph}px;--bubn:${(pb / 80).toFixed(3)}">${bubbleHTML(now, mm, k, true)}</div>`;
  };
  return `<div class="form" id="form">
    <h4>Metas</h4>
    <div class="two">${num('fGoal', `Leads de ${esc(mn)}`, S.goals[key], plan('leads', key))}${num('fWinGoal', `Matrículas de ${esc(mn)}`, wg[key], plan('mat', key))}</div>
    <div class="two">${num('fGoalN', `Leads de ${esc(nn)}`, S.goals[nKey], plan('leads', nKey))}${num('fWinGoalN', `Matrículas de ${esc(nn)}`, wg[nKey], plan('mat', nKey))}</div>
    <div class="two">${num('fVisM', `Visitas marcadas de ${esc(mn)}`, ((S.visitGoals || {})[key] || {}).marc, Plan.meta('visits', 'ALL', key))}${num('fVisR', `Visitas realizadas de ${esc(mn)}`, ((S.visitGoals || {})[key] || {}).real, '')}</div>
    <div class="row" style="justify-content:space-between"><span class="hint">Em branco vale a tabela do plano, que também define as metas por unidade e por vendedor.</span><button class="pbtn" id="bPlan" title="Preenche com os valores da tabela do plano">Usar o plano</button></div>
    <h4>Fotos do fundo</h4>
    <div id="phbox" class="phbox">${photosHTML()}</div>
    <h4>Agendor</h4>
    ${sw('fEnabled', a.enabled, 'Puxar leads do Agendor automaticamente')}
    <label class="f">Token da API do Agendor
      <input class="fieldline" id="fToken" type="password" placeholder="${a.hasToken ? 'Já salvo, deixe vazio para manter' : 'Cole o token aqui'}"></label>
    ${tokenHint}
    <label class="f">Atualizar
      <select class="fieldline" id="fInt">${[[1, 'Ao vivo (1 min)'], [5, 'A cada 5 min'], [15, 'A cada 15 min'], [30, 'A cada 30 min'], [60, 'A cada 1 hora']].map(([n, t]) => `<option value="${n}" ${sel(n, a.intervalMin)}>${t}</option>`).join('')}</select></label>
    <span class="hint">Contam como lead só os negócios dos funis SAPreuni (Santo André) e MAPreuni (Mauá).</span>
    <div class="row"><button class="pbtn" id="bTest">Testar conexão</button></div>
    <div class="hint diag" id="testMsg">${esc(testMsg)}</div>
    <div class="row"><button class="pbtn" id="bOps" title="Lê tarefas e carteira abertas dos vendedores e das visitas">${S.opsBusy ? 'Lendo o Agendor...' : 'Atualizar rotina agora'}</button></div>
    <div class="hint diag">${esc(opsDiag())}</div>
    ${appIconSection()}
    <h4>Bolinha</h4>
    <div class="tgrid" id="tgrid">${Object.entries(THEMES).map(([k, T]) => `<button class="tchip ${bubTheme() === k ? 'on' : ''}" data-theme="${k}"><div class="pvbox">${preview(k, T)}</div><span>${esc(T.name)}</span></button>`).join('')}</div>
    <label class="f">Tamanho da bolinha <b id="bsLbl" style="color:var(--ink)">${size} px</b>
      <input type="range" id="bSize" min="56" max="128" step="4" value="${size}"></label>
    <h4>Dias úteis e feriados</h4>
    <div id="cal">${calHTML()}</div>
    <span class="hint">Clique num dia para marcar ou desmarcar como feriado.</span>
    ${sw('fAuto', draft.auto, 'Presumir feriados nacionais e Carnaval')}
    ${sw('fMun', draft.municipal, 'Incluir Santo André (8/4) e Mauá (8/12) <small>confira</small>')}
    ${sw('fSat', draft.saturday, 'Contar sábado como dia útil')}
    <h4>Programa</h4>
    ${sw('fStart', S.startWithWindows, 'Abrir junto com o Windows')}
    <div class="row" style="justify-content:space-between;margin-top:2px">
      <button class="pbtn" id="bReset" title="Apaga só os ajustes manuais deste mês">Zerar manuais do mês</button>
      <button class="pbtn primary" style="height:34px;padding:0 22px" id="bSave">Salvar</button></div>
  </div>`;
}
function opsDiag() {
  const o = S.ops;
  const hh = (t) => (t ? new Date(t).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '');
  if (S.opsBusy) return 'Lendo negócios e tarefas no Agendor. Pode levar alguns minutos, a tela atualiza sozinha.';
  if (!o) return 'Rotina dos vendedores e visitas ainda não lida. Use o botão acima.';
  const head = o.syncedAt ? `Última tentativa às ${hh(o.syncedAt)}.\n` : '';
  if (o.error) return `${head}Erro na leitura. ${o.error}`;
  if (!o.diag) return `${head}Ainda sem dados.`;
  const lst = (x) => Object.entries(x || {}).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([n, v]) => `${n} (${v})`).join(', ') || 'nenhum';
  return `${head}Negócios em andamento nos funis: ${o.diag.deals}. Etapas: ${lst(o.diag.stages)}\nTarefas lidas: ${o.diag.tasks}${o.diag.tasksVia ? ` (formato ${o.diag.tasksVia})` : ''}. Tipos: ${lst(o.diag.taskTypes)}\nVisitas marcadas no mês: ${o.visits ? o.visits.marcadas : 0}${o.visits && o.visits.fonte === 'etapa' ? ' (contadas pela etapa do funil)' : ''}\nCampos de tarefa vistos: ${(o.diag.taskKeys || []).join(', ') || '-'}${o.tasksError ? '\nErro nas tarefas. ' + o.tasksError : ''}`;
}
function readSettings() {
  const v = (id) => $(id);
  const w = draftWork();
  return { token: v('fToken').value, entity: 'deals', enabled: v('fEnabled').checked, intervalMin: Number(v('fInt').value),
    saturday: w.saturday, autoHolidays: w.autoHolidays, municipal: w.municipal, extraHolidays: w.extraHolidays, ignoredHolidays: w.ignoredHolidays,
    startWithWindows: v('fStart').checked };
}

/* ---------------------------------------------------------------- eventos */
function setMode(m) {
  mode = m; view = 'main'; flip = false; menuOpen = false;
  if (m === 'bubble') { snapNext = true; viewKey = null; }
  if (m !== 'expanded') unitSel = 'ALL';
  api.setMode(m);
  render();
}
function openSettings(now) {
  view = 'settings'; testMsg = ''; menuOpen = false;
  draft = { saturday: !!S.work.saturday, auto: S.work.autoHolidays !== false, municipal: S.work.municipal !== false,
    extra: new Set(S.work.extraHolidays || []), ignored: new Set(S.work.ignoredHolidays || []) };
  calMonth = { y: now.getFullYear(), m: now.getMonth() };
  render();
}
function pickMonth(k, real) {
  viewKey = k === Calc.monthKey(real) ? null : k;
  menuOpen = false; flip = false;
  if (viewKey && S.agendor.enabled && !(S.history && S.history[viewKey])) api.loadMonth(viewKey);
  render();
}
function bindPhotos() {
  const box = $('phbox'); if (!box) return;
  const redraw = (r) => { if (r) S = r; box.innerHTML = photosHTML(); bindPhotos(); };
  const add = $('bAddPh'); if (add) add.addEventListener('click', async () => redraw(await api.addPhotos()));
  box.querySelectorAll('[data-rm]').forEach((b) => b.addEventListener('click', async () => redraw(await api.removePhoto(b.dataset.rm))));
  const df = $('fPhDef'); if (df) df.addEventListener('change', async () => redraw(await api.setDefaultPhotos(df.checked)));
}
function bind(now) {
  const on = (id, fn) => { const el = $(id); if (el) el.addEventListener('click', fn); };
  const key = Calc.monthKey(now);
  const nKey = Calc.monthKey(new Date(now.getFullYear(), now.getMonth() + 1, 1));
  on('bClose', () => api.close());
  on('bProf', () => { view = 'profiles'; menuOpen = false; render(); });
  document.querySelectorAll('[data-p]').forEach((b) => b.addEventListener('click', () => {
    S.ui.profile = b.dataset.p; api.setUi({ profile: b.dataset.p });
    view = 'main'; viewKey = null; unitSel = 'ALL'; flip = false; seen = null; menuOpen = false; chartMetric = area() !== 'mkt' ? 'won' : 'leads';
    if (mode === 'bubble') mode = 'compact';
    render();
  }));
  on('bBubble', () => setMode('bubble'));
  on('bSet', () => openSettings(now));
  on('bBack', () => { view = 'main'; render(); });
  on('bExpand', () => setMode(mode === 'expanded' ? 'compact' : 'expanded'));
  on('bM1', () => api.addManual(-1));
  on('bP1', () => api.addManual(1));
  on('bP5', () => api.addManual(5));
  on('bUndo', () => api.undoManual());
  on('bSync', () => { if (viewKey && S.agendor.enabled) api.loadMonth(viewKey, true); else api.syncNow(); });
  on('gCard', () => { flip = !flip; render(); });
  on('tLeads', () => { chartMetric = 'leads'; render(); });
  on('tWon', () => { chartMetric = 'won'; render(); });
  on('mAcc', () => { chartMode = 'acc'; render(); });
  on('mDay', () => { chartMode = 'day'; render(); });
  on('oLeads', () => { originTab = 'leads'; render(); });
  on('oWon', () => { originTab = 'won'; render(); });
  on('sMat', () => { sellerMetric = 'mat'; render(); });
  on('sVal', () => { sellerMetric = 'val'; render(); });
  on('bCmp', () => { cmpMode = cmpMode === 'yoy' ? 'prev' : 'yoy'; render(); });
  document.querySelectorAll('[data-icon]').forEach((b) => b.addEventListener('click', async () => {
    const key = b.dataset.icon;
    document.querySelectorAll('[data-icon]').forEach((x) => x.classList.toggle('on', x === b));
    S.appIcon = key; await syncAppIcon(true);
  }));
  if (document.querySelector('canvas[data-ic]')) drawIconTiles();
  on('bGme', () => { gameTab = 'me'; render(); });
  on('bGvs', () => { gameTab = 'vs'; render(); });
  on('aMkt', () => { S.ui.area = 'mkt'; chartMetric = 'leads'; flip = false; api.setUi({ area: 'mkt' }); render(); });
  on('aSdr', () => { S.ui.area = 'sdr'; flip = false; api.setUi({ area: 'sdr' }); render(); });
  on('aEq', () => { S.ui.area = 'equipe'; chartMetric = 'won'; flip = false; api.setUi({ area: 'equipe' }); render(); });
  on('bTmMat', () => { const t = teamState(); saveTeam({ ...t, metric: 'mat' }); });
  on('bTmVal', () => { const t = teamState(); saveTeam({ ...t, metric: 'val' }); });
  document.querySelectorAll('[data-tm]').forEach((b) => b.addEventListener('click', () => { const t = teamState(), id = b.dataset.tm; saveTeam({ ...t, hide: t.hide.includes(id) ? t.hide.filter((x) => x !== id) : [...t.hide, id] }); }));
  on('aVen', () => { S.ui.area = 'vendas'; chartMetric = 'won'; flip = false; api.setUi({ area: 'vendas' }); render(); });
  on('bMonth', () => { if (viewKey) pickMonth(null, now); else { menuOpen = !menuOpen; render(); } });
  document.querySelectorAll('[data-u]').forEach((b) => b.addEventListener('click', () => { unitSel = b.dataset.u; render(); }));
  document.querySelectorAll('[data-mk]').forEach((b) => b.addEventListener('click', () => pickMonth(b.dataset.mk, now)));
  on('bGoal', async () => { const n = Number($('goalQuick').value); if (n > 0) await (sdrView() ? api.setVisitGoal(key, 'marc', n) : api.setGoal(key, n)); });
  const gq = $('goalQuick');
  if (gq) gq.addEventListener('keydown', (e) => { if (e.key === 'Enter') $('bGoal').click(); });
  on('bTest', async () => {
    const msg = $('testMsg'); msg.className = 'hint diag'; msg.textContent = 'Testando...';
    const r = await api.testAgendor(readSettings());
    if (r.ok) {
      const lst = (o) => Object.entries(o || {}).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([n, v]) => `${n} (${v})`).join(', ') || 'nenhum';
      testMsg = `Conectou. ${r.total} leads e ${r.won} ganhos neste mês.` + (r.diag ? `\nResponsáveis vistos: ${lst(r.diag.owners)}\nFunis vistos (só SAPreuni e MAPreuni contam): ${lst(r.diag.funnels)}` : '');
    } else testMsg = r.error;
    msg.className = 'hint diag ' + (r.ok ? 'ok' : 'err'); msg.textContent = testMsg;
  });
  on('bOps', async () => {
    $('bOps').textContent = 'Lendo o Agendor...'; $('bOps').disabled = true;
    // se o token foi digitado agora e ainda nao salvo, salva antes de ler (o teste de conexao usa o campo, a rotina usa o salvo)
    const typed = $('fToken').value.trim();
    if (typed || $('fEnabled').checked !== S.agendor.enabled) { const st = readSettings(); if (typed) st.enabled = true; const s0 = await api.saveSettings(st); if (s0) S = s0; }
    const r = await api.syncOps(); if (r) S = r; render(); });
  on('bReset', async () => { if (confirm('Zerar os ajustes manuais deste mês?')) await api.resetManual(key); });
  on('bPlan', () => {
    const set = (id, kind, k) => { $(id).value = Plan.meta(kind, 'ALL', k) || ''; };
    set('fGoal', 'leads', key); set('fGoalN', 'leads', nKey); set('fWinGoal', 'mat', key); set('fWinGoalN', 'mat', nKey);
  });
  bindPhotos();

  // calendario de feriados
  const cal = $('cal');
  if (cal) {
    const redraw = () => { cal.innerHTML = calHTML(); };
    cal.addEventListener('click', (e) => {
      const nav = e.target.closest('[data-nav]');
      if (nav) {
        const d = new Date(calMonth.y, calMonth.m + Number(nav.dataset.nav), 1);
        calMonth = { y: d.getFullYear(), m: d.getMonth() }; redraw(); return;
      }
      const dayBtn = e.target.closest('[data-d]');
      if (!dayBtn) return;
      const s = dayBtn.dataset.d;
      const p = Holidays.presumed(Number(s.slice(0, 4)), draftWork())[s];
      const set = p ? draft.ignored : draft.extra;
      if (set.has(s)) set.delete(s); else set.add(s);
      redraw();
    });
    [['fAuto', 'auto'], ['fMun', 'municipal'], ['fSat', 'saturday']].forEach(([id, k]) => {
      $(id).addEventListener('change', (e) => { draft[k] = e.target.checked; redraw(); });
    });
  }
  const tg = $('tgrid');
  if (tg) tg.addEventListener('click', (e) => {
    const chip = e.target.closest('[data-theme]'); if (!chip) return;
    tg.querySelectorAll('.tchip').forEach((x) => x.classList.toggle('on', x === chip));
    api.setBubble({ theme: chip.dataset.theme });
  });
  const bs = $('bSize');
  if (bs) bs.addEventListener('input', () => { $('bsLbl').textContent = bs.value + ' px'; clearTimeout(bs._t); bs._t = setTimeout(() => api.setBubble({ size: Number(bs.value) }), 150); });
  const form = $('form');
  if (form && !app.classList.contains('xl')) form.style.maxHeight = Math.max(320, Math.min(560, (window.screen.availHeight || 800) - 250)) + 'px';

  on('bSave', async () => {
    // le tudo da tela antes de qualquer await, pois cada salvamento redesenha a tela
    const raw = (id) => $(id).value;
    const goals = [[key, raw('fGoal'), 'lead'], [nKey, raw('fGoalN'), 'lead'], [key, raw('fWinGoal'), 'win'], [nKey, raw('fWinGoalN'), 'win']];
    const settings = readSettings();
    const vis = [['marc', raw('fVisM')], ['real', raw('fVisR')]];
    $('bSave').textContent = 'Salvando...'; $('bSave').disabled = true;
    for (const [k, v, t] of goals) {
      if (v === '' || !(Number(v) >= 0)) continue;
      const kind = t === 'lead' ? 'leads' : 'mat';
      const cur = t === 'lead' ? (S.goals || {})[k] : (S.winGoals || {})[k];
      const val = Number(v) === Plan.meta(kind, 'ALL', k) ? 0 : Number(v); // igual ao plano, volta a valer o plano
      if (val === 0 && !cur) continue;
      await (t === 'lead' ? api.setGoal(k, val) : api.setWinGoal(k, val));
    }
    for (const [k, v] of vis) if (v !== '' && Number(v) >= 0) await api.setVisitGoal(key, k, k === 'marc' && Number(v) === Plan.meta('visits', 'ALL', key) ? 0 : Number(v));
    await api.saveSettings(settings);
    view = 'main'; render();
  });
}

/* ---------------------------------------------------------------- render */
function render(source) {
  if (!S) return;
  syncAppIcon();
  // nunca redesenha os ajustes por causa de atualizacoes automaticas, senao apaga o que esta sendo digitado
  if (view === 'settings' && source === 'tick') return;
  const now = new Date();
  const app = $('app');
  const pad = 24;
  if (view === 'profiles') {
    ringPct = null;
    app.className = 'profiles'; $('heroUI').innerHTML = ''; $('info').innerHTML = pickerHTML(); $('mhost').innerHTML = '';
    lastShape = '';
    bind(now);
    const fit = () => {
      if (view !== 'profiles') return;
      const pk = app.querySelector('.picker');
      if (pk) pk.style.zoom = '';
      const h = Math.max(Math.ceil(app.querySelector('.card').getBoundingClientRect().height), pk ? pk.scrollHeight : 0);
      const availH = (window.screen.availHeight || 900) - 8;
      const need = h + pad * 2 + 12;
      if (pk && need > availH) { pk.style.zoom = String(Math.max(0.5, (availH - pad * 2 - 12) / h)); }
      const hh = Math.ceil(app.querySelector('.card').getBoundingClientRect().height);
      api.setSize(600 + pad * 2, Math.min(availH, hh + pad * 2 + 12));
    };
    fit();
    // fontes e imagens terminam de carregar depois, entao mede de novo para nao cortar a segunda fileira
    setTimeout(fit, 250); setTimeout(fit, 900);
    return;
  }
  if (view === 'main' && mode === 'bubble') {
    const m = viewModel(now);
    watch(m); watchGame(m);
    const T = THEMES[bubTheme()];
    const [bw, bh] = bubDims(bubTheme(), bubSize());
    const b = $('bubble');
    b.className = `bubble ${T.cls} sh-${T.shape}`;
    b.innerHTML = bubbleHTML(now, m, bubTheme());
    b.title = m.P.c.goal ? `${fmt(m.P.count || 0)} de ${fmt(m.P.c.goal)} ${m.P.noun}. Clique para abrir.` : 'Clique para abrir';
    app.className = 'bubblemode' + (fxToastOn ? ' fxon' + (fxUp ? ' up' : '') : ''); lastShape = '';
    app.style.setProperty('--bwpx', bw + 'px'); app.style.setProperty('--bhpx', bh + 'px'); app.style.setProperty('--bubn', bubSize() / 80);
    $('mhost').innerHTML = '';
    api.setSize(bw + pad * 2, bh + pad * 2 + (fxToastOn ? 60 : 0), snapNext); snapNext = false;
    animateRing(m);
    return;
  }
  ringPct = null;
  const cls = view === 'settings' ? 'settings' : mode;
  app.className = cls + (view === 'main' && area() !== 'mkt' ? ' vendas' : '') + (view === 'settings' && mode === 'expanded' ? ' xl' : '');
  let heroHTML, infoHTML, m = null;
  if (cls === 'settings') { heroHTML = heroSettings(); infoHTML = infoSettings(now); }
  else {
    m = viewModel(now);
    watch(m); watchGame(m);
    heroHTML = heroMain(now, m);
    const t = prof().type, big = cls === 'expanded';
    infoHTML = t === 'seller' ? (big ? infoSellerExpanded(now, m) : infoSellerCompact(now, m))
      : sdrView() ? (big ? infoSdrExpanded(now, m) : infoSdrCompact(now, m))
      : area() === 'equipe' ? infoTeam(now, m, big)
      : (big ? infoExpanded(now, m) : infoCompact(now, m));
  }
  if (m && prof().type === 'admin' && cls === 'compact') infoHTML = `<div class="segrow">${areaSeg()}</div>` + infoHTML;
  const shape = cls + prof().id + area() + unitSel + (viewKey || '') + (m && m.P.goal ? '1' : '0') + (area() === 'equipe' ? JSON.stringify(teamState()) : '');
  const changed = shape !== lastShape;
  lastShape = shape;
  $('heroUI').innerHTML = heroHTML;
  $('info').innerHTML = infoHTML;
  $('mhost').innerHTML = menuOpen && cls !== 'settings' ? monthMenu(now) : '';
  // ajustes em tela grande: largura e altura respeitam a tela, o formulario vira colunas e rola por dentro
  let xlW = 0;
  if (app.classList.contains('xl')) {
    const availW = window.screen.availWidth || 1280, availH0 = (window.screen.availHeight || 900) - 8;
    xlW = Math.max(480, Math.min(880, availW - pad * 2 - 8));
    app.style.setProperty('--cw', xlW + 'px');
    const form = $('form');
    if (form) {
      const kids = [...form.children], n = xlW < 760 ? 2 : 3;
      const cols = Array.from({ length: n }, () => { const d = document.createElement('div'); d.className = 'xc'; return d; });
      // cada titulo (h4) abre um bloco que vai inteiro para a coluna mais curta
      const blocks = []; kids.forEach((k) => { if (k.tagName === 'H4' || !blocks.length) blocks.push([k]); else blocks[blocks.length - 1].push(k); });
      const hs = blocks.map((b) => b.reduce((a, k) => a + k.offsetHeight + 12, 0));
      const tot = new Array(n).fill(0);
      blocks.forEach((b, i) => { const c = tot.indexOf(Math.min(...tot)); b.forEach((k) => cols[c].appendChild(k)); tot[c] += hs[i]; });
      form.innerHTML = ''; cols.forEach((c) => form.appendChild(c));
      form.style.maxHeight = Math.max(300, availH0 - pad * 2 - 130) + 'px';
    }
  } else app.style.removeProperty('--cw');
  if (changed) { $('info').classList.remove('fade'); void $('info').offsetWidth; $('info').classList.add('fade'); }
  bind(now);
  // o cartao nunca passa da altura da tela, se precisar a parte clara ganha rolagem
  const info = $('info'), card = app.querySelector('.card');
  info.style.maxHeight = ''; info.style.overflowY = '';
  const availH = (window.screen.availHeight || 900) - 8;
  let h = Math.ceil(card.getBoundingClientRect().height) + pad * 2;
  if (h > availH && cls !== 'settings') {
    info.style.maxHeight = Math.max(160, info.getBoundingClientRect().height - (h - availH) - 2) + 'px'; info.style.overflowY = 'auto';
    h = availH;
  }
  const w = ({ expanded: 880, settings: (mode === 'expanded' ? (xlW || 880) : 380) }[cls] || 320) + pad * 2;
  api.setSize(w, h, mode === 'expanded' ? 'center' : undefined);
}

/* ---------------------------------------------------------------- efeitos da bolinha */
// matricula nova = conquista com confete e brilho dourado. lead novo = onda de cadastro.
let fxQueue = [];
let fxBusy = false;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function watch(m) {
  const cur = m.watch || { key: m.key, leads: m.L.count, won: m.W.count, wgoal: m.W.goal };
  if (seen && seen.key === cur.key && S.agendor.enabled) {
    const dw = cur.won !== null && seen.won !== null ? cur.won - seen.won : 0;
    const dl = cur.leads - seen.leads;
    // entradas em lote (primeira sincronizacao do dia) entram em silencio
    if (view === 'main' && mode === 'bubble') {
      if (dw > 0 && dw <= 10) fxQueue.push({ type: 'won', n: dw, cur, prev: seen.won });
      if (dl > 0 && dl <= 30) fxQueue.push({ type: 'lead', n: dl, cur });
      if (fxQueue.length && !fxBusy) runFx();
    }
  }
  seen = cur;
}
async function runFx() {
  fxBusy = true;
  while (fxQueue.length) {
    const e = fxQueue.shift();
    if (!(view === 'main' && mode === 'bubble')) continue;
    await playFx(e);
  }
  fxBusy = false; fxToastOn = false;
  if (view === 'main' && mode === 'bubble') render();
}
async function playFx(e) {
  const app = $('app'), bub = $('bubble');
  fxUp = window.screenY + window.innerHeight / 2 > (window.screen.availHeight || 800) / 2;
  fxToastOn = true; render();
  await sleep(180); // espera a janela crescer
  const box = $('fx');
  const toast = document.createElement('div');
  let ms;
  if (e.type === 'won') {
    const goal = e.cur.wgoal || 0;
    toast.className = 'toast won';
    toast.innerHTML = `<svg viewBox="0 0 24 24"><path d="M12 2l2.9 6.3 6.9.8-5.1 4.7 1.4 6.8L12 17.3 5.9 20.6l1.4-6.8L2.2 9.1l6.9-.8z"/></svg><div style="flex:1"><b>${e.n > 1 ? e.n + ' matrículas!' : 'Nova matrícula!'}</b><span>${goal ? `${fmt(e.cur.won)} de ${fmt(goal)}` : `${fmt(e.cur.won)} no mês`}</span>${goal ? `<div class="tbar"><i id="tbarFill" style="--w0:${Math.min(100, (e.prev / goal) * 100)}%"></i></div>` : ''}</div>`;
    toast.dataset.w1 = goal ? Math.min(100, (e.cur.won / goal) * 100) : 0;
    const cols = ['#ffc83d', '#2fd08f', '#0aa874', '#e8366b', '#ffffff', '#ffe28a'];
    let h = '<i class="glow"></i>';
    for (let i = 0; i < 26; i++) {
      const a = (Math.PI * 2 * i) / 26 + Math.random() * 0.3, d = 38 + Math.random() * 22;
      h += `<i class="pt" style="--x:${(Math.cos(a) * d).toFixed(0)}px;--y:${(Math.sin(a) * d).toFixed(0)}px;--r:${Math.round(Math.random() * 540 - 270)}deg;--c:${cols[i % cols.length]};animation-delay:${(Math.random() * 0.12).toFixed(2)}s"></i>`;
    }
    box.innerHTML = h;
    bub.classList.add('bounce', 'gold');
    ms = 3600;
  } else if (e.type === 'badge') {
    const B = GBADGES[e.id];
    toast.className = 'toast badge';
    toast.innerHTML = `${GICON[B.icon]}<div><b>${esc(B.name)}</b><span>Conquista desbloqueada</span></div>`;
    box.innerHTML = '<i class="glow"></i><i class="rip" style="border-color:#ffc83d"></i><i class="rip" style="border-color:#ffc83d;animation-delay:.4s"></i>';
    bub.classList.add('bounce', 'gold');
    ms = 3000;
  } else {
    toast.className = 'toast lead';
    toast.innerHTML = `<svg viewBox="0 0 24 24"><circle cx="10" cy="8" r="4"/><path d="M2.5 20c.6-4 3.6-6 7.5-6s6.9 2 7.5 6M19 8v6M16 11h6"/></svg><div><b>${e.n > 1 ? '+' + e.n + ' leads' : 'Novo lead'}</b><span>${fmt(e.cur.leads)} no mês</span></div>`;
    box.innerHTML = '<i class="rip"></i><i class="rip" style="animation-delay:.35s"></i><i class="rip" style="animation-delay:.7s"></i>';
    ms = 2400;
  }
  app.appendChild(toast);
  const tf = toast.querySelector('#tbarFill');
  if (tf) setTimeout(() => { tf.style.width = toast.dataset.w1 + '%'; }, 450); // a barra de matriculas cresce
  await sleep(ms);
  toast.classList.add('out');
  await sleep(300);
  toast.remove(); box.innerHTML = ''; bub.classList.remove('bounce', 'gold');
}

/* ---------------------------------------------------------------- bolinha: arrastar e clicar */
function initBubble() {
  const b = $('bubble');
  let st = null;
  b.addEventListener('pointerdown', (e) => { b.setPointerCapture(e.pointerId); st = { x: e.screenX, y: e.screenY, moved: false }; });
  b.addEventListener('pointermove', (e) => {
    if (!st) return;
    const dx = e.screenX - st.x, dy = e.screenY - st.y;
    if (!st.moved && Math.hypot(dx, dy) < 4) return;
    st.moved = true; st.x = e.screenX; st.y = e.screenY;
    api.moveBy(dx, dy);
  });
  b.addEventListener('pointerup', () => { const was = st; st = null; if (!was) return; if (was.moved) api.snap(); else { fromBubble = true; setMode('compact'); } });
  b.addEventListener('pointercancel', () => { st = null; });
}

/* ---------------------------------------------------------------- fotos do fundo */
const PHOTOS = [
  { f: 'photos/02.jpg', p: '50% 28%', o: '45% 40%' },
  { f: 'photos/01.jpg', p: '50% 38%', o: '60% 45%' },
  { f: 'photos/04.jpg', p: '50% 55%', o: '40% 50%' },
  { f: 'photos/03.jpg', p: '50% 52%', o: '50% 50%' },
  { f: 'photos/05.jpg', p: '50% 10%', o: '55% 30%' },
  { f: 'photos/07.jpg', p: '50% 60%', o: '35% 55%' },
  { f: 'photos/06.jpg', p: '50% 14%', o: '50% 25%' },
  { f: 'photos/08.jpg', p: '50% 14%', o: '60% 25%' },
];
const SLIDE_MS = 11000;
// padrao da Noc mais as fotos da galeria da pessoa
function photoList() {
  const mine = ((S && S.photos) || []).map((p) => ({ f: p.url, p: '50% 40%', o: '50% 45%' }));
  const base = !S || S.usePhotosDefault !== false ? PHOTOS : [];
  const all = base.concat(mine);
  return all.length ? all : PHOTOS;
}
function initSlides() {
  const box = $('slides');
  const mk = () => { const i = document.createElement('img'); i.className = 'slide'; i.alt = ''; i.draggable = false; box.appendChild(i); return i; };
  const a = mk(), b = mk();
  const put = (img, ph) => { img.src = ph.f; img.style.objectPosition = ph.p; img.style.setProperty('--o', ph.o); };
  let idx = 0, cur = a;
  put(a, photoList()[0]); a.classList.add('on');
  setInterval(() => {
    const list = photoList();
    if (list.length < 2 && cur.getAttribute('src') === list[0].f) return;
    idx = (idx + 1) % list.length;
    const nxt = cur === a ? b : a, old = cur;
    put(nxt, list[idx]);
    const go = () => {
      nxt.classList.remove('leaving'); nxt.classList.add('on');
      old.classList.remove('on'); old.classList.add('leaving');
      setTimeout(() => old.classList.remove('leaving'), 3200);
      cur = nxt;
    };
    (nxt.decode ? nxt.decode() : Promise.resolve()).then(go, go);
  }, SLIDE_MS);
}

async function init() {
  initSlides();
  initBubble();
  S = await api.getState();
  mode = (S.window && S.window.mode) || 'compact';
  if (!S.ui.profile) { view = 'profiles'; if (mode === 'bubble') mode = 'compact'; }
  if (mode === 'bubble') snapNext = true;
  render();
  api.onState((s) => { S = s; render('tick'); });
  // clicou fora: o cartao aberto pela bolinha volta a ser bolinha
  api.onBlur(() => { if (fromBubble && view === 'main' && mode !== 'bubble') { fromBubble = false; setMode('bubble'); } });
  setInterval(() => render('tick'), 60 * 1000);
}
init();
