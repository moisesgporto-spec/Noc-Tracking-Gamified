const { app, BrowserWindow, ipcMain, safeStorage, screen, dialog } = require('electron');
const { pathToFileURL } = require('url');
const path = require('path');
const fs = require('fs');
const { fetchMonth, fetchYoy, fetchAggs, ENTITIES } = require('./lib/agendor');
const Calc = require('./lib/calc');
const Plan = require('./lib/plan');
const { fetchOps } = require('./lib/ops');


// Pasta de dados fixa. Sem isso, "npm start" e o programa instalado usam pastas diferentes
// e as configuracoes (inclusive o token) parecem sumir.
// Edicao do app (edition.json). Cada edicao tem pasta de dados propria, entao duas edicoes podem ficar instaladas e abertas juntas.
const EDITION = require('./edition.json');
const DATA_DIR = EDITION.game ? 'LeadsNocGamificado' : 'LeadsNoc';
app.setName(DATA_DIR);
app.setPath('userData', path.join(app.getPath('appData'), DATA_DIR));

if (!app.requestSingleInstanceLock()) app.quit();

let curW = 340;
let curH = 470;
let animTimer = null;
let win = null;
let syncTimer = null;
let syncing = false;
let moveSave = null;

const defaults = () => ({
  goals: {},
  winGoals: {},
  seeded: false,
  bubble: { theme: 'foto-clara', size: 80 },
  ui: { area: 'mkt', profile: null, team: { hide: [], metric: 'mat' } },
  ops: null,
  visitGoals: {},
  photos: [],
  usePhotosDefault: true,
  history: {},
  manualLog: [],
  agendor: { enabled: false, token: null, entity: 'deals', intervalMin: 60 },
  cache: { month: null, days: {}, total: 0, origins: {}, won: { total: 0, days: {}, origins: {} }, prev: null, syncedAt: null, error: null },
  originCache: {},
  work: { saturday: false, autoHolidays: true, municipal: true, extraHolidays: [], ignoredHolidays: [] },
  window: { x: null, y: null, mode: 'compact' },
  startWithWindows: false,
});

const storeFile = () => path.join(app.getPath('userData'), 'leads-widget.json');
let store = defaults();

function migrateOldStore() {
  // traz as configuracoes de pastas usadas por versoes anteriores
  if (fs.existsSync(storeFile())) return;
  const base = app.getPath('appData');
  // a edicao gamificada comeca com as configuracoes (e o token) da edicao normal, se existirem
  for (const dir of [...(EDITION.game ? ['LeadsNoc'] : []), 'noc-leads-widget', 'Leads Noc', 'Electron']) {
    const f = path.join(base, dir, 'leads-widget.json');
    if (fs.existsSync(f)) {
      try { fs.mkdirSync(path.dirname(storeFile()), { recursive: true }); fs.copyFileSync(f, storeFile()); return; } catch (e) { /* tenta a proxima */ }
    }
  }
}

function load() {
  migrateOldStore();
  try {
    const saved = JSON.parse(fs.readFileSync(storeFile(), 'utf8'));
    const d = defaults();
    const oldHolidays = saved.work && Array.isArray(saved.work.holidays) ? saved.work.holidays : [];
    store = { ...d, ...saved, agendor: { ...d.agendor, ...saved.agendor }, cache: { ...d.cache, ...saved.cache }, work: { ...d.work, ...saved.work }, window: { ...d.window, ...saved.window }, bubble: { ...d.bubble, ...saved.bubble }, ui: { ...d.ui, ...saved.ui } };
    delete store.work.holidays;
    if (oldHolidays.length) store.work.extraHolidays = [...new Set([...store.work.extraHolidays, ...oldHolidays])];
    if (!['bubble', 'compact', 'expanded'].includes(store.window.mode)) store.window.mode = 'compact';
    // regra nova de contagem (so funis SAPreuni e MAPreuni): descarta o que foi guardado pela regra antiga
    if (store.countRules !== 2) {
      store.countRules = 2; store.history = {}; store.agendor.entity = 'deals';
      store.cache = { ...store.cache, month: null, prev: null, yoy: null, syncedAt: null };
    }
  } catch (e) {
    store = defaults();
  }
}
function seed() {
  // as metas de cada mes vem da tabela (lib/plan.js); aqui so marcamos que a versao nova ja rodou
  if (store.seeded) return;
  store.seeded = true; save();
}
function save() {
  try {
    fs.mkdirSync(path.dirname(storeFile()), { recursive: true });
    fs.writeFileSync(storeFile(), JSON.stringify(store, null, 2));
  } catch (e) { /* segue sem salvar */ }
}

// Token guardado criptografado quando o Windows permitir
function encodeToken(t) {
  if (!t) return null;
  try {
    if (safeStorage.isEncryptionAvailable()) return { enc: safeStorage.encryptString(t).toString('base64') };
  } catch (e) { /* cai para o armazenamento simples */ }
  return { plain: t };
}
function decodeToken(v) {
  if (!v) return null;
  try {
    if (v.enc) return safeStorage.decryptString(Buffer.from(v.enc, 'base64'));
    return v.plain || null;
  } catch (e) { return null; }
}

let loadingKey = null;
let yoyBusy = false;
const photosDir = () => path.join(app.getPath('userData'), 'photos');
function publicState() {
  const { token, ...ag } = store.agendor;
  const { originCache, photos, ...rest } = store;
  const photoList = (photos || []).map((p) => ({ id: p.id, url: pathToFileURL(path.join(photosDir(), p.file)).href }));
  return { ...rest, edition: { id: EDITION.id, game: !!EDITION.game, name: EDITION.name }, photos: photoList, loadingKey, agendor: { ...ag, hasToken: !!decodeToken(token), tokenUnreadable: !!token && !decodeToken(token) }, syncing, opsBusy };
}
function push() {
  if (win && !win.isDestroyed()) win.webContents.send('state:changed', publicState());
}

async function sync() {
  const token = decodeToken(store.agendor.token);
  if (!store.agendor.enabled || !token || syncing) return;
  syncing = true; push();
  const now = new Date();
  try {
    // o mes anterior muda pouco, entao so e lido de novo na virada do mes, ao trocar o tipo de lead ou a cada 12 h
    const entity = store.agendor.entity;
    const prevKey = Calc.monthKey(Calc.prevMonthDate(now));
    const p = store.cache.prev;
    const includePrev = !p || p.month !== prevKey || p.entity !== entity || Date.now() - (p.syncedAt || 0) > 12 * 3600 * 1000;
    const r = await fetchMonth({ token, entity, now, originCache: store.originCache, includePrev });
    store.originCache = r.originCache;
    store.cache = {
      month: Calc.monthKey(now), days: r.leads.days, daysU: r.leads.daysU, total: r.leads.total, origins: r.leads.origins, won: r.won,
      prev: r.prev ? { ...r.prev, entity, syncedAt: Date.now() } : p,
      yoy: store.cache.yoy || null, diag: r.diag,
      syncedAt: Date.now(), error: null,
    };
  } catch (e) {
    store.cache = { ...store.cache, error: e.message };
  }
  syncing = false; save(); push();
  syncYoy();
  syncOps();
}

// rotina dos vendedores e da SDR (carteira aberta, tarefas e visitas). Leitura completa, por isso mais espaçada.
let opsBusy = false, opsPromise = null;
async function syncOps(force) {
  const token = decodeToken(store.agendor.token);
  const prof = Plan.profileById(store.ui.profile);
  if (opsBusy) { if (force && opsPromise) await opsPromise; return; } // leitura em andamento: o botao espera ela terminar
  if (!store.agendor.enabled || !token) {
    if (force) { store.ops = { ...(store.ops || {}), error: `${!token ? 'Nenhum token salvo nesta versão. Cole o token em Ajustes e salve.' : 'O Agendor está desligado nesta versão. Marque a opção em Ajustes e salve.'}`, syncedAt: Date.now() }; save(); push(); }
    return;
  }
  if (!force && (!prof || !(['seller', 'sdr'].includes(prof.type) || (prof.type === 'admin' && store.ui.area === 'sdr')))) return;
  if (!force && store.ops && !store.ops.error && Date.now() - (store.ops.syncedAt || 0) < 4 * 60 * 1000) return;
  opsBusy = true; push();
  opsPromise = (async () => {
    try {
      const r = await fetchOps({ token, now: new Date() });
      store.ops = { ...r, syncedAt: Date.now(), error: null };
    } catch (e) { store.ops = { ...(store.ops || {}), error: e.message, syncedAt: Date.now() }; }
    opsBusy = false; save(); push();
  })();
  await opsPromise;
}
ipcMain.handle('ops:sync', async () => { await syncOps(true); return publicState(); });
ipcMain.handle('visitgoal:set', (_e, key, kind, value) => {
  if (!/^\d{4}-\d{2}$/.test(key) || !['marc', 'real'].includes(kind)) return publicState();
  store.visitGoals[key] = { ...(store.visitGoals[key] || {}), [kind]: Math.max(0, Math.round(Number(value) || 0)) };
  save(); push(); return publicState();
});

// comparacao com o mesmo mes de 2025, lida uma vez por dia em segundo plano
async function syncYoy() {
  const token = decodeToken(store.agendor.token);
  if (!store.agendor.enabled || !token || yoyBusy) return;
  const now = new Date();
  const key = `${now.getFullYear() - 1}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const y = store.cache.yoy;
  if (y && y.month === key && y.entity === store.agendor.entity && Date.now() - (y.syncedAt || 0) < 24 * 3600 * 1000) return;
  yoyBusy = true;
  try {
    const agg = await fetchYoy({ token, entity: store.agendor.entity, now });
    store.cache = { ...store.cache, yoy: { ...agg, entity: store.agendor.entity, syncedAt: Date.now() } };
    save(); push();
  } catch (e) { /* tenta de novo na proxima rodada */ }
  yoyBusy = false;
}

// meses anteriores sob demanda: le o mes escolhido e o anterior de uma vez e guarda
ipcMain.handle('history:load', async (_e, key, force) => {
  const token = decodeToken(store.agendor.token);
  if (!/^\d{4}-\d{2}$/.test(key) || !store.agendor.enabled || !token) return publicState();
  const h = store.history[key];
  if (!force && h && h.entity === store.agendor.entity && Date.now() - (h.syncedAt || 0) < 24 * 3600 * 1000) return publicState();
  if (loadingKey) return publicState();
  loadingKey = key; push();
  try {
    const [y, m] = key.split('-').map(Number);
    const r = await fetchAggs({ token, entity: store.agendor.entity, dates: [new Date(y, m - 1, 1), new Date(y, m - 2, 1)] });
    const pk = Calc.monthKey(new Date(y, m - 2, 1));
    store.history[key] = { ...r[key], prevAgg: r[pk], entity: store.agendor.entity, syncedAt: Date.now() };
    const keys = Object.keys(store.history);
    if (keys.length > 14) keys.sort((a, b) => store.history[a].syncedAt - store.history[b].syncedAt).slice(0, keys.length - 14).forEach((k) => delete store.history[k]);
  } catch (e) { store.cache = { ...store.cache, error: e.message }; }
  loadingKey = null; save(); push();
  return publicState();
});

let monthTimer = null;
function schedule() {
  if (syncTimer) clearInterval(syncTimer);
  // na virada do mes busca os dados do mes novo na hora
  if (!monthTimer) monthTimer = setInterval(() => { if (store.agendor.enabled && store.cache.month && store.cache.month !== Calc.monthKey(new Date())) sync(); }, 60 * 1000);
  const min = Math.max(1, Number(store.agendor.intervalMin) || 60);
  syncTimer = setInterval(sync, min * 60 * 1000);
}

function visiblePosition(x, y, w, h) {
  // mantem a janela inteira dentro da area util da tela
  const d = screen.getDisplayNearestPoint({ x: x ?? 0, y: y ?? 0 }).workArea;
  const nx = Math.min(Math.max(x ?? d.x + d.width - w - 20, d.x), d.x + d.width - w);
  const ny = Math.min(Math.max(y ?? d.y + 20, d.y), d.y + d.height - h);
  return { x: nx, y: ny };
}

function createWindow() {
  const pos = visiblePosition(store.window.x == null && EDITION.game ? (screen.getPrimaryDisplay().workArea.x + screen.getPrimaryDisplay().workArea.width - curW - 400) : store.window.x, store.window.y, curW, curH);
  win = new BrowserWindow({
    width: curW, height: curH, x: pos.x, y: pos.y,
    frame: false, transparent: true, hasShadow: false, resizable: false, maximizable: false, fullscreenable: false,
    alwaysOnTop: true, backgroundColor: '#00000000', show: false,
    title: EDITION.name,
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false },
  });
  // nivel mais alto, a janela continua visivel mesmo quando voce clica em outro programa
  win.setAlwaysOnTop(true, 'screen-saver');
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());
  let t;
  win.on('moved', () => {
    clearTimeout(t);
    t = setTimeout(() => {
      const [x, y] = win.getPosition();
      store.window.x = x; store.window.y = y; save();
    }, 300);
  });
  // clicar fora da janela avisa a tela, que volta para a bolinha se tiver sido aberta por ela
  win.on('blur', () => { setTimeout(() => { if (win && !win.isDestroyed() && !win.isFocused()) win.webContents.send('window:blur'); }, 120); });
  win.on('closed', () => { win = null; });
}

ipcMain.handle('state:get', () => publicState());
ipcMain.handle('goal:set', (_e, key, value) => {
  const n = Math.max(0, Math.round(Number(value) || 0));
  store.goals[key] = n; save(); push(); return publicState();
});
ipcMain.handle('bubble:set', (_e, v) => {
  const themes = ['foto-clara', 'foto-escura', 'escuro', 'branco', 'aneis', 'tracos', 'verde', 'capsula', 'cartao', 'barra', 'lider', 'placar', 'numero'];
  if (v && themes.includes(v.theme)) { store.bubble.theme = v.theme; store.bubble.themeSet = true; }
  if (v && Number.isFinite(Number(v.size))) store.bubble.size = Math.max(56, Math.min(128, Math.round(Number(v.size))));
  save(); push(); return publicState();
});
ipcMain.handle('ui:set', (_e, v) => {
  if (v && ['mkt', 'vendas', 'equipe', 'sdr'].includes(v.area)) { store.ui.area = v.area; if (v.area === 'sdr') setTimeout(() => syncOps(), 50); }
  if (v && v.team && typeof v.team === 'object') {
    const ids = Plan.SELLERS.map((s) => s.id);
    store.ui.team = { hide: Array.isArray(v.team.hide) ? v.team.hide.filter((x) => ids.includes(x)) : [], metric: v.team.metric === 'val' ? 'val' : 'mat' };
  }
  if (v && 'profile' in v) { store.ui.profile = v.profile === null ? null : (Plan.profileById(v.profile) ? v.profile : store.ui.profile); if (v.profile) setTimeout(() => syncOps(), 50); }
  save(); push(); return publicState();
});
ipcMain.handle('photos:add', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Escolher fotos', properties: ['openFile', 'multiSelections'], filters: [{ name: 'Imagens', extensions: ['jpg', 'jpeg', 'png', 'webp'] }] });
  if (r.canceled) return publicState();
  fs.mkdirSync(photosDir(), { recursive: true });
  for (const f of r.filePaths) {
    try {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const file = id + path.extname(f).toLowerCase();
      fs.copyFileSync(f, path.join(photosDir(), file));
      store.photos.push({ id, file });
    } catch (e) { /* pula a foto que nao abriu */ }
  }
  save(); push(); return publicState();
});
ipcMain.handle('photos:remove', (_e, id) => {
  const p = store.photos.find((x) => x.id === id);
  if (p) { try { fs.unlinkSync(path.join(photosDir(), p.file)); } catch (e) { /* ja removida */ } }
  store.photos = store.photos.filter((x) => x.id !== id);
  save(); push(); return publicState();
});
ipcMain.handle('photos:defaults', (_e, v) => { store.usePhotosDefault = !!v; save(); push(); return publicState(); });
ipcMain.handle('wingoal:set', (_e, key, value) => {
  store.winGoals[key] = Math.max(0, Math.round(Number(value) || 0)); save(); push(); return publicState();
});
ipcMain.handle('manual:add', (_e, delta) => {
  store.manualLog.push({ ts: Date.now(), delta: Number(delta) || 0 }); save(); push(); return publicState();
});
ipcMain.handle('manual:undo', () => {
  store.manualLog.pop(); save(); push(); return publicState();
});
ipcMain.handle('manual:reset', (_e, key) => {
  store.manualLog = store.manualLog.filter((e) => Calc.monthKey(new Date(e.ts)) !== key);
  save(); push(); return publicState();
});
ipcMain.handle('settings:save', async (_e, s) => {
  const a = store.agendor;
  if (typeof s.token === 'string' && s.token.trim()) a.token = encodeToken(s.token.trim());
  if (ENTITIES.includes(s.entity)) a.entity = s.entity;
  a.enabled = !!s.enabled;
  a.intervalMin = Math.max(1, Number(s.intervalMin) || 60);
  const w = store.work;
  const dates = (v) => [...new Set((Array.isArray(v) ? v : []).filter((d) => /^\d{4}-\d{2}-\d{2}$/.test(d)))];
  w.saturday = !!s.saturday;
  w.autoHolidays = s.autoHolidays !== false;
  w.municipal = s.municipal !== false;
  w.extraHolidays = dates(s.extraHolidays);
  w.ignoredHolidays = dates(s.ignoredHolidays);
  store.startWithWindows = !!s.startWithWindows;
  if (app.isPackaged) app.setLoginItemSettings({ openAtLogin: store.startWithWindows });
  save(); schedule(); push();
  await sync();
  return publicState();
});
ipcMain.handle('agendor:test', async (_e, s) => {
  const token = (s.token && s.token.trim()) || decodeToken(store.agendor.token);
  if (!token) return { ok: false, error: 'Informe o token do Agendor.' };
  try {
    const r = await fetchMonth({ token, entity: s.entity, now: new Date(), originCache: store.originCache });
    return { ok: true, total: r.leads.total, won: r.won.total, origins: r.leads.origins, diag: r.diag, sellers: Object.keys(r.won.sellers).length };
  } catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('sync:now', async () => { await sync(); return publicState(); });
ipcMain.handle('window:mode', (_e, m) => {
  if (['bubble', 'compact', 'expanded'].includes(m)) { store.window.mode = m; save(); }
  return true;
});
// arrastar a bolinha: a janela e transparente e sem moldura, entao o arraste e feito pelo codigo
ipcMain.on('window:moveBy', (_e, dx, dy) => {
  if (!win) return;
  const [x, y] = win.getPosition();
  const [w, h] = win.getSize();
  const nx = x + Math.round(dx), ny = y + Math.round(dy);
  win.setBounds({ x: nx, y: ny, width: w, height: h });
  store.window.x = nx; store.window.y = ny;
  clearTimeout(moveSave); moveSave = setTimeout(save, 400);
});
// Canto da tela mais proximo do centro da janela
function nearestCorner(x, y, w, h) {
  const area = screen.getDisplayNearestPoint({ x: x + w / 2, y: y + h / 2 }).workArea;
  const right = x + w / 2 > area.x + area.width / 2;
  const bottom = y + h / 2 > area.y + area.height / 2;
  return { area, right, bottom };
}
function animateTo(tx, ty, tw, th) {
  curW = tw; curH = th;
  const [fx, fy] = win.getPosition();
  const [fw, fh] = win.getSize();
  if (fw === tw && fh === th && fx === tx && fy === ty) return;
  if (animTimer) clearInterval(animTimer);
  let step = 0;
  const steps = 9;
  animTimer = setInterval(() => {
    step++;
    const t = 1 - Math.pow(1 - step / steps, 3); // desacelera no fim
    if (!win || win.isDestroyed()) { clearInterval(animTimer); return; }
    win.setBounds({
      x: Math.round(fx + (tx - fx) * t), y: Math.round(fy + (ty - fy) * t),
      width: Math.round(fw + (tw - fw) * t), height: Math.round(fh + (th - fh) * t),
    });
    if (step >= steps) { clearInterval(animTimer); animTimer = null; store.window.x = tx; store.window.y = ty; save(); }
  }, 16);
}
// A tela pede o tamanho que precisa. A janela cresce a partir do canto mais proximo
// (assim a bolinha de um canto da direita ou de baixo abre para dentro da tela).
// Com snap, a janela encosta no canto mais proximo.
ipcMain.on('window:size', (_e, w, h, snap) => {
  if (!win) return;
  const [x, y] = win.getPosition();
  const [cw, ch] = win.getSize();
  const { area, right, bottom } = nearestCorner(x, y, cw, ch);
  const tw = Math.round(Math.min(w, area.width));
  const th = Math.round(Math.min(h, area.height));
  let tx, ty;
  if (snap) {
    // encosta na lateral mais proxima, na altura em que estiver
    tx = right ? area.x + area.width - tw : area.x;
    ty = bottom ? y + ch - th : y;
  } else {
    tx = right ? x + cw - tw : x;
    ty = bottom ? y + ch - th : y;
  }
  tx = Math.min(Math.max(tx, area.x), area.x + area.width - tw);
  ty = Math.min(Math.max(ty, area.y), area.y + area.height - th);
  animateTo(tx, ty, tw, th);
});
// ao soltar a bolinha depois de arrastar, ela vai para a lateral mais proxima (direita ou esquerda), na altura em que estiver
ipcMain.on('window:snap', () => {
  if (!win) return;
  const [x, y] = win.getPosition();
  const [cw, ch] = win.getSize();
  const { area, right, bottom } = nearestCorner(x, y, cw, ch);
  animateTo(right ? area.x + area.width - cw : area.x, Math.min(Math.max(y, area.y), area.y + area.height - ch), cw, ch);
});
ipcMain.on('window:minimize', () => win && win.minimize());
ipcMain.on('window:close', () => app.quit());

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); } });
app.whenReady().then(() => {
  load();
  seed();
  createWindow();
  schedule();
  sync();
});
app.on('window-all-closed', () => app.quit());
