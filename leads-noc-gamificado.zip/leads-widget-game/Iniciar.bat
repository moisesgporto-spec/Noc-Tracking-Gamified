@echo off
rem Abre a versao instalada (com o icone certo). Se ainda nao foi instalada, roda direto desta pasta.
if exist "%LOCALAPPDATA%\Programs\Leads Noc Gamificado\Leads Noc Gamificado.exe" (
  start "" "%LOCALAPPDATA%\Programs\Leads Noc Gamificado\Leads Noc Gamificado.exe"
  exit /b 0
)
cd /d "%~dp0"
if not exist node_modules (
  echo Instalando dependencias, so na primeira vez...
  call npm install
)
call npm start
